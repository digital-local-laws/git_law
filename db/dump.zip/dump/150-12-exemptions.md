## § 150-12 Exemptions. 


[Amended 5-7-1991 by L.L. No. 1-1991]

A. This article shall not authorize the imposition of
such tax upon any transactions by or with any of the following in
accordance with § 1230 of the Tax Law:

(1) The State of New York or any of its agencies, instrumentalities,
public corporations (including a public corporation created pursuant
to agreement or compact with another state or Canada), improvement
districts or political subdivisions of the state; and

(2) The United States of America or any of its agencies
and instrumentalities, insofar as it is immune from taxation.



B. This article shall not authorize the imposition of
such tax upon any transactions by any of the following in accordance
with § 1230 of the Tax Law:

(1) Any corporation, association, trust, community chest,
fund or foundation organized and operated exclusively for religious,
charitable or educational purposes, or for the prevention of cruelty
to children or animals, and no part of the net earnings of which inures
to the benefit of any private shareholder or individual and no substantial
part of the activities of which is carrying on propaganda, or otherwise
attempting to influence legislation; provided, however, that nothing
in this subdivision shall include an organization operated for the
primary purpose of carrying on a trade or business for profit, whether
or not all of its profits are payable to one or more organizations
described in this subdivision.



C. The hotel operator shall submit such written proof
as may be required to show that the use or occupancy falls within
the aforedescribed exempt categories. In the absence of such documentation,
the tax must be collected by the operator.

D. Bed-and-breakfast inns shall be exempt from the tax
in this article to the extent such tax exceeds 3%. A bed-and-breakfast
inn is defined as an owner-operated and -managed structure or structures
of no more than 10 guest rooms for paying guests lodged on an overnight
basis. Such establishments may serve breakfast, the cost of which
is included as part of the room-rate paid for overnight lodging.[Added 12-5-2001 by L.L. No. 6-2001; amended 4-16-2002 by L.L. No. 1-2002]


