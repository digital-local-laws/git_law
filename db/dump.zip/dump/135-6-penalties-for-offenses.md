## § 135-6 Penalties for offenses.



A. Any person who violates this chapter shall be guilty of a violation
and subject to a fine of not more than $500 and/or imprisonment for
not more than 15 days. Each and every act committed that is prohibited
by this chapter shall constitute a separate violation. Each time a
vehicle travels on a County Road without a permit as required by this
chapter shall constitute a separate violation. Violations may be prosecuted
by the County District Attorney or any other person with authority
to prosecute violations within the County.

B. Upon failure of any permittee to comply with the requirements of
this chapter, the permit shall be subject to suspension, revocation
or to the imposition of conditions.


