## § 162-7 Penalties for offenses.



A. A violation of any of the provisions of this article
shall constitute an offense, and a person found guilty of such offense may
be punished by a fine not to exceed $100 or by imprisonment not exceeding
30 days, or both such fine and imprisonment.

B. In addition to the foregoing, vehicles in violation of
any portion of this article may be towed from the area and the owner required
to reimburse the towing garage for the cost of said removal and storage of
their vehicle.


