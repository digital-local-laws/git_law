## § 160-4 Vesting of title and notice to owner.



A. If an inquiry is required under § 160-3, and
the identity of the owner is ascertained, a notice shall be sent to such owner
(and to any lienholder made known to the county by the state licensing authority)
before title may be acquired by the county. If such vehicle is unclaimed,
title shall vest in the county five days from the date such notices are mailed.
Notice shall be sent by registered or certified mail, return receipt requested,
in the form prescribed in Subsection D of this section.

B. If an inquiry is required under § 160-3 and
the identity of the owner cannot be ascertained, title to the vehicle shall
vest in the county without any additional notice being required, when notice
of such fact is received.

C. If an inquiry is not required under § 160-3,
title to the vehicle shall vest in the county immediately.

D. Form of notice to owner:







NAME AND ADDRESS OF LOCAL AUTHORITY








Mr. John Doe


Date






10 Any Street








Anytown, New York










Vehicle Plate No.








Year and Make








Vehicle Identification Number






Dear Sir:






  The above described vehicle was taken into custody as an
abandoned vehicle after being left unattended within the jurisdiction of this
(county, city, town, village).






  Pursuant to Section 2224 of the Vehicle and Traffic Law,
you are liable for the costs of removal and storage of the vehicle. The (county,
city, town, village) shall acquire title to this vehicle unless it is claimed
within five days of the above date. In such event, the vehicle will be sold,
and any funds remaining after the costs of removal and sale will be held,
without interest, for the benefit of the owner for five years.






  Your failure to claim this vehicle will not absolve you
of your liability to pay the removal and storage charges for the vehicle,
and you may be required to pay any portion of such charges which exceed the
proceeds realized from the sale of the vehicle.






  You may claim this vehicle or obtain additional information
concerning this matter by (calling) (contacting) (appearing at)






________________________






________________________






Very truly yours







