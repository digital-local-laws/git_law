## § 150-34 Effect.


Insofar as the provisions of this article are
inconsistent with the provisions of any other local law or act, the
provisions of this article shall be controlling.
