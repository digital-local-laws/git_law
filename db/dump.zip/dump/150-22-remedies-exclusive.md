## § 150-22 Remedies exclusive.


The remedies provided by §§ 150-19
and 150-21 of this article shall be exclusive remedies available to
any person for the review of tax liability imposed by this article.
No determination, proposed determination of tax nor determination
on any application for refund shall be enjoined or reviewed except
as hereinafter provided, by an action for declaratory judgment, an
action for money had and received, or by any action or proceeding
other than a proceeding in the nature of a certiorari proceeding under
Article 78 of the Civil Practice Law and Rules. A taxpayer may, however,
proceed by declaratory judgment if he/she institutes suit within 30
days after a deficiency assessment is made and pays the amount of
the deficiency assessment to the County Administrator prior to the
institution of such suit and posts a bond for costs as provided in
§ 150-19 of this article.
