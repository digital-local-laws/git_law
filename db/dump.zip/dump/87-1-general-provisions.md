## § 87-1 General provisions.



A. Authority. The Airport Manager is the person in charge
of the Airport for the County. The Airport Manager shall run the Airport in
conformity with FAA requirements and all other applicable law. The Airport
Manager may from time to time recommend, for adoption by resolution of the
County Legislature, rules and regulations for governance of the Airport, and
minimum standards to ensure fairness/equity among tenants and users of the
Airport. The Airport Manager shall at all times have authority to take such
action as may be necessary to safeguard the people in attendance at the Airport
and to maintain law and order, as well as restrict or terminate operations
when required in the interest of safety.

B. Conduct of business.

(1) Commercial use. The Airport is designed to accommodate
commercial airlines, fixed-base operators, flying clubs and other aviation
and commercial entities. However, no person, partnership, association, or
corporation shall use the Airport as a base or terminal for the carrying on
of commercial aviation, freight, or mail, or for student flight, or other
commercial purpose of transportation for hire without first securing a permit
or lease from Tompkins County and paying fees or charges agreed to with the
County for such privileges.

(2) Concessions. No person, corporation, partnership, or
association shall engage in the sale of refreshments or any other commodity,
gasoline, oil, rental, or any travel services or offer or solicit funds from
the public at the Airport for any purpose, or post notices such as advertising
signs, without permission of the County and the payment of the rates and charges
for use prescribed and agreed upon by both the County and such person.

(3) Any individual, group of individuals, partnership, or
corporation (hereafter referred to as "operator") during the conduct of any
flight or other activity at the Airport shall comply with the rules and regulations
and pay all fees and charges, whether imposed pursuant to an agreement made
with the County or prescribed by the County for other-than-contract operations.

(4) Sales of fuel and fuel-related products will only be
allowed by contract with the County.



C. Other provisions.

(1) Security. All persons using the Airport are subject to
Airport security regulations and procedures, in compliance with federal, state,
and local laws.

(2) Environmental compliance. All Airport tenants and users
shall obey all federal, state, and local environmental laws and shall be wholly
responsible for costs associated with fines or clean-up of contamination brought
about as a result of their actions, operations, and the activities of their
employees, their guests, and invitees.

(3) Discrimination or unfair treatment. The Airport shall
be made available for public use on fair and reasonable terms. No tenant shall
be allowed to discriminate on the basis of race, religion, color, age, disability,
gender, or sexual orientation.

(4) Construction or alteration of property. No person shall
do any construction, alteration work, plumbing, or electrical wiring in or
to any existing building on the Airport without first securing written permission
from the Airport Manager. Violators will be required to remove such work at
their own expense.

(5) Animals. No person shall enter on the Airport property
with an animal that is not restrained by a leash or confined in such a manner
as to be under control at all times.

(6) Firearms, explosives, and other weapons. No person except
police, duly authorized persons, FBI personnel, County Airport employees,
or members of the Armed Forces of the United States on official duty in uniform
of that branch of the service shall carry any firearms, explosives, or incendiary
devices or other dangerous weapons on the Airport without written permission
of the Airport Manager.




