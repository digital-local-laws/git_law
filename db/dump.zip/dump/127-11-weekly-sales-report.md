## § 127-11 Weekly sales report.


Any person or firm permitted to conduct business under the provisions
of this chapter shall file and attest to its accuracy a report containing
the gross amount of sales for each week or portion thereof that such business
is conducted. This report is to be filed on or before 12:00 noon, on Monday
or the first business day of each week for any portion of the preceding week
in which sales were made. The report is to be filed with the County Clerk
unless otherwise stipulated. The bond will not be returned until the report
has been filed.
