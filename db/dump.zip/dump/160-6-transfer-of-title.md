## § 160-6 Transfer of title.



A. Whenever a vehicle is sold pursuant to the provisions
of § 1224 of the Vehicle and Traffic Law, the appropriate official
or employee of the county shall issue a bill of sale substantially in the
form prescribed in Subsection B of this section. Bills of sale shall be numbered
consecutively as issued, and a copy shall be maintained by the county for
one year after the date of sale.

B. Bill of sale.







Form of bill of sale:








NO._____________________


COUNTY OF TOMPKINS








SHERIFF'S DEPARTMENT








BILL OF SALE






The vehicle described below was sold on the below date as an abandoned
vehicle, pursuant to the provisions of § 1224 of the New York State
Vehicle and Traffic Law. Notice of sale was sent to the last registered owner,
if known, as required by law.






Make


Year


Type


Color


Cylinders


Vin


Date of Sale


Amount






Name and Address of Last Owner: ____________________






__________________________






Name and Address of Purchaser: ____________________________






______________________________








____________________________








(TITLE)






DATED:________________________






STATE OF NEW YORK


)








) ss:






COUNTY OF TOMPKINS


)






On this ____________ day of _______________________, nineteen hundred
________________________,






before me personally came _____________ to me personally known,






who, being by me duly sworn did depose and say that he (she) is the
__________________________






of the _____________________________ and that he (she) is duly authorized
and empowered to execute this instrument and that he (she) has signed his
(her) name hereto by the virtue of the power vested in him (her).








___________________________








NOTARY







