## § 22-6 Indemnification.



A. Tompkins County shall indemnify and hold its employees
harmless in the amount of any judgment obtained against such employees in
a state or federal court, or in the amount of any settlement of a claim, provided
that the act or omission from which such judgment or claim arose occurred
while the employee was acting within the scope of his/her public employment
or duties; provided further that in the case of a settlement, the duty to
indemnify and hold harmless shall be conditioned upon the approval of the
amount of settlement by the Tompkins County Board of Representatives.

B. Except as otherwise provided by law, the duty to indemnify
and hold harmless prescribed by this section shall not arise where the injury
or damage resulted from intentional wrongdoing or recklessness on the part
of the employee.

C. Nothing in this section shall authorize Tompkins County
to indemnify or hold an employee harmless with respect to punitive or exemplary
damages, fines, or penalties, or money recovered from an employee pursuant
to § 51 of the General Municipal Law.

D. Upon entry of a final judgment against the employee,
or upon settlement of the claim, the employee shall serve a copy of such judgment
or settlement personally or be certified or registered mail within 30 days
of the date of entry or settlement, upon the Chairman of the Tompkins County
Board of Representatives; and, if not inconsistent with the provisions of
this article, the amount of such judgment or settlement shall be paid by Tompkins
County.


