## § 104-1 Use restricted.


The use of county-owned or -leased buildings and grounds by other than
county and state officials, employees and authorized persons, including service
and maintenance personnel, is prohibited during the hours that said buildings
and grounds are not open for public use, as posted.
