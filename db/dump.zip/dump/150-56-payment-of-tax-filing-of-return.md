## § 150-56 Payment of tax; filing of return.



A. The real estate transfer tax shall be paid to the
Finance Director or the Tompkins County Clerk or other recording officer
acting as the agent of the Finance Director upon designation as such
agent by the Finance Director. Such tax shall be paid at the same
time as the real estate transfer tax imposed by Article 31 of the
New York State Tax Law is required to be paid. The Finance Director
or recording officer shall endorse, upon each deed or instrument affecting
a conveyance, a receipt for the amount of the tax so paid.

B. A return shall be required to be filed with the Finance
Director or recording officer for purposes of the real estate transfer
tax imposed pursuant to this article at the same time as a return
is required to be filed for purposes of the real estate transfer tax
imposed by Article 31. The return, for purposes of the real estate
transfer tax imposed pursuant to this article, shall be a photocopy
or carbon copy of the real estate transfer tax return required to
be filed pursuant to § 1409 of New York State Tax Law. However,
when an apportionment is required to be made pursuant to § 150-62,
a supplemental form shall also be required to be filed. The real estate
transfer tax returns and supplemental forms required to be filed pursuant
to this section shall be preserved for three years and thereafter
until the Finance Director or recording officer orders them to be
destroyed.

C. The recording officer shall not record an instrument
affecting a conveyance unless the return required by this section
has been filed and the tax imposed pursuant to this article shall
have been paid as provided in this section.


