## § 1-10 Penalties for tampering with Code.


Any person who, without authorization from the Clerk of the Board of
Representatives, changes or amends, by additions or deletions, any part or
portion of the Code of Tompkins County or who alters or tampers with such
Code in any manner whatsoever which will cause the legislation of Tompkins
County to be misrepresented thereby or who violates any other provision of
this local law shall be guilty of an offense and shall, upon conviction thereof,
be subject to a fine of not more than $250 or imprisonment for a term of not
more than 15 days, or both.
