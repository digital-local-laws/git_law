## § 114-17 Administration and collection of fee by Commissioner of New York State Department of Motor Vehicles.



A. As authorized under Tax Law § 1202(c), the
motor vehicle use fee shall be administered and collected on behalf
of Tompkins County by the Commissioner of the New York State Department
of Motor Vehicles or his agents.

B. Pursuant to Tax Law § 1202(c), the New York
State Commissioner of Motor Vehicles is authorized, on behalf of Tompkins
County, to make the payment of such fee a condition precedent to the
registration or registration renewal of any vehicle subject to the
fee imposed by this article.

C. The Chair of the Tompkins County Legislature is hereby
authorized and directed to negotiate and enter into an agreement with
the Commissioner of the New York State Department of Motor Vehicles
for the implementation of this article, and such agreement shall provide
for the exclusive method of collection, custody, and remittal of the
proceeds of any such fee and for the payment by the County of the
reasonable expenses incurred by the New York State Department of Motor
Vehicles in connection with the collection and administration of said
fee. Such agreement shall also provide that the Tompkins County Director
of Finance, upon request, not more frequently than once in each calendar
year at a time agreed upon by the State Comptroller, shall audit the
accuracy of the payments, distributions, and remittances to Tompkins
County pursuant to this article.

D. The said agreement shall set forth, in detail, policies
and procedures for collection for underpayment and for refunds. Such
agreement shall also set forth procedures for deposit and retention
of funds and indemnification.


