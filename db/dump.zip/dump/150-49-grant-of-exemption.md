## § 150-49 Grant of exemption.


Such exemptions shall be granted where the Assessor
is satisfied that the applicant is entitled to an exemption pursuant
to this article. The Assessor shall approve such application and such
property shall thereafter be exempt from taxation and special ad valorem
levies for the County real property taxation as provided in the schedule
established in § 150-46 of this article commencing with
the assessment roll prepared on the basis of the taxable status date
referred to in § 150-48 of this article. The assessed value
of any exemption granted pursuant to this section shall be entered
by the Assessor on the assessment roll with the taxable property,
with the amount of the exemptions shown in a separate column.
