## § 110-14 Penalties for offenses.


Any person or entity violating this article
shall be guilty of a violation and shall be subject to a fine not
exceeding $100. For purpose of this article, each improperly routed
911 call shall constitute a separate offense.
