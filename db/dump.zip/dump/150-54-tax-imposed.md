## § 150-54 Tax imposed.


Pursuant to Article 31-G of New York State Tax
Law, a tax is hereby imposed on each conveyance of real property or
interest therein in Tompkins County when the consideration exceeds
$500, at a rate of $1 for each $500 or fractional part thereof.
