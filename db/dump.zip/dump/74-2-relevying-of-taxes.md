## § 74-2 Relevying of taxes.


The County Legislative body shall cause the amount of such unpaid taxes,
together with 7% of the amount of principal and interest, to be relevied upon
the real property upon which the same were originally imposed by the village.
After relevy on the town and county tax roll, all such relevied amounts shall
be part of the total tax to be collected.
