## § 74-11 Owner's election of manner of payment.



A. Upon receipt of the statement of taxes, an owner of real
property may elect to pay the total amount of the taxes set forth in such
statement without regard to this article; or he may elect to pay such taxes
in installments as provided herein.

B. If such owner shall elect to pay the taxes in installments,
he shall pay to the collecting officer the amount set forth in such statement
and designated as "first installment," which amount shall include the service
charge set forth in § 74-8 of this article. The amount of the second
installment shall be paid to the County Treasurer on or before the date specified
in § 74-7 of this chapter.

C. If any such installment is paid on or before the date
when due, no interest shall be charged thereon; if not so paid, interest shall
be added to the amount of any such installment at the rate as determined pursuant
to § 924-a of the Real Property Tax Law. No such installment may
be paid unless all prior installments of current taxes, including interest,
shall have been paid or shall be paid at the same time.

D. The owner of real property who elects to pay taxes in
installments as provided in this section shall indicate his election by remitting
the amount of the first installment to the collecting officer on or before
the date upon which it is due or not later than within five calendar days
thereafter; provided, however, that in the event that the amount of the first
installment is paid after the date upon which it was due, the interest rate
set forth in Subsection C of this section shall apply.

E. The failure or neglect by an owner of real property to
pay the first installment as provided in Subsection D of this section shall
be construed as an election by such owner to pay the total amount of taxes
in one payment in the manner provided by law.


