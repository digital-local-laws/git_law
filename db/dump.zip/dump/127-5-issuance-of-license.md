## § 127-5 Issuance of license.



A. Grant, refusal. Upon the filing of the application as
provided in § 127-4, the Sheriff shall, upon his approval of such
application, issue to the applicant a license as provided in § 127-2
hereof. Except as hereinafter provided, no license shall be refused except
for a specific reason and for the protection of the public safety, health,
morals, or the general welfare.

B. A license shall not be assignable. Any holder of such
license who permits it to be used by any person, and any person who uses such
license granted to any other person, shall each be guilty of a violation of
this chapter.

(1) Contents. All licenses shall be issued from a properly
bound book with proper reference stubs kept for that purpose, numbered in
the order in which they are issued, and shall state clearly the kind of vehicle,
if any, to be used, and the kind of goods, wares or merchandise to be sold
or service to be rendered, the dates of issuance and expiration of the license,
the fee paid and the name and address of the licensee.

(2) Every licensee, while exercising his license, shall at
all times display the license conspicuously, or if engaged in telephone solicitation,
shall upon the commencement of each call state his name and address and the
number of his license.




