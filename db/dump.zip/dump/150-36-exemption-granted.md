## § 150-36 Exemption granted.


The County of Tompkins hereby grants a real
property tax exemption for veterans under the Alternative Exemption
Program, with the following maximum levels of exemption:

A. Past war veterans exemption. For those honorably discharged
veterans (and certain of their family members as set forth in the
enabling legislation) who served during the Spanish-American War,
the Mexican Border War, World War I, World War II, the Korean War,
the Vietnam War period, or the Person Gulf conflict::

(1) Fifteen percent of the assessed value, with a maximum
exemption of $15,000.



B. Combat zone veterans exemption. For those veterans
under the basic war veterans exemption who can also document service
in a combat theater or zone:

(1) An additional 10% of assessed value, with a maximum
exemption of $10,000.



C. Disability veterans exemption. For those veterans
who have received a service-connected disability compensation rating
from the Veterans' Administration:

(1) An additional percent of assessed value equal to 50%
of the disability rating, with a maximum exemption of $50,000.




