## § 17-3 Designation, status, qualifications and terms of designation of emergency interim successors.



A. Elective officers. Within 30 days following the effective
date of this chapter, and thereafter within 30 days after first entering upon
the duties of his office, each elective officer shall, in addition to any
duly authorized deputy, designate such number of emergency interim successors
to the powers and duties of his office and specify their rank in order of
succession after any duly authorized deputy so that there will not be fewer
than three duly authorized deputies or emergency interim successors, or combination
thereof, to perform the powers and duties of the office.

B. Appointive officers. Each officer or body of officers
empowered by law to appoint officers shall within the time specified in subdivision
a of this section, in addition to any duly authorized deputy, designate for
each such appointive officer, such number of emergency interim successors
to such officers and specify their rank in order of succession after any duly
authorized deputies or emergency interim successors, or combination thereof,
for each such officer. Where such a body of officers consists of members having
overlapping terms, such body of officers shall review and, as necessary, revise
the previous designations of emergency interim successors by such board within
30 days after a new member elected or appointed to such body of officers first
enters upon the duties of his office as a member of such body of officers.

C. Review of designations. The incumbent, in the case of
those elective officers specified in Subsection A of this section, and the
appointing officer or body of officers specified in Subsection B of this section,
shall from time to time review and, as necessary, promptly revise the designations
of emergency interim successors to insure that at all times there are at least
three duly authorized deputies or emergency interim successors, or combination
thereof, for each elective and appointive officer of the county.

D. Qualifications. No person shall be designated to, nor
serve as, an emergency interim successor unless he has legally qualified to
hold the office of the person to whose powers and duties he is designated
to succeed.

E. Status of emergency interim successor. A person designated
as an emergency interim successor shall hold that designation at the pleasure
of the designator, and such a designation shall remain effective until replaced
by another by the authorized designator.

F. Compensation. An emergency interim successor shall serve
without additional salary, unless otherwise provided by local law. He shall,
however, be entitled to reimbursement for actual expenses necessarily incurred
in the performance of his powers and duties.


