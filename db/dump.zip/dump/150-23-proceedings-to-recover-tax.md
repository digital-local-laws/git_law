## § 150-23 Proceedings to recover tax.



A. Whenever any operator, any officer of a corporate
operator, any occupant, or other person fails to collect and pay over
any tax and/or penalty or interest as imposed by this article, the
County Attorney shall, at the request of the County Administrator,
bring or cause to be brought an action to enforce the payment of the
same on behalf of the County in any court of the State of New York
or of any other state or of the United States. If, however, the County
Administrator believes that any such operator, officer, occupant,
or other person is about to cease business, leave the state, or remove
or dissipate the assets out of which the tax or penalties might be
satisfied, and that any such tax or penalty will not be paid when
due, such tax or penalty may be declared to be immediately due and
payable, and the County Administrator may issue a warrant immediately.

B. As an additional or alternate remedy, the County Administrator
may issue a warrant, directed to the Sheriff, commanding the Sheriff
to levy upon and sell the real and personal property of the operator,
officer of a corporate operator, or other person liable for the tax,
which may be found within the County for the payment of the amount
thereof, with any penalties and interest, and the cost of executing
the warrant, and to return such warrant to the County Administrator
and to pay to the County Administrator the money collected by virtue
thereof within 60 days after the receipt of said warrant. Within five
days after the receipt of the warrant, the Sheriff shall file a copy
of same with the County Clerk. Thereupon the Clerk shall enter in
the judgment docket the name of the person stated in the warrant,
the amount of the tax, penalties, and interest for which the warrant
is issued, and the date when such copy is filed. Thereupon the amount
of such warrant so docketed shall become a lien upon the interest
in real and personal property of the person against whom the warrant
is issued. The Sheriff shall then proceed upon the warrant in the
same manner and with like effect as that provided by law in respect
to executions issued against property upon judgments of the court
of record. For services in executing the warrant, the Sheriff shall
be entitled to the same fees, which may be collected in the same manner.
In the discretion of the County Administrator, a warrant of like terms,
force, and effect may be issued and directed to any officer or employee
of the County Administrator. In the execution thereof, such officer
or employee shall have all the powers conferred by law upon sheriffs,
but shall be entitled to no fee or compensation in excess of the actual
expenses paid in the performance of such duty. If a warrant is returned
not fully satisfied, the County Administrator may, from time to time,
issue new warrants and shall also have the same remedies to enforce
the amount due thereunder as if the County has recovered judgment
therefor and execution thereon has been returned unsatisfied.

C. Whenever an operator makes a sale, transfer, or assignment
of any part or the whole of the hotel or lease, license, or other
agreement or right to possess or operate such hotel or the equipment,
furnishings, fixtures, supplies or stock of merchandise, or the said
premises or lease, license or other agreement or right to possess
or operate such hotel and equipment, furnishings, fixtures, supplies
and stock of merchandise pertaining to the conduct or operation of
said hotel, other than in the ordinary and regular prosecution of
business, the purchaser, transferee or assignee shall, at least 10
days before taking possession of the subject of said sale, transfer
or assignment, or before making payment, notify the County Administrator
by registered mail of the proposed sale and the price, terms and conditions
thereof, whether or not the seller, transferor or assignor has represented
to or informed the purchaser, transferee, or assignee that it owes
any tax pursuant to this article, whether or not the purchaser, transferee,
or assignee has knowledge that such taxes are owing, and whether any
such taxes are in fact owing.

D. Whenever the seller, transferor, or assignor fails
to give notice to the County Administrator as required above, or whenever
the County Administrator informs the purchaser, transferee, or assignee
that a possible claim for such tax(es) exists, any sums of money,
property, choses in action, or other consideration which the purchaser,
transferee or assignee is required to transfer over to the seller,
transferor, or assignor shall be subject to a first priority right
and lien for any such taxes theretofore or thereafter determined to
be due from the seller, transferor, or assignor to the County. The
purchaser, transferee, or assignee is then forbidden to transfer to
the seller, transferor, or assignor any such sums of money, property,
or choses in action to the extent of the amount of the County's claim.
For failure to comply with the provisions of this subsection, the
purchaser, transferee, or assignee, in addition to being subject to
the liabilities and remedies imposed under the provisions of Article
6 of the Uniform Commercial Code, shall, as well as the seller, transferor,
or assignor, be personally liable for the payment to the County of
any such taxes theretofore or thereafter determined to be due to the
County from the seller, transferor, or assignor. Such liability may
be assessed and enforced in the same manner as the liability for tax
under this article.


