## § 140-21 Designation of specified facility.



A. The Board of Representatives is hereby authorized to
designate, by resolution, from time to time, one or more specified facilities,
to which certain acceptable solid waste or regulated recyclable materials,
generated or originated, or brought within the county, must be delivered.
Any so specified facility or facilities shall be the only facility or facilities
to which such acceptable solid waste or regulated recyclable materials shall
be delivered. Such designation shall be subject to such exceptions as are
set forth in the rules and regulations promulgated pursuant to this article
or as the Commissioner may determine to be in the public interest.

B. Should the Board of Representatives designated one or
more specified facilities pursuant to Subsection A above, no person shall
dispose of or deliver such acceptable solid waste or regulated recyclable
materials except at the designated facility or facilities.

C. Should the Board of Representatives designate one or
more specified facilities pursuant to Subsection A above, no facility shall
accept such acceptable solid waste or regulated recyclable materials, other
than the designated facility or facilities.

D. Any solid waste generated or originated or brought within
the county that has not been designated to be delivered to a specified facility
shall be disposed of only as permitted under other state, federal and local
laws.


