## § 150-29 Notices and limitations of time.



A. Any notice authorized or required under the provisions
of this article may be given by mailing the same to the person for
whom it is intended in a postpaid envelope addressed to such person
at the address given in the last return filed by him pursuant to the
provisions of this article, or in any application made by him. If
no return has been filed nor application made, then notice may be
given by mailing the same to such address as may be obtainable. Mailing
of such notice shall be presumptive evidence of the receipt of same
by the person to whom it is addressed. Any period of time which is
determined according to the provisions of this article by the giving
of notice shall commence to run from the date of mailing of such notice.

B. The provisions of the Civil Practice Law and Rules
or any other law relative to limitations of time for the enforcement
of a civil remedy shall not apply to any action or proceeding taken
by the County to levy, appraise, assess, determine, or enforce the
collection of any tax or penalty provided by this article. However,
except in the case of a willfully false or fraudulent return with
the intent to evade the tax, no assessment of additional tax shall
be made after the expiration of more than three years from the date
of filing of a return; provided, however, that where no return has
been filed as provided by law, the tax may be assessed and collected
at any time.

C. Where a taxpayer has consented, in writing, before
the expiration of the period prescribed herein for the assessment
of an additional tax, that such period be extended, the amount of
such additional tax due may be determined at any time within the extended
period. The period so extended may be further extended by subsequent
consents, in writing, made before the expiration of the extended period.


