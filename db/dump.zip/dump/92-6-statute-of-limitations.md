## § 92-6 Statute of limitations.


Any action brought for violation of this chapter must be commenced within
one year after the alleged unlawful discriminatory practice, unless the complainant
chooses to attempt conciliation with the Human Rights Commission, in which
the complainant must commence action within one year from the unsuccessful
termination of conciliation efforts or one year from the Investigator's
determination that the conciliation agreement has been breached by the respondent.
