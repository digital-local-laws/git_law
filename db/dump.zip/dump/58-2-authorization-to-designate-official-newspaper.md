## § 58-2 Authorization to designate official newspaper.


That notwithstanding the provisions of § 214 of County Law,
the Tompkins County Board of Representatives is authorized and empowered to
designate annually one newspaper of general circulation as the official newspaper
of Tompkins County, wherein all notices required by law may be published.
