## § 114-5 Establishment of annual solid waste fee.



A. The annual solid waste fee shall be charged to all
owners of improved real property located within the county, as the
owners and users of such property are deemed to generate solid waste
or recyclable materials and are therefore users of county's solid
waste and/or recycling facilities and services.

B. The annual solid waste fee shall be an annual fee
covering the period from January 1 through December 31.

C. The Board shall establish by resolution a rate schedule
of classifications and formulas for determining the billing units
assigned to all parcels based upon the use of the real property. The
classification of parcels and the formulas for determining the billing
units assigned to each class shall be based on the level of services
available to such class, which shall be determined by the Board at
its sole discretion. Information regarding the use of each parcel
and property measurements shall be based upon the county's records
for the assessment of property values. These records shall be used
as the basis for purposes of calculating billing units under this
article. The Board may amend the rate schedule from time to time by
resolution, to add, delete or change classes of parcels on the solid
waste fee roll or to change the method for calculating the number
of billing units of a specific class.

D. On or before December 10 of each year, the Board shall
by resolution establish the unit charge to be applied for the following
fiscal year in calculating the annual solid waste fee to be charged.

E. The annual solid waste fee shall be charged to the
owner of each parcel of real property in accordance with this article,
based upon the number of billing units assigned to such parcel (as
set forth in § 114-6 below) times the unit charge set for
the year.

F. A fifty-percent exemption from the annual solid waste
fee shall be allowed for all senior citizens who also qualify for
the senior citizen partial exemption from real property taxes.


