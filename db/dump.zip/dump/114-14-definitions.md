## § 114-14 Definitions.


As used in this article, the following terms
shall have the meanings indicated:

BUSES
The same meaning as defined in § 104 of the Vehicle
and Traffic Law, as amended.


PASSENGER MOTOR VEHICLE
Any motor vehicle subject to the registration fee as provided
for in § 401, Subdivision 6, of the Vehicle and Traffic
Law.


TRUCK
The same meaning as defined in § 158 of the Vehicle
and Traffic Law, as amended.

