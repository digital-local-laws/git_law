## § 74-1 County Administrator authorized to collect taxes.


Notwithstanding any general, special or local law to the contrary, upon
receipt of a village ordinance, local law or resolution of a village within
Tompkins County requesting the County of Tompkins to collect delinquent village
taxes subsequent to the effective date of this article and upon certification
of correctness of such unpaid taxes by the village authorities, the County
Administrator of Tompkins County may collect such village taxes, provided
that said certificate by the village authorities is received by the County
Administrator no later than the 15th day of November following the levy of
taxes. (Pursuant to § 1436 of the Real Property Tax Law).
