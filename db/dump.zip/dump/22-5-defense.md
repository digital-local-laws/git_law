## § 22-5 Defense.



A. Upon compliance by the employee with the provisions of
§ 22-7 of this article, Tompkins County shall provide for the defense
of the employee in any civil action or proceeding, state or federal, arising
out of any alleged act or omission which occurred or allegedly occurred while
the employee was acting within the scope of his/her public employment or duties.
This duty to provide for a defense shall not arise where such civil action
or proceeding is brought by or at the behest of Tompkins County.

B. Subject to the conditions set forth in Subsection A of
this section, the employee shall be entitled to representation by private
counsel of his/her choice in any civil action or proceeding whenever the County
Attorney determines that a conflict of interest exists, or whenever a court,
upon appropriate motion or otherwise by a special proceeding, determines that
a conflict of interest exists and that the employee is entitled to be represented
by counsel of his/her choice; provided, however, that the County Attorney
may require, as a condition to payment of the fees and expenses of such representation,
that appropriate groups of such employees be represented by the same counsel.
Reasonable attorney's fees and litigation expenses shall be paid by Tompkins
County to such private counsel from time to time during the pendency of the
civil action or proceeding with the approval of the Tompkins County Board
of Representatives.

C. Any dispute with respect to representation of multiple
employees by a single counsel or the amount of litigation expenses or the
reasonableness of attorney's fees shall be resolved by the court upon motion
or by way of a special proceeding.

D. Where the employee delivers process and a written request
for a defense to Tompkins County under § 22-7 of this article, the
county shall take the necessary steps on behalf of the employee to avoid entry
of a default judgment pending resolution of any question pertaining to the
obligation to provide for a defense.


