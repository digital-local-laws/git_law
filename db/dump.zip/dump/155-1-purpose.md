## § 155-1 Purpose.


Prohibiting the self-service sales and open displays of tobacco products
will promote the health, safety and welfare of residents of Tompkins County
under the age of 18 by making it more difficult for such minors to purchase
tobacco products.
