## § 140-27 Permits.



A. To the extent provided in the rules and regulations promulgated
hereunder, no person shall dispose of solid waste or recyclables at a facility
owned or operated by or contracted for by the county without a permit issued
by the county.

B. Permits must be obtained from the Commissioner.

C. The Board of Representatives shall establish the fee(s)
for permits.

D. The terms and conditions for the permit shall be determined
by the rules and regulations promulgated pursuant to this article.


