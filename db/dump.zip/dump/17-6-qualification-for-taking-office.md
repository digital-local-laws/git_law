## § 17-6 Qualification for taking office.


At the time of their designation, or as soon thereafter as possible,
emergency interim successors, Acting Chairman of the Board of Supervisors,
Deputy Chairman of the Board of Supervisors, shall take such oath and do such
other things, if any, as may be required to qualify them to perform the powers
and duties of the office to which they may succeed.
