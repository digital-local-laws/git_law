## § 74-6 Definitions.


As used in this article, the following terms shall have the meanings
indicated:

TAXES
Includes special assessments which are levied by the County Legislature
at the time and in the manner provided by law for the levy of county and town
taxes.

