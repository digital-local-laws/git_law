## § 145-1 Notification required.


No civil action shall be maintained against the County of Tompkins or
the County Commissioner of Public Works for damages or injuries to persons
or property sustained in consequence of any county street, highway, road,
bridge, culvert, sidewalk or crosswalk being out of repair, unsafe, dangerous
or obstructed, or in consequence of the existence of snow or ice thereon,
unless prior thereto written notice of the defective, unsafe, dangerous or
obstructed condition, or of the existence of such snow or ice, was actually
given to the Clerk of the Board of Representatives or the County Board of
Representatives and there was a failure or neglect within a reasonable time
after the giving of such notice to repair or remove the defect, danger, or
obstruction complained of, or to cause the snow or ice to be removed, or the
place otherwise made reasonably safe.
