## § 140-28 Enforcement.


This article shall be enforced by:

A. Any peace officer or police officer, as provided by the
Criminal Procedure Law of the State of New York.

B. The Commissioner or designee, by issuance of an appearance
ticket pursuant to Article 150 of the Criminal Procedure Law of the State
of New York.


