## § 150-62 Apportionment.


The amount of tax due whenever the real property
or interest therein is situated within and without the County of Tompkins
shall be in proportion to the value of the property in the County
of Tompkins relative to the value outside the County.
