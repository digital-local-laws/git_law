## § 72-6 Definitions.


As used in this article, the following terms shall have the meanings
indicated:

BAR
Any area, including outdoor seating areas, devoted to the sale and
service of alcoholic beverages for on-premises consumption and where the service
of food is only incidental to the consumption of such beverages.


FOOD-SERVICE ESTABLISHMENT
Any area, including outdoor seating areas, or portion thereof in
which the business is the sale of food for on-premises consumption.


PLACE OF EMPLOYMENT
Any indoor area or portion thereof under the control of an employer
in which employees of the employer perform services, and shall include, but
not be limited to, offices, school grounds, retail stores, banquet facilities,
theaters, food stores, banks, financial institutions, factories, warehouses,
employee cafeterias, lounges, auditoriums, gymnasiums, restrooms, elevators,
hallways, museums, libraries, bowling establishments, employee medical facilities,
rooms or areas containing photocopying equipment or other office equipment
used in common, and company vehicles.


SMOKING
The burning of a lighted cigar, cigarette, pipe or any other matter
or substance which contains tobacco.

