## § 68-3 Participation; rules and regulations.


The City of Ithaca and any of the towns and villages within the County
of Tompkins may become a participant in the Tompkins County Self-Insurance
Plan in the manner prescribed by the rules and regulations adopted by the
Board of Supervisors. Such rules and regulations shall also provide a method
by which a participant may withdraw from the plan.
