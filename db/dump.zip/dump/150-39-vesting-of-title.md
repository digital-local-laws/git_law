## § 150-39 Vesting of title.


Title to that portion of real property owned
by a cooperative apartment corporation in which a tenant-stockholder
of such corporation resides, and which is represented by his share
or shares of stock in such corporation as determined by its or their
proportional relationship to the total outstanding stock of the corporation,
including that owned by the corporation, shall be deemed to be vested
in such tenant-stockholder.
