## § 130-5 Penalties for offenses.



A. Administrative sanctions.

(1) A person providing a commercial lawn application who
violates any provision of this article shall be liable for a civil penalty
not to exceed $5,000 for a first violation, and not to exceed $10,000 for
a subsequent offense.

(2) An owner or owner's agent of a multiple dwelling or owner,
owner's agent or a person in a position of authority for all other types of
premises, who violates any rule or regulation pursuant to the section on prior
notification of commercial lawn applications, and a person who violates any
provision of the subdivision posting of residential lawn applications shall
for a first such violation, in lieu of penalty, be issued a written warning
and shall also be issued educational materials prepared by the Commissioner
pursuant to Subdivision 2 of § 33-1005 of the New York Environmental
Conservation Law. Such person shall, however, for a second violation, be liable
for a civil penalty not to exceed $100, and not to exceed $250 for any subsequent
violation.

(3) A person who violates the provisions of the section on
retail consumer information sign shall be issued a warning for the first violation
and shall be provided seven days to correct such violation; and shall be liable
for a civil penalty not to exceed $100 for a second violation, and not to
exceed $250 for a subsequent violation.



B. Criminal sanctions for persons providing commercial lawn
applications.

(1) Any person providing a commercial lawn application and
having the culpable mental states defined in Subdivision 1 or 2 of § 15.05
of the New York Penal Law who violates any provision of this article, except
an offense relating to the application of a general use pesticide, shall be
guilty of a misdemeanor and, upon conviction thereof, shall be punished by
a fine not to exceed $5,000 for each day during which such violation continues
or by imprisonment for a term of not more than one year, or by both such fine
and imprisonment. If the conviction is for a subsequent offense committed
after a first conviction of such person under this subsection, punishment
shall be by a fine not to exceed $10,000 for each day during which such violation
continues or by imprisonment for a term of not more than one year, or by both
such fine and imprisonment.

(2) Any person providing a commercial lawn application who
violates any provision of this article relating to the use of a general use
pesticide shall be guilty of a violation and, upon conviction thereof, shall
be punished by a fine not to exceed $2,500. If the conviction is for a subsequent
offense committed after the first such conviction of such person under this
subsection, punishment shall be a fine not to exceed $5,000.




