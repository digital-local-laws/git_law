## § 114-15 Imposition of use fee.



A. Pursuant to the Vehicle and Traffic Law and §§ 1202(a)
and 1202(c) of the Tax Law, a special motor vehicle use fee on vehicle
registrations is hereby imposed on motor vehicles registered within
Tompkins County. Such fee shall be charged in accordance with the
following schedule:

(1) A fee of $10 per year for:

(a) 
All commercial motor vehicles, regardless of
weight used principally in connection with a business carried on within
Tompkins County, except when owned and used in connection with the
operation of a farm by the owner or tenant thereof.

(b) 
Passenger motor vehicles weighing more than
3,500 pounds.



(2) A fee of $5 per year for:

(a) 
Passenger motor vehicles of a type commonly
used for noncommercial purposes owned by residents of Tompkins County
and weighing 3,500 pounds or less; and





B. The fee shall be paid for all registrations and renewals
of registrations for which the registration fee is established in
§ 401(6)(a) or (7) of the Vehicle and Traffic Law.

(1) The fee shall be applicable to an original or renewal
registration transaction only, and not to a preregistration transaction.
If no fee for a registration transaction is due, no County motor vehicle
use fee shall be due on that transaction.

(2) The applicability of such fee shall be determined
based upon the information on the application for registration, as
well as any additional documentation required by the Commissioner
of Motor Vehicles.

(3) The receipt for payment of such fee may be the registration
certificate, whether or not it indicates the amount of the fee paid.




