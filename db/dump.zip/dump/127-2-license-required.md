## § 127-2 License required.


It shall be unlawful for any person, except as provided in § 127-3
below, within the county limits to act as a hawker, peddler or solicitor or
to conduct a transient business as herein defined without first having obtained
and paid for, and having in force and effect, a license therefor.
