## § 17-4 Assumption of powers and duties of officer by emergency interim successor.


If, in the event of an attack or a public disaster, an officer described
in Subsection A or Subsection B of § 17-3 of this chapter, or his
duly authorized deputy, if any, is unable, due to death, absence from the
county, or other physical, mental or legal reasons, to perform the powers
and duties of the office, the emergency interim successor of such officer
highest in rank in order of succession who is able to perform the powers and
duties of the office shall, except for the power and duty to discharge or
replace duly authorized deputies and emergency interim successors of such
officer, perform the powers and duties of such officer. An emergency interim
successor, acting Chairman of the Board of Supervisors or Deputy Chairman
of the Board of Supervisors shall perform such powers and duties only until
such time as the lawful incumbent officer or his duly authorized deputy, if
any, resumes the office or undertakes the performance of the powers and duties
of the office, as the case may be, or until, where an actual vacancy exists,
a successor is duly elected or appointed to fill such vacancy and qualifies
as provided by law.
