## § 19-2 Notice of meeting.


Notice of the meeting at which the Board will
consider the determination that a particular parcel is no longer needed
for public use shall be advertised in the official newspapers 10 days
in advance of the meeting.
