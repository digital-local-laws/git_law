## § 4-3 Powers and duties.


The duties of said office shall be to:

A. Plan environmental and personal services to meet the
needs of the elderly population through the evaluation of services and the
identification of major problems affecting the elderly.

B. Stimulate and review needed programs and services for
the elderly.

C. Conduct research on the needs of the elderly in this
community and develop alternative means of meeting these needs.

D. Cooperate with elderly citizens and organizations servicing
or representing the elderly to meet the needs of the elderly population of
the community.

E. Provide information relative to programs and services
for the elderly in the community and sources of support for programs and services.

F. Encourage the cooperation of agencies servicing the elderly.

G. Recommend to and cooperate with federal, state and local
agencies in the development of public policy toward the elderly.

H. Contract with existing agencies or such new ones as may
be appropriate for new or increased services where federal, state or local
funding may be available.

I. When and if indicated, undertake on an interim or continuing
basis specific programs or services.


