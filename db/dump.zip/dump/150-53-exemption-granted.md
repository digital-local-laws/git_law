## § 150-53 Exemption granted.


Pursuant to § 459-a of the Real Property
Tax Law, there shall be an exemption from taxation for real property
altered, installed or improved subsequent to the Americans With Disabilities
Act of 1990 for the purpose of the removal of architectural barriers
for persons with disabilities from existing property. Improvements
to such real property shall be exempt pursuant to the exemption schedule
in §459-a of the Real Property Tax Law.
