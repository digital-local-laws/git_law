## § 92-2 Authority.


The authority of this chapter shall be the exercise of the police power
for the protection of the public welfare, health and peace of the people of
this County and in fulfillment of the provisions of the County Charter concerning
civil rights.
