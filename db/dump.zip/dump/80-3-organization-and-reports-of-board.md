## § 80-3 Organization and reports of Board.


The Traffic Safety Board shall:

A. Meet and organize within fifteen days after its members
are appointed.

B. Elect annually a Chairman, Vice-Chairman and Secretary
from its membership.

C. Adopt rules for the conduct of its business.

D. Within the limit of appropriation made therefor by the
Board of Representatives, authorize the employment of such personnel as may
be necessary to properly perform the function and carry out the objectives
of this chapter.

E. Appoint an Executive Secretary, who shall be the administrative
officer of the Board.

F. Render annually to the Board of Representatives, and
from time to time as required, a verified account of all monies received and
expended by it or under its direction and an account of its proceedings and
of other pertinent matters in such form and manner as may be required by the
Board of Representatives.

G. Submit annually to the proper fiscal authorities of the
county, at such time and in such manner as may be required, an estimate of
the funds required to carry out the purpose of this chapter.

H. Submit a report of activities annually to the state and,
from time to time, such other information or reports as may be required by
the state pursuant to Article 16-a of the Executive Law.


