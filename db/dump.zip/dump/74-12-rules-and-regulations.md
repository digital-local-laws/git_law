## § 74-12 Rules and regulations.


The County Treasurer of the County of Tompkins is hereby empowered to
promulgate and amend suitable rules and regulations prescribing the necessary
forms for carrying into effect the provisions of this article relating to
the installment payment of taxes.
