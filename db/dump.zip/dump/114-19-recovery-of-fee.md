## § 114-19 Recovery of fee.


Whenever any person fails to pay the fee due
hereunder, proceedings to recover such fees, as well as any applicable
penalties and/or interest, shall be the responsibility of Tompkins
County as set forth in the agreement. A final penalty schedule shall
be subject to the approval of the Tompkins County Legislature.
