## § 140-7 Collection of regulated recyclables.



A. Authority to collect.

(1) Only persons acting under the authority of a county recycling
hauler shall collect, pick up, remove, or cause to be collected, picked up,
or removed, any recyclables placed in or adjacent to a recycling container
for collection by the county as part of a county-sponsored program.

(2) Only persons acting under the authority of a licensed
hauler shall collect, pick up, remove, or cause to be collected, any recyclables
left by the waste generator for collection by the licensed hauler.



B. Empty curbside recycling containers shall be removed
from the curbside or other place of collection by the waste generator responsible
for placing the recycling container at curbside no later than 8:00 p.m. the
day on which collection is made from the premises.

C. A licensed hauler may refuse to collect or pick up solid
waste from which the designated recyclables have not been removed. In instances
where the licensed hauler or the county recycling hauler has refused to collect
solid waste or recyclables because the recyclables have not been separated,
placed, treated or prepared in accord with the provisions of this article
and the rules and regulations promulgated hereunder, the person responsible
for initially placing those materials for collection shall remove those materials
from any curb, sidewalk, streetside or other designated collection place no
later than 8:00 p.m. the day on which collection is scheduled for the premises.

D. Nothing herein shall prevent any person from making arrangements
for the reuse, private collection, sale, or donation of recyclables; provided
that recyclables to be privately collected, sold or donated shall not be placed
curbside or at any other designated collection place on or immediately preceding
the day for scheduled collection of such recyclable materials pursuant to
a county-sponsored recycling program; and provided that all reporting requirements
of this article, rules, and regulations are complied with.


