## § 140-15 Enforcement.


The Commissioner of Public Works or his designee, in consultation with
the County Attorney, shall enforce the provisions of this article and all
rules, regulations and designations made pursuant thereto. Such enforcement
shall include but not be limited to legal or equitable proceedings, including
without limitation an action for specific performance brought in the name
of the county.
