## § 114-4 Definitions; dates.



A. As used in this article, the following terms shall
have the meanings indicated:

BILLING UNIT OR UNITS
Refers to the number assigned to each parcel of real property
pursuant to § 114-6 below and shall provide the basis for
determining the fee charged.


BOARD OF REPRESENTATIVES
The Tompkins County Board of Representatives.


COUNTY
The County of Tompkins.


COUNTY ADMINISTRATOR
The County Administrator of Tompkins County as set forth
in the Tompkins County Charter and Code.


FEE STATUS DATE
March 1 for each subsequent fiscal year.[Amended 3-1-1994 by L.L. No. 1-1994]


RATE SCHEDULE
Refers to the schedule adopted by the Board of Representatives
pursuant to § 114-5B, establishing classes and formulas
for determining billing units for parcels of improved real property.


RECYCLABLES or RECYCLABLE MATERIALS
Materials that would otherwise be solid waste, and which
can be collected, separated, and/or processed, treated, reclaimed,
used or reused so that their component materials or substances can
be beneficially used or reused.


SOLID WASTE
All putrescible and nonputrescible solid waste materials
generated or originated within the county, including but not limited
to materials or substances discarded or rejected, whether as being
spent, useless, worthless, or in excess to the owners at the time
of such discard or rejection or for any other reason; or being accumulated,
stored, or physically, chemically or biologically treated prior to
being discarded or rejected, having served their intended use; or
a manufacturing by-product, including but not limited to garbage,
refuse, waste materials resulting from industrial, commercial, community,
and agricultural activities, sludge from air or water pollution control
facilities or water supply treatment facilities, rubbish, ashes, contained
gaseous material, incinerator residue, demolition and construction
debris and offal; but not including sewage and other highly diluted
water-carried materials or substances and those in gaseous form, or
hazardous waste as defined in the law.


SOLID WASTE FEE ROLL
Refers to the listing of all parcels in the county, including
the assignment of billing units to each parcel.


UNIT CHARGE
The dollar amount established by the Board of Representatives
pursuant to § 114-5 below, as the annual solid waste fee
charged for one billing unit.


B. In the event that any date herein falls on a Saturday,
Sunday or legal holiday, then the applicable date shall be the next
succeeding date that is not a Saturday, Sunday or legal holiday.


