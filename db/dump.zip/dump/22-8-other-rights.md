## § 22-8 Other rights.


The benefits of this article shall inure only to employees as defined
herein, and shall not enlarge or diminish the rights of any other party, nor
shall any provision of this article be construed to affect, alter, or repeal
any provision of the Workers' Compensation Law.
