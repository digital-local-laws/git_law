## § 114-9 Delinquent fees.



A. Any annual solid waste fee not received by the County
Division of Budget and Finance when due shall be considered delinquent
and shall be subject to a late payment charge of 5% of the amount
of the unpaid fee, together with interest on the unpaid fee of 1%
per month. Any late payment charge and interest shall be a lien against
the parcel of property against which it accrued as of the accrual
date.

B. For all taxable parcels, any delinquent annual solid
waste fee remaining unpaid as of November 1 may be added to the ensuing
year's county tax bill for the parcel against which there is a lien.
In such case, no payments shall be accepted after the commencement
of the relevy. On or about December 1, the County Administrator shall
prepare and transmit to the Board a list of those property owners
with delinquent annual solid waste fees as of November 1, which list
shall include a brief description of the property, the names of the
persons liable to pay the same, and the amount of unpaid fees, including
late payment charges and interest through December 31. The Board shall
levy such sums against the properties liable and shall state the amount
thereof as a separate entry of annual tax rolls of the various municipalities
under the name "Relevied County Annual Solid Waste Fee." Such amount
shall be collected and enforced in accordance with § 266
of the County Law.[Amended 3-1-1994 by L.L. No. 1-1994]

C. For all nontaxable parcels (Assessment Roll Section
8). On or about December 1, the County Administrator shall prepare
a listing of those property owners with delinquent annual solid waste
fees as of November 1. These outstanding fees will not be relevied
on any tax bill, and will continue to be payable at the Tompkins County
Division of Budget and Finance. All parcels with outstanding fees
will be issued a subsequent notice of delinquency on or about January
1 which will include all penalties and interest accrued to date. This
billing shall also include notification of additional administrative
costs of $25 or 10% of the fee, whichever is greater, to be added
to all bills remaining unpaid as of February 1. Interest will continue
to accrue until fee is paid.[Added 3-1-1994 by L.L. No. 1-1994]

D. Notwithstanding the foregoing, the county shall be
entitled to commence a civil action to foreclose upon any lien upon
property in accordance with the law or collect any amount due to it.

E. For all nontaxable parcels (Assessment Roll Section
8). On or about December 1, 1993, the County Administrator shall prepare
a listing of those property owners with delinquent annual solid waste
fees as of November 1. These outstanding fees will not be relevied
on any tax bill, and will continue to be payable at the Tompkins County
Division of Budget and Finance. All parcels with outstanding fees
will be issued a subsequent notice of delinquency on or about March
1, 1994, which will include all penalties and interest as of December
31, 1993. This billing shall also include notification of additional
administrative costs of $25 or 10% of the fee, whichever is greater,
to be added to all bills remaining unpaid as of April 1, at which
time interest will resume at a rate of 1% per month until the fee
is paid.[Added 3-1-1994 by L.L. No. 1-1994]


