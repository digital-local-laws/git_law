## § 150-33 Applicability.


When determining whether a parcel qualifies
as residential or farm property, for purposes of this article, the
enforcing officer shall consider the information appearing on the
applicable tax roll. The enforcing officer shall also consider any
relevant information submitted to him or her by the Assessor, by the
owner, or by any other person with an interest in a parcel, subject
to the provisions of § 1111(3) of the Real Property Tax
Law.
