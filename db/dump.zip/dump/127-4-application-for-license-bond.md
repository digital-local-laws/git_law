## § 127-4 Application for license: bond.



A. Form, contents. Any person desiring to procure a license
as herein provided shall file with the Sheriff a written application upon
a blank form provided by the Sheriff and furnished by the county and shall
file at the same time character references from the Sheriff, Chamber of Commerce
or Better Business Bureau from three different communities where the applicant
or his firm has previously conducted a similar business endeavor. Such information
must contain the name, current address and telephone number of the references.
Such application shall give the number and kind of vehicles to be used by
the applicant in carrying on the business for which the license is desired,
the kind of goods, wares and merchandise the desires to sell or purchase or
the kind of service he desires to perform, the method of distribution, the
names, permanent and local address and age of the applicant, the name and
address of the person or firm he represents, the length of time the applicant
desires a license, and such other information as may be required by the Sheriff.

B. Accompanying documents. Such application shall be accompanied
by a certificate from the sealer of weights and measures certifying that all
weighing and measuring devices to be used by the applicant have been examined
and approved.

(1) Bonds, conditions, amount, duration. An application for
a license as a hawker, peddler, solicitor or transient business that demands,
accepts or receives a payment or deposit of money in advance of final delivery
or purchases items from individual or any entity shall also be accompanied
by a bond to the county approved as to form and security by the county attorney
in the penal sum of $1,000 with sufficient surety or sureties or sufficient
collateral security conditioned for making a final delivery of goods, wares
or merchandise ordered or services to be performed in accordance with the
term of such order, or failing therein that the advance payment of such order
be refunded, and further conditioned that in the event the purchaser stops
payment on its payment instrument or has insufficient funds to make payment
for goods purchased from individuals or entities, then, and in that event,
such bond to be used to make payment to the seller in such amount up to the
limit of the bond. It is also required that any such bond applicant will make
a full, complete and true report of the gross amount of sales made in such
business within the county in accordance with § 127-11 below and
will comply in good faith with the provisions of this chapter and in paying
the amount of taxes fixed. Any person aggrieved by the action of any licensed
hawkers, peddlers, solicitors or transient business shall have the right of
action on the bond for the recovery of money or damages, or both. Such bond
shall remain in full force and effect, and in case of a cash deposit, such
deposit shall be retained by the county for a period of 90 days after the
expiration of any such license, unless sooner released by the Sheriff.

(2) Certificate, applicability. The requirement for a certificate
of weights and measures and bond shall apply to those claiming any one of
the exemptions under § 127-3.




