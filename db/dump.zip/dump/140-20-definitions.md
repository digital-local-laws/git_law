## § 140-20 Definitions.


As used in this article, the following terms shall have the meanings
indicated:

ACCEPTABLE SOLID WASTE
All solid waste generated, originated or brought within the county
other than waste that is defined herein as hazardous waste, unregulated recyclable
materials, regulated recyclable materials, or unacceptable waste. Acceptable
solid waste excludes solid waste traveling through the county while being
transported from a place outside the county to a destination outside the county.


BELOW REGULATORY CONCERN RADIOACTIVE WASTE
Radioactive waste that has been deregulated or is not regulated by
the United States Environmental Protection Agency or Nuclear Regulatory Commission,
or the New York State Department of Health or Environmental Conservation.


BOARD OF REPRESENTATIVES
The Tompkins County Board of Representatives.


COMMISSIONER
The Commissioner of the Department of Public Works of Tompkins County
or designee thereof.


COUNTY
The County of Tompkins.


FACILITY
Any solid waste management or resource recovery facility employed
beyond the initial solid waste collection process that is to be used, occupied
or employed for or is incidental to the receiving, transporting, storage,
processing, or disposal of solid waste or the recovery by any means of any
material or energy product or resource therefrom, including but not limited
to recycling centers, transfer stations, processing systems, resource recovery
facilities, sanitary landfills, plants and facilities for composting or landspreading
of solid wastes, secure land burial facilities, reprocessing and recycling
facilities, reuse facilities, surface impoundments and waste oil storage,
incinerators and other solid waste disposal, reduction or conversion facilities.


HAZARDOUS WASTE

A. 
Any waste that by reason of its quality, concentration, composition
or physical, chemical or infectious characteristics may do any of the following:
cause or significantly contribute to an increase in mortality or an increase
in serious irreversible, or incapacitating reversible illness; or pose a substantial
threat or potential hazard to human health or the environment when improperly
treated, stored, transported or disposed of or otherwise mismanaged; or any
waste that is defined or regulated as a hazardous waste, toxic substance hazardous
chemical substance or mixture, or asbestos under applicable law, as amended
from time to time including, but not limited to:

B. 
The Resource Conservation and Recovery Act, 42 U.S.C. § 6901
et seq. and the regulations contained in 40 CFR Parts 260-281;

C. 
The Toxic Substances Control Act, 15 U.S.C. § 2601 et seq.
and the regulations contained in 40 CFR Parts 761-766;

D. 
Future additional or substitute federal, state or local laws pertaining
to the identification, treatment, storage or disposal of toxic substances
or hazardous waste; except that hazardous waste shall not include household
hazardous waste which is accorded treatment as other than hazardous waste
under applicable law;

E. 
Radioactive materials that are source, special nuclear or by-product
material as defined by the Atomic Energy Act of 1954, 42 U.S.C. § 2011
at seq. and the regulations contained in 10 CFR Part 40;

F. 
Below regulatory concern radioactive waste; or

G. 
Solid waste so designated by the rules and regulations promulgated pursuant
to this article.




PERSON
Any natural person, partnership, association, joint venture, corporation,
estate, trust, association, county, city, town, village, improvement district,
governmental entity or other legal entity.


RECYCLING or RECYCLED
Any method, technique or process utilized to separate, process, modify,
convert, treat or otherwise prepare solid waste so that its component materials
or substances may be beneficially used or reused.


REGULATED RECYCLABLE MATERIALS
Materials separated or required to be separated from the waste stream
pursuant to a mandatory source separation law adopted by the county pursuant
to § 120-aa of the General Municipal Law.


SOLID WASTE
All putrescible and nonputrescible solid wastes, including but not
limited to materials or substances discarded or rejected whether as being
spent, useless, worthless or in excess to the owners at the time of such discard
or rejection, or that are being accumulated, stored, or physically, chemically
or biologically treated prior to being discarded or rejected, having served
their intended use, or that are a manufacturing by-product, including but
not limited to garbage, refuse, industrial, commercial and agricultural waste,
sludges from air or water pollution control facilities or water supply treatment
facilities, rubbish, ashes, contained gaseous material, incinerator residue,
demolition and construction debris and offal, but not including sewage and
other highly diluted water-carried materials or substances and those in gaseous
form, or hazardous waste as defined in this article, or any unregulated recyclable
materials, but shall include regulated recyclable materials.


SPECIFIED FACILITY OR FACILITIES
A facility or facilities for certain solid waste specified by the
Board of Representatives pursuant to § 140-21 of this article.


UNACCEPTABLE WASTE
Sludges from air treatment facilities, industrial wastewater sludges
that are actual point source discharges, foundry sand, loads of fly and bottom
ash, discarded automobiles or major components thereof, large items of machinery
and equipment from commercial sources, offal, regulated infectious or medical
waste, domestic sewage, in-situ mining residues, below regulatory concern
radioactive waste, and other solid waste so designated by the rules and regulations
promulgated pursuant to this article.


UNREGULATED RECYCLABLE MATERIALS
Scrap or other material of value separated from the waste stream
and held for purposes of material recycling, including but not limited to
manufacturing by-products of value, but not including materials separated
from or required to be separated from the waste stream pursuant to a mandatory
source separation law adopted by the county pursuant to § 120-aa
of the General Municipal Law.

