## § 90-1 Authorization to seize and impound dogs.


The Tompkins County Society for the Prevention of Cruelty to Animals
is hereby authorized and directed to seize and impound dogs in violation of
Orders of the Commissioner of Agriculture and Markets under § 115
and/or § 115-a of the Agriculture and Markets Law[1] whenever orders of the Commissioner are in effect.
[1]:
Editor's Note: Sections 115 and 115-a were repealed by L. 1978, c.
220, § 1. See now § 123 of the Agriculture and Markets
Law.
