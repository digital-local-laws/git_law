## § 150-18 Payment of tax.


At the time of filing a return of occupancy
and of rents, each operator shall pay to the County Administrator
the taxes imposed by this article upon rents required to be included
in such return, as well as all other moneys collected by the operator
acting or purporting to act under the provisions of this article.
Where the County Administrator deems it necessary to protect revenues
to be obtained under this article, any operator required to collect
the tax imposed by this article may be required to file a bond, issued
by a surety company authorized to transact business in this state
and approved by the Superintendent of Insurance of this state as to
solvency and responsibility, in such amount as the County Administrator
may fix to secure the payment of any tax and/or penalties and interest
due or which may become due from such operator. In the event that
the County Administrator determines that an operator is to file such
a bond, notice to the operator shall be given to that effect, specifying
the amount of the bond required. The operator shall file the bond
within five days after the giving of notice unless within those five
days the operator requests, in writing, a hearing before the County
Administrator, at which the necessity, propriety, and amount of the
bond shall be determined by the County Administrator. This determination
shall be final and shall be complied with within 15 days after the
giving of notice thereof. In lieu of a bond, securities approved by
the County Administrator or cash in the amount prescribed may be deposited
into the custody of the County Administrator, who may at any time,
without notice to the depository, apply them to any tax and/or interest
or penalties due, and for that purpose the securities may be sold
at public or private sale without notice to the depositor thereof.
