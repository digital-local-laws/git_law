## § 15-9 Expenses.


Actual and necessary expenses incurred by this Board and its members
in the performance of duties imposed upon it or its members shall be a charge
on the county and shall be audited, levied and paid in the same manner as
other county charges, within limits of the appropriations therefor.
