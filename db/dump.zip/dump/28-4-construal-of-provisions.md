## § 28-4 Construal of provisions.


Nothing herein shall be so construed as to create any vacancies
in any public office.
