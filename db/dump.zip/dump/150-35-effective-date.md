## § 150-35 Effective date.


This article shall take effect immediately upon
the filing of a copy with the Secretary of State, but not earlier
than January 1, 1995. This article shall also be filed with the State
Board of Equalization and Assessment within 30 days after the enactment
thereof.
