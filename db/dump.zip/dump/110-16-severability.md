## § 110-16 Severability.


If any portion of this article thereof is found
to be invalid, no other portion of this article shall be affected
thereby, and the remainder of this article shall remain in full force
and effect.
