## § 114-16 Exemptions.



A. The fee imposed by this article shall not be imposed
upon any vehicle exempt from the registration fee pursuant to the
Vehicle and Traffic Law.

B. The fee imposed by this article shall not be imposed
upon nonprofit religious, charitable, or educational organizations
qualified for exemption with the New York State Department of Taxation
and Finance.


