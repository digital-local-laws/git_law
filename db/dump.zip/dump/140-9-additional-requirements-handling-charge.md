## § 140-9 Additional requirements; handling charge.



A. No person shall bring into any county solid waste management
facilities any waste materials from which regulated recyclables have not been
source separated. If a person delivers to a county-owned or operated solid
waste management facility solid waste from which regulated recyclables have
not been properly separated, the county may, at its option, refuse to accept
the load of solid waste, or accept the solid waste and charge the person a
handling charge. The handling charge shall be $25 per load for any person
delivering under a residential permit and $100 per load for all others, in
addition to the regular tipping fee. The handling fee shall be collected in
the same manner and subject to the same conditions as the regular tipping
fee.

B. Licensed haulers shall deliver county-supplied recycling
containers to the haulers' customers, to the extent required by any county-sponsored
recycling program.

C. The county shall supply county recycling haulers and
licensed haulers with notice forms that the hauler must use to notify its
customers if solid waste or recyclables left for collection do not conform
or comply with the requirements of this article and the rules and regulations
promulgated hereunder.

D. Licensed haulers shall indemnify and hold harmless Tompkins
County for any pending, threatened or actual claims, liability or expenses
arising from collection, transport, handling and disposal by the licensed
hauler in violation of this article.


