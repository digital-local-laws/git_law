## § 92-1 Purpose.



A. The County Legislature reaffirms that the County has
the responsibility to act to assure that every individual within the County
is afforded an equal opportunity to enjoy a full and productive life, and
that the failure to provide such equal opportunity, whether because of discrimination,
prejudice, intolerance or inadequate education, training, housing or health
care, not only threatens the rights and proper privileges of its inhabitants,
but menaces the institutions and foundations of a free democratic state and
threatens the peace, order, health, safety and general welfare of the state
and its inhabitants. The County Legislature wishes to provide a method of
redress for discrimination based on gender identity and expression and on
sexual orientation with remedies and damages to be awarded commensurate with
relief awarded to other protected groups.

B. The Legislature's purpose is to ensure that individuals
who live in our free society have the capacity to make their own choices,
follow their own beliefs and conduct their lives as they see fit, consistent
with existing law.


