## § 140-19 Legislative findings.



A. The county currently owns and operates a transfer station
and anticipates owning and contracting for the operation of a transfer station
in the foreseeable future.

B. Requiring the delivery of all acceptable solid waste
to a designated facility or facilities allows the county to ensure that regulated
recyclable materials are being separated from solid waste and that solid waste
does not contain hazardous waste or other harmful products.

C. By requiring the delivery of acceptable solid waste to
a designated facility or facilities, the county can ensure that solid waste
is disposed of in an environmentally safe manner and at an environmentally
safe location.

D. Requiring the delivery of all acceptable solid waste
to a designated facility or facilities allows the county to accurately determine
the quantity of solid waste generated in the county, and thereby allows the
county to plan accordingly and to accurately meet reporting requirements.

E. By requiring the delivery of acceptable solid waste to
a designated transfer station, the county can ensure that the waste is loaded
into vehicles suitable for economical and environmentally sound transportation.

F. By requiring the delivery of solid waste to a particular
facility or facilities, the county can collect fees from the producers of
solid waste, and thereby encourage the reduction of solid waste.

G. Solid waste that is loaded into transfer trailers at
a transfer station for shipment may economically travel a greater distance
than solid waste which is not reloaded at a transfer station, and, therefore,
the reloading of solid waste encourages and facilitates the transportation
of solid waste in interstate commerce.


