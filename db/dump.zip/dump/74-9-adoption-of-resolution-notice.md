## § 74-9 Adoption of resolution; notice.



A. On and after the effective date of this article, the
Town Board of any town may determine, in accordance with § 973 of
the Real Property Tax Law, that thereafter and until such action be duly rescinded,
the amount of taxes for county, town and special district purposes constituting
in the aggregate an amount in excess of $50 levied by the County Board of
Representatives pursuant to law upon any parcel of real property situate within
such town, may be paid in installments as provided herein.

B. Whenever a resolution has been adopted pursuant to this
section, the notice required to be given by the collecting officer pursuant
to §§ 920 and 1322 of the Real Property Tax Law shall state
that taxes may be paid in installments as provided by this article. Warrants
for the collection of taxes levied while such resolution continues in force
shall contain appropriate directions for the collection of taxes in the manner
specified by this article.


