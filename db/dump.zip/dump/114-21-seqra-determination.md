## § 114-21 SEQRA determination.


This Legislature, being the State Environmental
Quality Review Act (SEQRA) lead agency, hereby finds and determines
that this article constitutes a Type II action pursuant to §§ 617.13(D)(15)
and 617.13(D)(21) of Volume 6 of the New York Code of Rules and Regulations
(NYCRR) and within the meaning of § 8-0109(2) of the New
York Environmental Conservation Law, as routine or continuing agency
administration and management, not including new programs or major
reordering of priorities. Therefore, no further environmental review
is necessary.
