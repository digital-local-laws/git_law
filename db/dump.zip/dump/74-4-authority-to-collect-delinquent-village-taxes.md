## § 74-4 Authority to collect delinquent village taxes.


The County of Tompkins shall have the same authority to collect such
village delinquent taxes and shall use the same proceedings as used for the
collection of delinquent county taxes, including foreclosure pursuant to the
Real Property Tax Law.
