## § 87-2 Parking.



A. Parking stations. The County may establish public parking
stations at the Airport. Vehicles and equipment shall not be parked at the
Airport other than in the locations and under conditions as may be specified
by the County.

B. Fees. The County may establish hourly, daily, weekly,
and monthly parking-area fees for motor and other vehicles of any and all
types where not provided in lease agreements.

C. Rental vehicles. Rental vehicles, if allowed by contract,
shall park in accordance with provision of the contract.

D. Taxicabs, limousines, and buses. Any owner or operator
of a taxicab, limousine, bus or other vehicle shall use only designated areas
of the Airport for conducting business.


