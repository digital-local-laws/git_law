## § 80-5 Executive Secretary of Board.


The Executive Secretary of the Board shall:

A. Subject to the supervision and control of the Board,
perform the functions necessary to properly and efficiently carry out the
provisions and purposes of this chapter.

B. Be a citizen of the United States.

C. Receive such salary and expenses as the Board of Representatives
may fix and properly account for such expenses.

D. Furnish an official undertaking in an amount and in such
form and with such sureties as shall be approved by the Board of Supervisors.


