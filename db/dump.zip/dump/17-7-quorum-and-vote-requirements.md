## § 17-7 Quorum and vote requirements.


In the event of an attack or a public disaster, the Chairman of the
Board of Supervisors, Acting Chairman of the Board of Supervisors or Deputy
Chairman of the Board of Supervisors may suspend quorum requirements for the
Board of Supervisors. If quorum requirements are suspended, any local law,
ordinance, resolution or other action requiring enactment, adoption or approval
by an affirmative vote of a specified proportion of members may be enacted,
adopted or approved by the affirmative vote of the specified proportion of
those voting thereon.
