## § 28-2 Districts enumerated.



A. The County of Tompkins be and hereby is divided into Districts which
shall be made up of municipalities, or portions thereof, as described
hereafter.





Legislative
District Number


Description






1


Part of the City of Ithaca




2


Part of the City of Ithaca




3


Part of the City of Ithaca




4


Part of the City of Ithaca




5


Town of Ulysses; part of the Town of Ithaca; and part of the
Town of Enfield




6


Part of the Town of Lansing




7


Town of Caroline; Town of Danby and part of the Town of Ithaca




8


Town of Newfield; and part of the Town of Enfield




9


Town of Groton; part of the Town of Dryden; and part of the
Town of Lansing




10


Village of Lansing; Village of Cayuga Heights; and part of the
Town of Ithaca




11


Part of the Town of Ithaca




12


Part of the Town of Ithaca




13


Part of the Town of Dryden




14


Part of the Town of Dryden






B. Description of district boundaries.

(1) District No. 1. Part of the City of Ithaca described as follows:

(a) 
Beginning at a monument marking the former southwest corner
of the corporate limits of the City of Ithaca, also known as the southwest
corner of "DeWitt location," located approximately 315 feet west of
the center line of Floral Avenue, on the corporate limits; thence
running easterly along the south line of the corporate limits a distance
of 1,728 feet, to a point on the City of Ithaca corporate limits;
thence along the western and southern corporate limits a distance
of 15,816 feet, more or less, to a point on the City of Ithaca corporate
limits, which is the northwesterly corner of said Tax Parcel 503089-40.-3-3
(Tax Role Status 2011); thence northeasterly across Tax Parcel 500700-106.-1-8
(Tax Role Status 2011) a distance of approximately 615 feet, to the
southerly end of the center line of South Cayuga Street; thence northerly
along the center line of South Cayuga Street a distance of approximately
1,480 feet to the southern end of North Cayuga Street; thence northerly
along the center line of North Cayuga Street a distance of approximately
1,840 feet to the intersection with Cascadilla Creek; thence westerly
and northwesterly along the center line of Cascadilla Creek a distance
of 4,458 feet, more or less, to the intersection with the center line
of Cayuga Inlet; thence northerly along the center line of Cayuga
Inlet, and as extended, to the north line of the City of Ithaca a
distance of 5,523 feet, more or less; thence westerly along the north
line of the City of Ithaca a distance of 3,420 feet, more or less,
to a point on the west shore of Cayuga Lake; thence southeasterly
along the line of the corporate limits of the City of Ithaca as it
twists and turns a distance of 4,613 feet, more or less; thence westerly
along the City of Ithaca corporate limits a distance of 2,587 feet,
more or less; thence southwesterly along the City of Ithaca corporate
limits, which is also the center line of Williams Brook, a distance
of 331 feet, more or less; thence southerly along the western line
of the corporate limits of the City of Ithaca a distance of 9,800
feet, more or less, to the point and place of beginning.



(2) District No. 2. Part of the City of Ithaca described as follows:

(a) 
Beginning at a point of intersection of the center lines of
Linn Street, University Avenue and Cascadilla Creek; thence easterly
along the center line of Cascadilla Creek a distance of 1,490 feet,
more or less, to a point of intersection with the center line of Stewart
Avenue; thence northeasterly along the center line of Stewart Avenue
a distance of 1,943 feet; thence northeasterly along the northwest
face of Carl Becker House, a building on Cornell University campus,
a distance of 330 feet, more or less, to the northeast corner of Carl
Becker House; thence southeasterly along the westernmost edge of the
access road located east of Carl Becker House a distance of 294 feet,
more or less, to a point; thence easterly along a line which is also
the north face of Mennen Hall a distance of 222 feet, more or less,
to a point of intersection with the center line of West Avenue; thence
northerly along the center line of West Avenue a distance of 530 feet,
more or less, to a point of intersection of the center lines of University
Avenue and McGraw Place; thence northerly along the center line of
University Avenue a distance of 1,924 feet, more or less, to a point
of intersection with the center line of Thurston Avenue; thence northerly
along the center line of Thurston Avenue a distance of 760 feet, more
or less, to a point of intersection of the center line of Wait Avenue;
thence northeasterly and northwesterly along the center line of Wait
Avenue a distance of 621 feet, more or less, to a point of intersection
with the center line of Triphammer Road; thence northeasterly along
the center line of Triphammer Road a distance of 303 feet, more or
less, to the of intersection with the center line of Sisson Place;
thence easterly along the center line of Sisson Place a distance of
1,012 feet, more or less, to the intersection with the center line
of Robert Purcell Community Center access road; thence southeasterly
a distance of 168 feet, more or less, to the northwestern corner of
Mews Hall; thence southeasterly along the northern face of Mews Hall
a distance of 225 feet, more or less, to the northeast corner of Mews
Hall; thence northeasterly a distance of 250 feet, more or less, to
the southern end of Sisson Place Extension; thence northeasterly along
the center line of Sisson Place Extension a distance of 277 feet,
more or less, to the intersection with the eastern boundary of the
City of Ithaca; thence northerly along the eastern boundary of the
City of Ithaca a distance of 403 feet, more or less, to the northeast
corner of the corporate limits of the City of Ithaca, where the Village
of Cayuga Heights and the Town of Dryden boundaries meet; thence westerly
along the north line of the City of Ithaca a distance of 9,087 feet,
more or less, to a point of intersection with the east line of North
Cayuga Street, a corner of the City of Ithaca boundary; thence northerly
along the corporate limit of the City of Ithaca a distance of 4,705
feet, more or less, to the most northerly, northeast corner of the
corporate limits of the City of Ithaca, which is on the east shore
of Cayuga Lake; thence westerly across Cayuga Lake a distance of 4,430
feet, more or less, to the approximate center of Cayuga Lake, which
said point is on a line due north of the center line of Cayuga Inlet;
thence southerly along the center line of the Cayuga Inlet, as extended,
and along the actual center line of the Cayuga Inlet a distance of
7,500 feet, more or less, to a point of intersection with the center
line of Cascadilla Creek; thence easterly and southeasterly along
the center line of Cascadilla Creek a distance of 6,070 feet, more
or less, to the intersection to a point of intersection of the south
line of Cascadilla Creek and the center line of North Cayuga Street;
thence northerly along the center line of North Cayuga Street a distance
of 111 feet, more or less, to a point of intersection with the center
line of Farm Street; thence easterly along the center line of Farm
Street a distance of 1,239 feet, more or less, to a point of intersection
with the center line of Linn Street; thence southerly along the center
line of Linn Street a distance of 707 feet, more or less, to the point
of beginning.



(3) District No. 3. Part of the City of Ithaca described as follows:

(a) 
Beginning at a point in the south corporate limits of the City
of Ithaca at its intersection with the center line of East State Street
(New York State Route 79); thence easterly along the south corporate
limit of the City of Ithaca a distance of 260 feet, more or less,
to a monument marking the southeast corner in the corporate limits
of the City of Ithaca; thence northerly along the east line of the
City of Ithaca a distance of 10,966 feet, more or less, to the intersection
with Sisson Place Extension, a road on the Cornell University campus;
thence southwesterly along the center line of Sisson Place Extension
a distance of 277 feet, more or less, to the southern end of Sisson
Place Extension; thence southwesterly a distance of 250 feet, more
or less, to the northeast corner of Mews Hall; thence northwesterly
along the northern face of Mews Hall a distance of 225 feet, more
or less, to the northwest corner of Mews Hall; thence northwesterly
a distance of 168 feet, more or less, to the intersection of the center
lines of Robert Purcell Community Center access road and Sisson Place;
thence westerly along the center line of Sisson Place a distance of
1,012 feet, more or less, to the intersection with the center line
of Triphammer Road; thence southerly and southwesterly along the center
line of Triphammer Road a distance of 303 feet, more or less, to a
point of intersection with the center line of Wait Avenue; thence
southeasterly and southwesterly along the center line of Wait Avenue
a distance of 621 feet, more or less, to a point of intersection with
the center line of Thurston Avenue; thence southerly along the center
line of Thurston Avenue a distance of 760 feet, more or less, to a
point of intersection of the center lines of Forest Home Drive and
University Avenue; thence westerly and southwesterly along the center
line of University Avenue a distance of 1,924 feet, more or less,
to a point of intersection of the center lines of McGraw Place and
West Avenue; thence southerly and southeasterly along the center line
of West Avenue a distance of 1,212 feet, more or less, to a point
of intersection with the center line of Campus Road; thence southeasterly
along the center line of Campus Road a distance of 800 feet, more
or less, to a point of intersection with Central Avenue; thence southeasterly
along Central Avenue a distance of 799 feet, more or less, to a point
of intersection with the center line of College Avenue; thence southeasterly
along the center line of Campus Road a distance of 800 feet, more
or less, to a point of intersection with the center line of Central
Avenue; thence southerly along the center line of Central Avenue a
distance of 960 feet, more or less, to a point of intersection with
the center line of Oak Avenue; thence easterly along the center line
of Oak Avenue a distance of 569 feet, more or less, to a point of
intersection with the center line of Summit Avenue; thence southerly
along the center line of Summit Avenue extended a distance of 409
feet, more or less, to a point of intersection with the center line
of Dryden Road; thence westerly along the center line of Dryden Road
a distance of 325 feet, more or less, to a point of intersection with
the center line of Linden Avenue; thence southerly along the center
line of Linden Avenue a distance of 838 feet, more or less, to a point
of intersection with the center line of Bool Street; thence westerly
along the center line of Bool Street a distance of 267 feet, more
or less, to a point of intersection with the center line of College
Avenue; thence southerly along the center line of College Avenue a
distance of 614 feet, more or less, to a point of intersection with
the center line of Mitchell Street (New York State Route 336); thence
southwesterly along the center line of Mitchell Street (New York State
Route 336) a distance of 306 feet, more or less, to a point of intersection
with the center line of East State Street; thence northwesterly along
the center line of East State Street a distance of 2,126 feet, more
or less, to a point of intersection with the center line of East Green
Street (New York Route 79E); thence southwesterly along the center
line of East Green Street (New York Route 79E) a distance of 430 feet,
more or less, to the intersection with the center line of South Aurora
Street; thence southwesterly a distance of 40 feet, more or less,
to the intersection with the center line of Six Mile Creek; thence
southeasterly along the center line of Six Mile Creek a distance of
1,660 feet, more or less, to the intersection with the center line
of South Cayuga Street; thence southerly along South Cayuga Street
a distance of 1,200 feet, more or less, to the southern end of the
center line of South Cayuga Street; thence southwesterly across Tax
Parcel 500700-106.-1-8 (Tax Role Status 2011) a distance of approximately
615 feet to a point of intersection with the City of Ithaca corporate
limits, which is the northwesterly corner of said Tax Parcel 503089-40.-3-3
(Tax Role Status 2011); thence easterly along the southerly boundary
of the City of Ithaca corporate limits, as it twists and turns, a
distance of 9,000 feet, more or less, to the point and place of beginning.



(4) District No. 4. Part of the City of Ithaca described as follows:

(a) 
Beginning at a point on the center line of Cascadilla Creek
at the point of intersection with the center line of Stewart Avenue;
thence running northeasterly along the center line of Stewart Avenue
a distance of 1,943 feet, more or less, to a point on the center line
of Stewart Avenue, which is the northeasterly corner of the face of
Carl Becker House, a building on the Cornell University Campus; thence
southeasterly along the westernmost edge of the access road located
east of Carl Becker House a distance of 294 feet, more or less, to
a point; thence easterly along a line which is also the north face
of Mennen Hall a distance of 222 feet, more or less, to a point of
intersection with the center line of West Avenue; thence southerly
along the center line of West Avenue a distance of 636 feet, more
or less, to a point of intersection with the center line of Campus
Road; thence southeasterly along the center line of Campus Road a
distance of 800 feet, more or less, to a point of intersection with
the center line of College Avenue; thence southerly along the center
line of College Avenue a distance of 960 feet, more or less, to a
point of intersection with the center line of Oak Avenue; thence easterly
along the center line of Oak Avenue a distance of 569 feet, more or
less, to a point of intersection with the center line of Summit Avenue;
thence southerly along the center line of Summit Avenue a distance
of 409 feet, more or less, to a point of intersection with the center
line of Dryden Road; thence westerly along the center line of Dryden
Road a distance of 325 feet, more or less, to a point of intersection
with the center line of Linden Avenue; thence southerly along the
center line of Linden Avenue a distance of 838 feet, more or less,
to a point of intersection with the center line of Bool Street; thence
westerly along the center line of Bool Street a distance of 267 feet,
more or less, to a point of intersection with the center line of College
Avenue; thence southerly along the center line of College Avenue a
distance of 614 feet, more or less, to a point of intersection with
the center line of Mitchell Street; thence southwesterly along the
center line of Mitchell Street a distance of 306 feet, more or less,
to a point of intersection with the center line of East State Street
(New York Route 79E); thence northwesterly along the center line of
East State Street (New York Route 79E) a distance of 2,126 feet, more
or less, to a point of intersection with the center line of East Green
Street (New York Route 79E); thence southwesterly along the center
line of East Green Street (New York Route 79E) a distance of 430 feet,
more or less, to the intersection with the center line of South Aurora
Street; thence southeasterly a distance of 40 feet, more or less,
to the intersection with the center line of Six Mile Creek; thence
southwesterly along the center line of Six Mile Creek a distance of
1,660 feet, more or less, to the intersection with the center line
of South Cayuga Street; thence northerly along the center line of
South Cayuga Street a distance of 1,480 feet, more or less, to the
southern end of North Cayuga Street; thence northerly along the center
line of North Cayuga Street a distance of 1,951 feet, more or less,
to the intersection with the center line of Farm Street; thence easterly
along the center line of Farm Street a distance of 1,239 feet, more
or less, to a point of intersection with the center line of Linn Street;
thence southerly along the center line of Linn Street a distance of
707 feet, more or less, to the intersection with the center line of
Cascadilla Creek; thence easterly along the center line of Cascadilla
Creek a distance of 1,490 feet, more or less, to the point of beginning.



(5) District No. 5. All of the Town of Ulysses and those parts of the
Town of Enfield and Town of Ithaca described as follows:

(a) 
Beginning at the northwesterly corner of the Town of Enfield
where it adjoins the Town of Ulysses; thence southerly along the westerly
boundary of the Town of Enfield a distance of approximately 9,332
feet, more or less, to the intersection of the center lines of Buck
Hill Road North and Mecklenburg Road (New York State Route 79); thence
easterly along the center line of Mecklenburg Road (New York State
Route 79) a distance of approximately 6.2 miles to the intersection
of Sheffield Road, which is also the westerly boundary of the Town
of Ithaca; thence northerly along the center line of Sheffield Road
a distance of approximately 2.4 miles to the northeasterly corner
of the Town of Enfield; thence westerly along the center line of Iradell
Road, which is also the northerly boundary of the Town of Enfield,
a distance of approximately 6.1 miles to the point of beginning.

(b) 
Beginning at the northwesterly corner of the Town of Ithaca;
thence southerly along the center line of Sheffield Road, which is
also the westerly boundary of the Town of Ithaca, a distance of 7,457
feet, more or less, to the intersection with Bundy Road; thence easterly
along the center line of Bundy Road a distance of approximately 2.16
miles to the intersection with the center line of Trumansburg Road
(New York Route 96); thence southeasterly along the center line of
Trumansburg Road (New York Route 96) a distance of 2,770 feet, more
or less, to the corporate limits of the City of Ithaca; thence easterly
along the corporate limits of the City of Ithaca a distance of 1,033
feet, more or less, to the southeasterly corner of Tax Parcel 503089-26.-4-3
(Tax Role Status Year 2011); thence north and northwesterly along
the corporate limits of the City of Ithaca and in part along Taughannock
Boulevard (New York State Route 89) a distance of 4,441 feet, more
or less, to the northwesterly corner of the most northerly boundary
of the City of Ithaca, a point on the west shore of Cayuga Lake; thence
easterly along the north boundary of the City of Ithaca and across
Cayuga Lake a distance of 3,420 feet, more or less, to the approximate
center of Cayuga Lake, which said point is on a line due north of
the center line of Cayuga Inlet; thence northwesterly along the approximate
center line of Cayuga Lake a distance 5,717 feet, more or less, to
the southeasterly corner of the Town of Ulysses; thence westerly along
the southerly boundary of Town of Ulysses a distance of approximately
2.7 miles to the point of beginning.



(6) District No. 6. All of the Town of Lansing, excluding all of the
Village of Lansing and excluding the part of the Town of Lansing described
as follows:

(a) 
Beginning in the northeasterly corner of the Town of Lansing;
thence southerly along the easterly boundary of the Town of Lansing
a distance of approximately 6.1 miles to the intersection with the
center line of Peruville Road; thence westerly along the center line
of Peruville Road a distance of 3,700 feet, more or less, to the intersection
with the center line of Van Ostrand Road; thence northerly along the
center line of Van Ostrand Road approximately 4.4 miles to the intersection
with the center line of North Lansing School Road; thence westerly
along the center line of North Lansing School Road a distance of 1,992
feet, more or less, to the intersection with the center line of Breed
Road; thence northerly along the center line of Breed Road a distance
of approximately 1.7 miles to the intersection with the center line
of Weeks Road, which is the northerly boundary of the Town of Lansing;
thence easterly along the center line of Weeks Road a distance of
approximately 1.0 mile to the point of beginning.



(7) District No. 7. All of the Town of Caroline and all of the Town of
Danby, and that part of the Town of Ithaca described as follows:

(a) 
Beginning at the intersection of the center line of Danby Road
(New York State Route 96B) and the southerly boundary of the Town
of Ithaca; thence easterly along the southerly boundary of the Town
of Ithaca a distance of approximately 1.2 miles to the center line
of Troy Road; thence northerly a distance of 3,054 feet, more or less,
to the intersection with the center line of East King Road; thence
westerly along the center line of East King Road a distance of approximately
1.4 miles to the intersection with the center line of Danby Road (New
York State Route 96B); thence westerly and southerly along the center
line of West King Road a distance of approximately 1.9 miles to the
southerly boundary of the Town of Ithaca; thence easterly along the
southerly boundary of the Town of Ithaca a distance of approximately
1.2 miles to the point of beginning.



(8) District No. 8. All of the Town of Newfield and that part of the
Town of Enfield described as follows:

(a) 
Beginning at the southwesterly corner of the Town of Enfield;
thence easterly along the southerly boundary of the Town of Enfield
a distance of approximately 6.1 miles to the southeasterly corner
of the Town of Enfield; thence northerly along the easterly boundary
of the Town of Enfield a distance of approximately 3.7 miles to the
intersection of the center lines of Mecklenburg Road (New York State
Route 79) and Sheffield Road; thence westerly along the center line
of Mecklenburg Road (New York State Route 79) a distance of approximately
6.2 miles to the intersection Buck Hill Road South, which is the westerly
boundary of the Town of Enfield; thence southerly along the westerly
boundary of the Town of Enfield a distance of approximately 4.3 miles
to the point of beginning.



(9) District No. 9. All of the Town of Groton and those parts of the
Town of Lansing and the Town of Dryden described as follows:

(a) 
Beginning in the northeasterly corner of the Town of Lansing;
thence southerly along the easterly boundary of the Town of Lansing
a distance of approximately 6.1 miles to the intersection with the
center line of Peruville Road; thence westerly along the center line
of Peruville Road a distance of 3,700 feet, more or less, to the intersection
with the center line of Van Ostrand Road; thence northerly along the
center line of Van Ostrand Road approximately 4.4 miles to the intersection
with the center line of North Lansing School Road; thence westerly
along the center line of North Lansing School Road a distance of 1,992
feet, more or less, to the intersection with the center line of Breed
Road; thence northerly along the center line of Breed Road a distance
of approximately 1.7 miles to the intersection with the center line
of Weeks Road, which is the northerly boundary of the Town of Lansing;
thence easterly along the center line of Weeks Road a distance of
approximately 1.0 mile to the point of beginning.

(b) 
Beginning in the northeasterly corner of the Town of Dryden;
thence westerly along the northerly boundary of the Town of Dryden
a distance of approximately 4.2 miles to the intersection with the
center line of Ed Hill Road; thence southerly and easterly 6,570 feet,
more or less, along the center line of Ed Hill Road to the intersection
with the center line of Hile School Road; thence easterly along the
center line of Hile School Road a distance of 2,912 feet, more or
less, to the intersection with the center line of Red Mill Road; thence
northerly and easterly along the center line of Red Mill Road a distance
of 1,975 feet, more or less, to the intersection with the center line
of West Malloryville Road; thence easterly along the center line of
West Malloryville Road a distance of 4,172 feet, more or less, to
the intersection with the center line of Fall Creek Road; thence easterly
along the center line of East Malloryville Road a distance of 7,008
feet, more or less, to the intersection with the center line of Gulf
Hill Road; thence easterly along the center line of Gulf Hill Road
a distance of 3,375 feet, more or less, to the intersection with the
center line of Cortland Road (New York State Route 13); thence northeasterly
369 feet, more or less, along the center line of Cortland Road (New
York State Route 13) to the intersection with Old Dryden Road; thence
northeasterly along the center line of Old Dryden Road a distance
of 2,805 feet, more or less, to the easterly boundary of the Town
of Dryden; thence northerly along the easterly boundary of the Town
of Dryden a distance of 3,675 feet, more or less, to the point of
beginning.



(10) District No. 10. All of the Village of Lansing and all of the Village
of Cayuga Heights, and that part of the Town of Ithaca described as
follows:

(a) 
Beginning in the southwesterly corner of the Village of Cayuga
Heights where it adjoins with the City of Ithaca and the Town of Ithaca;
thence westerly along the southerly boundary of the Town of Ithaca
a distance 1,653 feet, more or less, to the intersection with the
corporate limits of the City of Ithaca, which is also the center line
of Cayuga Street North; thence northerly long the corporate limits
of the City of Ithaca a distance of approximately 4,600 feet to the
northern corner of the City of Ithaca, which is on the eastern side
of Cayuga Lake; westerly across Cayuga Lake a distance of 3,207 feet,
more or less, to the approximate center of Cayuga Lake, which said
point is on a line due north of the center line of Cayuga Inlet; thence
northwesterly along the approximate center line of Cayuga Lake a distance
4,043 feet, more or less, to the southwesterly corner of the Town
of Lansing, which is also located in the approximate center of Cayuga
Lake; thence easterly along the southerly boundary of Town of Lansing
a distance of 3,542 feet, more or less, to the northwesterly corner
of the Village of Cayuga Heights; thence southerly, easterly, and
southerly along the westerly boundary of the Village of Cayuga Heights
a distance of approximately two miles to the point of beginning.



(11) District No. 11. Part of the Town of Ithaca described as follows:

(a) 
Beginning at the northeasterly corner of the Town of Ithaca,
where it adjoins with the Village of Lansing and the Town of Dryden;
thence southerly along the easterly boundary of the Town of Ithaca
a distance of approximately 5.7 miles to the southeasterly corner
of the Town of Ithaca; thence westerly along the southerly boundary
of the Town of Ithaca a distance of approximately 1.4 miles to the
intersection of the center line of Troy Road; thence northerly along
the center line of Troy Road a distance of approximately 1.4 miles
to the intersection with the center line of Coddington Road; thence
northwesterly along the center line of Coddington Road a distance
of approximately 1.1 miles to the intersection with the boundary of
the City of Ithaca; thence northeasterly, northwesterly, easterly,
northerly, northeasterly, northwesterly, westerly, and northerly a
distance of approximately 4.6 miles along the boundary of the City
of Ithaca and Village of Cayuga Heights to the intersection with the
southerly boundary of the Village of Lansing and the northeasterly
corner of the Village of Cayuga Heights; thence easterly along the
northerly boundary of the Town of Ithaca a distance of approximately
1.3 miles to the point of beginning.



(12) District No. 12. Part of the Town of Ithaca described as follows:

(a) 
Beginning at the southwesterly corner of the Town of Ithaca;
thence northerly along the westerly boundary of the Town of Ithaca
a distance of approximately 4.5 miles to the intersection with the
center line of Bundy Road; thence easterly along the center line of
Bundy Road a distance of approximately 2.2 miles to the intersection
with the center line of Trumansburg Road (New York Route 96); thence
southeasterly along the center line of Trumansburg Road (New York
Route 96) a distance of 1,774 feet, more or less, to the City of Ithaca
corporate limits; thence westerly and northwesterly along the City
of Ithaca corporate limits a distance of 2,606 feet, more or less,
to the northwesterly corner of Tax Parcel 503089-26.-8-1 (Tax Role
Status Year 2011); thence southwesterly along the boundary of the
City of Ithaca a distance of 334 feet, more or less, to the northwesterly
corner of Tax Parcel 500700-132.-1-25 (Tax Role Status Year 2011);
thence southerly along the western line of the corporate limits of
the City of Ithaca a distance of 9,800 feet, more or less, to a monument
marking the corner of the corporate limits of the City of Ithaca,
also known as the southwest corner of "DeWitt location," located approximately
315 feet west of the center line of Floral Avenue, on the corporate
limit; thence easterly, southerly, northwesterly, and southwesterly
along the boundary of the City of Ithaca, as it twists and turns,
a distance of approximately 3.8 miles to the intersection with the
center line of Coddington Road; thence southeasterly along the center
line of Coddington Road a distance of approximately 1.1 miles to the
intersection with the center line of Troy Road; thence southerly along
the center line of Troy Road a distance of 4,581 feet, more or less,
to the intersection with the center line of East King Road; thence
westerly along the center line of East King Road a distance of approximately
1.4 miles to the intersection with the center line of Danby Road (New
York State Route 96B); thence westerly and southerly along the center
line of West King Road a distance of approximately 1.9 miles to the
southerly boundary of the Town of Ithaca; thence westerly along the
southerly boundary of the Town of Ithaca a distance of approximately
2.4 miles to the point of beginning.



(13) District No. 13. Part of the Town of Dryden described as follows:

(a) 
Beginning at the northwesterly corner of the Town of Dryden,
where it adjoins the Town of Lansing: thence southerly along the westerly
boundary of the Town of Dryden a distance of approximately 10.3 miles
to the southwesterly corner of the Town of Dryden; thence easterly
approximately 3.0 miles along the southerly boundary of the Town of
Dryden; thence northerly approximately 1.0 mile along the boundary
of the Town of Dryden; thence easterly approximately 1.9 miles along
the southerly boundary of the Town of Dryden to the intersection of
Hollister Road and Midline Road; thence easterly and northwesterly
3.3 miles, more or less, along the center line of Midline Road to
the intersection with the center lines of Ringwood Road and Mineah
Road; thence northwesterly 2.1 miles, more or less, along the center
line of Mineah Road to the intersection with the center lines of Dryden
Road (New York State Route 13) and Kirk Road; thence northerly 3,775
feet, more or less, along the center line of Kirk Road to the intersection
with the center line of Main Street (New York State Route 366); thence
northeasterly approximately 8,687 feet along the center line of Main
Street (New York State Route 366) to the intersection with the westerly
boundary of the Village of Freeville; thence northerly approximately
3,335 feet along the westerly boundary of the Village of Freeville
to the intersection with the center line of West Dryden Road, a point
which is also the northwestern corner of the Village of Freeville;
thence easterly along the northern boundary of the Village of Freeville
422 feet, more or less, to the intersection of Groton Road (New York
State Route 38); thence northerly along the center line of Groton
Road (New York State Route 38) a distance of 2.1 miles, more or less,
to the intersection of Peruville Road, which is the northern boundary
of the Town Of Dryden; thence westerly approximately 4.7 miles along
the northerly boundary of the Town of Dryden to the point of beginning.



(14) District No. 14. Part of the Town of Dryden described as follows:

(a) 
Beginning at the southeasterly corner of the Town of Dryden;
thence westerly approximately 4.8 miles along the southerly boundary
of the Town of Dryden to the intersection with Midline Road; thence
easterly and northwesterly 3.3 miles, more or less, along the center
line of Midline Road to the intersection with the center lines of
Ringwood Road and Mineah Road; thence northwesterly 2.1 miles, more
or less, along the center line of Mineah Road to the intersection
with the center lines of Dryden Road (New York State Route 13) and
Kirk Road; thence northerly 3,775 feet, more or less, along the center
line of Kirk Road to the intersection with the center line of Main
Street (New York State Route 366); thence northeasterly approximately
8,687 feet along the center line of Main Street (New York State Route
366) to the intersection with the westerly boundary of the Village
of Freeville; thence northerly approximately 3,335 feet along the
westerly boundary of the Village of Freeville to the intersection
with the center line of West Dryden Road, a point which is also the
northwestern corner of the Village of Freeville; thence easterly along
the northern boundary of the Village of Freeville 422 feet, more or
less, to the intersection of Groton Road (New York State Route 38);
thence northerly along the center line of Groton Road (New York State
Route 38) a distance of 2.1 miles, more or less, to the intersection
of Peruville Road, which is the northern boundary of the Town Of Dryden;
thence easterly approximately 4,830 feet along the center line of
Peruville Road, which is also the northern boundary of the Town of
Dryden, to the intersection with the center line of Ed Hill Road;
thence southerly and easterly 6,570 feet, more or less, along the
center line of Ed Hill Road to the intersection with the center line
of Hile School Road; thence easterly along the center line of Hile
School Road a distance of 2,912 feet, more or less, to the intersection
with the center line of Red Mill Road; thence northerly and easterly
along the center line of Red Mill Road a distance of 1,975 feet, more
or less, to the intersection with the center line of West Malloryville
Road; thence easterly along the center line of West Malloryville Road
a distance of 4,172 feet, more or less, to the intersection with the
center line of Fall Creek Road; thence easterly along the center line
of East Malloryville Road a distance of 7,008 feet, more or less,
to the intersection with the center line of Gulf Hill Road; thence
easterly along the center line of Gulf Hill Road a distance of 3,375
feet, more or less, to the intersection with the center line of Cortland
Road (New York State Route 13); thence northeasterly 369 feet, more
or less, along the center line of Cortland Road (New York State Route
13) to the intersection with Old Dryden Road; thence northeasterly
along the center line of Old Dryden Road a distance of 2,805 feet,
more or less, to the easterly boundary of the Town of Dryden; thence
southerly approximately 8.4 miles along the easterly boundary of the
Town of Dryden to the point of beginning.






