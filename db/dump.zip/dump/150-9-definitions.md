## § 150-9 Definitions.


As used in this article, the following terms
shall have the meanings indicated:

COUNTY ADMINISTRATOR
The budget officer for the County of Tompkins.


HOTEL
A building or portion thereof which is regularly used and
kept open as such for the lodging of guests. The term "hotel" includes
an apartment hotel, a motel, guest house, or facility known as a "bed-and-breakfast"
tourist facility, whether or not meals are served.


OCCUPANCY
The use or possession, or the right to the use or possession
of any room in a hotel.


OCCUPANT
A person who, for a consideration, uses, possesses, or has
the right to use or possess any room in a hotel under any lease, concession,
permit, right of access, license to use or other agreement, or otherwise.


OPERATOR
Any person operating a hotel in Tompkins County, including
but not limited to the owner or proprietor of such premises, lessee,
sublessee, mortgagee in possession, licensee, or any other person
otherwise operating such hotel.


PERMANENT RESIDENT
Any occupant of any room or rooms in a hotel for at least
30 consecutive days shall be considered a permanent resident with
regard to the period of such occupancy.


PERSON
An individual, partnership, society, association, joint-stock
company, corporation, estate, receiver, trustee, assignee, referee
and any other person acting in a fiduciary or representative capacity,
whether appointed by a court or otherwise, and any combination of
the foregoing.


RENT
The consideration received for occupancy valued in money,
whether received in money or otherwise.


RETURN
Any return filed or required to be filed as herein provided.


ROOM
Any room or rooms of any kind in any part or portion of a
hotel, which is available for or let out for any purpose other than
a place of assembly.

