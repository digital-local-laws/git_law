## § 92-4 Exemptions.



A. The provisions of this chapter shall not apply to:

(1) The rental of a housing accommodation in a building that
contains housing accommodations for not more than two families living independently
of each other, if the owner or members of his or her family reside in one
such housing accommodation; or

(2) The rental of a room or rooms in a housing accommodation,
if such rental is by occupant of the housing accommodation or by the owner
of the housing accommodation and he or she or members of his or her family
reside in such housing accommodation.



B. Nothing contained in this chapter shall be construed
to bar any religious or denominational institution or organization, or any
organization, operated for charitable or educational purposes, which is operated,
supervised or controlled by or in connection with a religious organization,
from limiting employment or sales or rental of housing accommodations or admission
or giving preference to persons of the same religion or denomination or from
making such action as is calculated by such organization to promote the religious
principles for which it is established or maintained.

C. Nothing in this chapter shall apply to any institution,
club, or place of accommodation which is its nature distinctly private as
defined by New York State Civil Rights Law § 40.

D. Nothing in this chapter shall prevent religious faiths
from establishing and maintaining educational institutions exclusively or
primarily for students of their own religious faith.


