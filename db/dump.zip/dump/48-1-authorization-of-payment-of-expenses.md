## § 48-1 Authorization of payment of expenses.


Payment or reimbursement in whole or in part to officers or employees
of their expenses of moving into the County of Tompkins so that they may assume
positions of employment are hereby authorized in accordance with this chapter.
