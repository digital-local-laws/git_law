## § 140-10 Enforcement.



A. Inspections and appearance tickets.

(1) All portions of vehicles, dumpsters, garbage cans, garbage
bags and other containers used to collect, haul, transport or dispose of solid
waste or regulated recyclables, including recycling containers or other containers
placed outside of residences or other establishments, shall be subject to
inspection to ascertain compliance with this article and the rules, regulations
or orders promulgated hereunder, by any police officer, peace officer, or
any other public official designated by the county.

(2) Police officers, peace officers, the Solid Waste Manager
and other public officials designated by the Board of Representatives are
hereby authorized and directed to issue appearance tickets for violations
of this article.



B. Penalties.

(1) Civil sanctions. The county may commence a civil action
to enjoin or otherwise remedy any failure to comply with this article or the
rules, regulations and orders promulgated pursuant to this article.

(2) Criminal penalties.

(a) Except as provided below, failure to comply with this
article or the rules, regulations or orders promulgated pursuant to this article,
shall be a violation as defined in § 55.10 of the Penal Law.

(b) Any waste generator convicted of a violation shall be
liable for a fine of $15 for the first violation, $30 for the second violation
and $50 for each succeeding violation.

(c) Any person, other than a waste generator, convicted of
a violation shall be liable for a fine of $50 for the first violation, $100
for the second violation and $250 for each succeeding violation.

(d) If any person is convicted of three violations of this
article within a period of 24 months, each subsequent failure to comply with
this article or the rules, regulations or orders promulgated pursuant to this
article, shall be a misdemeanor as defined in § 55.10 of the Penal
Law. Any person convicted of a misdemeanor shall be liable for a fine of up
to $2,500.



(3) Each commission of a single act shall constitute a separate
violation of this article, and each day such violation occurs or continues
shall constitute a separate offense, which may be punished and prosecuted
as such.

(4) Any penalties or damages recovered or imposed under this
article are in addition to any other remedies available at law or equity.




