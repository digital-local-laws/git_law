## § 150-21 Refunds, revisions or credits.



A. In the manner provided in this section, the County
Administrator shall refund or credit, without interest, any tax, penalty
or interest erroneously, illegally or unconstitutionally collected
or paid if application to the County Administrator for such refund
is made within one year from the payment thereof. Whenever a refund
is made by the County Administrator, the reason therefor shall be
stated in writing. Such application may be made by the occupant, operator,
or other persons who has actually paid the tax. Such application may
also be made by an operator who has collected and paid over such tax
to the County Administrator, provided that the application is made
within one year of the payment by the occupant to the operator. However,
no actual refund of moneys shall be made to such operator until it
is first established to the satisfaction of the County Administrator
under such regulations as the County Administrator by authority of
the Board of Representatives may prescribe, that the operator has
repaid to the occupant the amount for which the application for refund
is made. In lieu of any refund required to be made, the County Administrator
may allow credit therefor on payments due from the applicant.

B. An application for a refund or credit made as herein
provided shall be deemed an application for a revision of any tax,
penalty or interest complained of, and the County Administrator may
receive evidence with respect thereto. After making determination,
the County Administrator shall give notice thereof to the applicant,
who shall be entitled to review said determination by a proceeding
pursuant to Article 78 of the Civil Practice Law and Rules, provided
that the proceeding is instituted within 30 days after the giving
of the notice of determination, and provided that a final determination
of tax due was not previously made. Such a proceeding shall not be
instituted unless an undertaking is filed with the County Administrator
in an amount and with sureties approved by a Justice of the Supreme
Court to the effect that if such proceedings are dismissed or the
tax confirmed, the petitioner will pay all costs and charges that
may accrue in the prosecution of said proceeding.

C. A person shall not be entitled under this section
to a revision, refund, or credit of a tax, interest, or penalty that
had been determined to be due pursuant to the provisions of this § 150-21
where said person has had a hearing or an opportunity for a hearing
as provided in this section, or who has failed to avail himself of
the remedies provided therein. No refund or credit of a tax, interest,
or penalty paid after a determination by the County Administrator
pursuant to § 150-19 of this article shall be paid unless
it is found that the determination was erroneous, illegal, unconstitutional
or otherwise improper by the County Administrator after a hearing
or of his own motion, or in a proceeding under Article 78 of the Civil
Practice Law and Rules pursuant to the provisions of said section.
In that event, refund or credit without interest shall be made of
the tax, interest or penalty found to have been overpaid.


