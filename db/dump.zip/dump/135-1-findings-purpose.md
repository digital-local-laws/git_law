## § 135-1 Findings; purpose.


The Tompkins County Legislature has determined the County is
facing a variety of impending major development efforts that may result
in extraordinary, high-intensity traffic to and from development sites,
causing significant and measurable damage to County roads that jeopardizes
the health and safety of residents and others who use those roads.
Accordingly, the damage that results from high-intensity traffic must
be anticipated, analyzed, and repaired promptly and to appropriate
engineering standards. The Legislature has further determined that
it is in the best interest of taxpayers and the general public to
assign responsibility for the repair of damage to County roads attributable
to such high-intensity use, and, where necessary, for the improvement
of County roads to a standard appropriate for high-intensity use prior
to the commencement of the activity, to those responsible for the
damage rather than to all County taxpayers. The purpose of this chapter
is to maintain the safety and general welfare of County residents
by regulating heavy uses of County roads that have the potential to
adversely affect such roads. Well-maintained roads are important to
the safety and economic well-being of the County and its residents.
Endeavors, such as construction, timber harvesting, mining, and natural
gas drilling are also of economic interest. This chapter is not intended
to regulate such businesses; the intent is to protect the public roads
from damage.
