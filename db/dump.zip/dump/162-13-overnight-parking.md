## § 162-13 Overnight parking.


The Board of Representatives, or a committee or staff member designated
by the Board, may from time to time designate certain overnight hours during
which parking shall be prohibited or limited, in any one or more parking areas
of the county.
