## § 150-31 Purpose.


This article is adopted pursuant to Article
11 of the Real Property Tax Law, as amended by Chapter 602 of 1993
and Chapter 532 of 1994, which states that the redemption period for
delinquent taxes shall expire two years after lien date, except that
a tax district may increase the redemption period for residential
and/or farm property to three or four years, in the manner provided
by § 1111 of Article 11 of the Real Property Tax Law. This
article hereby extends the period of redemption for residential and
farm property to three years after lien date.
