## § 150-1 Statutory authority.


This article is enacted pursuant to § 467
of the Real Property Tax Law of the State of New York, as amended
by Chapter 198 of the Laws of 1990.
