## § 70-1 Deputies and employees placed in the classified service.


All full-time deputies and full-time employees (for the purpose of this
chapter, "full-time" shall be all employees scheduled to work no less than
2,080 hours annually) of the Sheriff of Tompkins County, except the Undersheriff,
are hereby placed in the classified service of Civil Service and shall be
employed in accordance with the provisions of the Civil Service Law of the
State of New York, and shall be subject to and governed by such law and the
Tompkins County Civil Service Rules and appendices.
