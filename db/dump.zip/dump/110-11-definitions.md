## § 110-11 Definitions.


As used in this article, the following terms
shall have the meanings indicated:

TOMPKINS COUNTY PUBLIC SAFETY ANSWERING POINT or TOMPKINS COUNTY
PSAP
The site designated and operated by the County of Tompkins
for the purpose of receiving emergency calls, including those from
a wireless telephone service, and dispatching needed emergency services.


WIRELESS TELEPHONE SERVICE
All commercial mobile services, as that term is defined in
Section 332(d) of Title 47, United States Code, including all broadband
personal communications services, wireless radio telephone services,
geographic area specialized and enhanced specialized mobile radio
services and incumbent wide-area specialized mobile radio licensees,
which offer real time, two-way voice service that is interconnected
with the public switched telephone network.


WIRELESS TELEPHONE SERVICE SUPPLIER
Any corporation or person as defined in § 1080
of the Tax Law which provides wireless telephone service in New York
State.

