## § 162-3 Parking permits.


The Airport Manager is authorized to issue parking permits to employees
or tenants at the airport, persons owning aircraft in the tiedown and T-hangar
areas, county employees and others, authorizing parking in the designated
parking areas. Permits shall be issued on a calendar year basis.
