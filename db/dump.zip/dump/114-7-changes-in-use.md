## § 114-7 Changes in use.


Each owner of property is hereby required to
provide the county written notice of any change in use of the parcel
that could result in a change in the classification and/or the number
of billing units assigned to the parcel. Such notice shall be in the
form prescribed by the county, and given within 30 days of the change
in property use.
