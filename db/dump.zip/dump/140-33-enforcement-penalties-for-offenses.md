## § 140-33 Enforcement; penalties for offenses.



A. Any person who commits a violation of § 140-32A,
B, C, or G above is subject to arrest. Punishment upon conviction shall be
as follows:

(1) First offense. Conviction of a first offense under this
article shall be punishable by a fine of not less than $100 nor more than
$500, and/or a term of imprisonment not to exceed 15 days, together with restitution
based on avoided disposal fees and cost of collection and hauling, and/or
community service. Violation of this provision shall be a violation as defined
by § 55.10(3) of the Penal Law of the State of New York.

(2) Second or subsequent offense. Conviction of a second
or subsequent offense within a year of the first offense shall be punishable
by a fine or not less than $500 nor more than $1,000 and/or a term of imprisonment
not to exceed six months, together with restitution based on avoided disposal
fees and cost of collection and hauling, and/or community service. Violation
of this provision shall be a misdemeanor as defined by § 55.10(2)
of the Penal Law of the State of New York.

(3) Conviction of any company, partnership, municipality,
or any entity other than an individual person shall be subject to a fine of
not less than $500 nor more than $2,500 and/or community service and/or restitution.



B. Any person who violates § 140-32D above shall
be guilty of a misdemeanor and, upon conviction, shall be punishable by a
fine or not less than $500 nor more than $5,000 for a first offense; and for
a second and each subsequent offense, he/she shall be guilty of a misdemeanor
and, upon conviction thereof, shall be punishable for a fine of not less than
$3,000 nor more than $20,000 or a term of imprisonment of not more than six
months, or both.

C. Any person who commits a violation of § 140-32E
above is subject to arrest and punishment, upon conviction, of a fine of not
less than $50 and/or a term of imprisonment not to exceed 15 days and/or community
service.

D. Each day during which an offense continues shall be deemed
to be a separate offense.

E. Enforcement of Subsections A through D shall be effected
as follows:

(1) By a peace officer or police officer as provided by the
Criminal Procedure Law of the State of New York;

(2) By the Tompkins County Solid Waste Manager and/or the
Public Health Director or their designees by issuance of an appearance ticket
pursuant to Article 150 of the Criminal Procedure Law of the State of New
York.



F. Persons violating § 140-32F shall be liable
for a civil penalty of $50 for the first offense, $100 for a second offense
and $500 for a third or subsequent offense. Said persons shall also be liable
for any expense in removing the illegally disposed of waste. This provision
shall be enforced by a delivery of a notice of civil penalty by a police officer,
peace officer, or the Solid Waste Manager or designee thereof, either in person
or by certified mail. Failure to pay said civil penalty may result in the
commencement of a civil action by the County Attorney or his designee. Upon
commencement of an action, the person shall be liable for attorneys' fees
in an amount of $100, in addition to the civil penalty.

G. Civil enforcement. Notwithstanding the penalties set
forth above, the Tompkins County Attorney may institute a civil action to
obtain restitution to the County of Tompkins from such offender for the actual
costs incurred in rectifying the problem created by the aforesaid violation
or improper disposal of solid waste, or to abate, enjoin, or otherwise compel
cessation of the violation of any provision of this article.

H. Any person who commits a violation of this article, including
any activity described in § 140-32, shall, in addition to any other
fines and penalties provided for by this article, be liable to pay restitution
to the county or any other person that incurs costs in collecting, hauling,
or properly disposing of solid waste or hazardous waste incurred as a result
of the offense.

I. Enforcement. This article is enforceable throughout the
county. It does not supersede ordinances enacted by municipalities within
Tompkins County that regulate the disposal of solid waste if such ordinances
are not inconsistent with this article.


