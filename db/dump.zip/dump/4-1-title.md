## § 4-1 Title.


This chapter shall be known as the "Tompkins County Office for the Aging."
