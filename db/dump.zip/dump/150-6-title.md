## § 150-6 Title.


This article shall be known as the "Tompkins
County Hotel Room Occupancy Tax Law."
