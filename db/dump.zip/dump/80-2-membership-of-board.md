## § 80-2 Membership of Board.



A. The Board shall be composed of eleven members interested
in traffic safety and traffic problems appointed by the Board of Representatives
of the county.

B. Each member shall be a resident of the county and a qualified
elector thereof. One of such members shall be a resident of and be appointed
from the City of Ithaca, and the balance of such membership shall be appointed
from the county at large.

C. The term of office of such members shall be three years,
except that the members first appointed to such Board shall be appointed as
follows: four shall be appointed for a term of one year; four for a term of
two years; three for a term of three years. Upon the expiration of the term
of office of any member, his successor shall be appointed to membership in
such Board for a term of three years.

D. The members of such Board shall receive no compensation
but shall be entitled to reasonable and necessary expenses incurred in the
performance of their duties within the amount of the appropriation made for
such purpose.


