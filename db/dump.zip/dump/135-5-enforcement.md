## § 135-5 Enforcement.


The Highway Manager, in consultation with the County Attorney,
shall enforce the provisions of this chapter and all rules, regulations,
and designations made pursuant thereto. Such enforcement shall include
but not be limited to legal or equitable proceedings, including without
limitation an action for specific performance brought in the name
of the County.
