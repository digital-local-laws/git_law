## § 150-2 Exemption granted. 


[Amended 4-4-2000 by L.L. No. 3-2000]

A. Pursuant to the provisions of § 467 of the
Real Property Tax Law of the State of New York, real property located
in the County of Tompkins, owned by one or more persons each of whom
is 65 years of age or over, or real property owned by husband and
wife, one of whom is 65 years of age or over, shall be partially exempt
from taxation by said County for the applicable taxes specified in
§ 467 based upon the income of the owner or combined income
of the owners. A person otherwise qualifying for such exemption shall
not be denied such exemption if such person becomes 65 years of age
after the appropriate taxable status date and before December 31 of
the same year. Such partial exemption shall be to the extent set forth
in the schedule following:







Annual Income of Owner or Combined Annual
Income of Owner


Percentage Assessed Valuation Exempt From
Taxation








M or less than M


50%






More than (M) but less than (M + $1,000)


45%






(M + $1,000 or more) but less than (M + $2,000)


40%






(M + $2,000 or more) but less than (M + $3,000)


35%






(M + $3,000 or more) but less than (M + $3,900)


30%






(M + $3,900 or more) but less than (M + $4,800)


25%






(M + $4,800 or more) but less than (M + $5,700)


20%






M = the income eligibility level as set by the
County Board of Representatives and consistent with § 467
of the Real Property Tax Law.






B. This partial exemption provided by this article shall,
however, be limited to such property and persons as meet the conditions,
qualifications, exclusions, and limitations set forth in § 467
of the Real Property Tax Law of the State of New York. This article
shall be administered in accordance with said sections of the Real
Property Tax Law, as now adopted, and as they may be amended from
time to time, and the provisions of said section as provided in § 467,
shall be applicable to the effectuation of the exemption provided
for in this article.


