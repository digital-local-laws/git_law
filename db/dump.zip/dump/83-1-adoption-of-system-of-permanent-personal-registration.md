## § 83-1 Adoption of system of Permanent Personal Registration.


The County of Tompkins hereby elects to adopt and does hereby adopt,
for the purpose of the registration of voters for elections within the County
of Tompkins, the system of Permanent Personal Registration set forth in Article
15 of the Election Law.
