## § 127-1 Definitions.


As used in this chapter, the following terms shall have the meanings
indicated:

ESTABLISHED PLACE OF BUSINESS
Includes a building or store in which or where the person transacts
business and deals in the goods, wares or merchandise he hawks, peddles or
solicits for during regular hours of business daily or the home of an individual
residing in Tompkins County who accepts orders for merchandise but accepts
no payment until the time of delivery.


HAWKER and PEDDLER
Includes any person, either principal or agent, who, in any public
street or public place, or by going from house to house on foot or on or from
any vehicle or animal, sells or barters, offers for sale or barter, or carries
or exposes for sale or barter any goods, wares or merchandise, except milk,
newspapers, periodicals and nonprocessed foods.


PRIVATE SALE
Includes any sale of personal goods, by the owner of such at their
place of residence (such sales are sometimes referred to as "garage sales,"
"lawn sales," etc.).


SOLICITOR
Includes any person who solicits publicly, goes from place-to-place
or house-to-house, requests or accepts orders by telephone or who stands in
any street or public place taking or offering to take orders for goods, wares
or merchandise, except newspapers or milk, or for services to be performed
in the future or for making, manufacturing or repairing any article or thing
whatsoever for future delivery.


TRANSIENT BUSINESS
Includes one conducted in a store, hotel, motel, house, building,
structure, on property owned by another or one conducted house-to-house or
one conducted by telephonic communications for the sale or purchase at retail
of goods, wares and merchandise, excepting food products, and which is intended
to be conducted for a temporary period of time, and not permanently.

