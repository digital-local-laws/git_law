## § 110-7 Surcharge to be added to bills.


[Amended 11-4-2009 by L.L. No. 1-2009]
All suppliers of local telephone exchange access
lines shall begin to charge the $1 per month surcharge as herein provided
to all service bills issued after November 17, 2009, subject to the
exclusions contained herein.
