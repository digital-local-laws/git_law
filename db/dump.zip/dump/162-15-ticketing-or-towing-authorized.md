## § 162-15 Ticketing or towing authorized.



A. Whenever any vehicle shall be found parked in violation
of this article, the Commissioner of Public Works, his designee or appropriate
police agency shall place a written notice to the owner on such vehicle that
such vehicle has been parked in violation of the provisions of this article,
and shall thereby summon such owner to appear in the Municipal Court in which
the violation occurred to answer for such violation in accordance with this
article. Jurisdiction is hereby conferred upon such court to hear, try and
determine all questions of law and/or fact arising under this article, and
to impose the fine or punishment hereinafter provided. Such summons may permit
the owner, as he or she may elect, to plead guilty to the offense indicated
thereon, signing his or her true and correct appearance in said court at the
time prescribed to be noted, and to pay a fine as designated.

B. When a vehicle is found to be parked in violation of
this article, such vehicle may be removed and conveyed by means of towing
the same or otherwise to some suitable place of storage. Before the owner
or person in charge of that vehicle shall be permitted to retrieve the vehicle,
he/she must furnish evidence of his/her identity and ownership or right to
possession, pay the proper charges and sign a receipt for such vehicle. The
county may contract with one or more companies engaged in the towing of vehicles,
to carry out this provision.


