## § 77-2 Powers and duties of Director.


The Director of the County Tax Department shall advise and assist all
assessors, collectors and receivers of taxes of the various tax districts
within the county in the discharge of the duties of their offices pursuant
to rules and regulations as may be prescribed by the Board of Supervisors.
Such Director shall also assist in the preparation of equalization rates for
the various tax districts within the county and act as advisor to the Equalization
Committee of the Board. The Director shall perform such other duties as shall
be prescribed by the Board of Supervisors.
