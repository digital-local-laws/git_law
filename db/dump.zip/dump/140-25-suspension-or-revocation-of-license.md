## § 140-25 Suspension or revocation of license.



A. Upon the failure of a licensee to comply with the solid
waste license conditions of this article and the rules and regulations promulgated
thereunder, or any other state, federal or local law governing the licensee's
operation, the Commissioner shall notify the licensee, in writing, personally
served or sent by registered mail to the licensee's last known address. Such
notice shall state the Commissioner's intent to revoke, suspend or impose
conditions on the licensee's solid waste license, together with the reasons
for the Commissioner's action.

B. The licensee may demand a hearing by serving upon the
Commissioner a written request for a hearing within 10 days from the date
the Commissioner's notice is served or mailed. Hearings shall be held as provided
in § 140-26 herein. If the licensee does not demand a hearing, the
Commissioner may revoke, suspend or impose conditions on the license and shall
promptly advise the licensee, in writing, of such action.

C. If in the judgment of the Commissioner the failure of
the licensee to comply with the solid waste license conditions or the rules
and regulations or other law pose a threat to the health or safety of the
county or any resident of the county or if the violations will continue if
action is not taken within the time period enumerated in Subsection B, the
Commissioner may revoke, suspend or impose conditions on a license at any
time without providing an opportunity for a prior hearing. Upon receipt of
notice of revocation, suspension or the imposition of conditions, the licensee
shall be entitled to a hearing within five days of receipt of demand for such
hearing by the county.


