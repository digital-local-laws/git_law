## § 168-5 Use of surcharge.


All surcharge monies remitted to the County of Tompkins by a wireless
communications service supplier shall be expended only as provided in § 308-a
of the County Law.
