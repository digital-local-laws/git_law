## § 150-13 Territorial limitations.


The tax imposed by this article shall apply
only to occupancies within the territorial limits of the County of
Tompkins.
