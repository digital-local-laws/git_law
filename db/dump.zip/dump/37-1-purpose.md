## § 37-1 Purpose.


The purpose of this article is to supersede that portion of the New
York State General Municipal Law § 352(5), which requires that a
public hearing on notice be held prior to the lease of real property at a
public airport.
