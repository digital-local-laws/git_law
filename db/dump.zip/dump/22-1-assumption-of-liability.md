## § 22-1 Assumption of liability.


The County of Tompkins shall assume the liability to save harmless and
protect the County Clerk and employees in the County Clerk's office from financial
loss arising out of any claim, demand, suit or judgment by reason of alleged
negligence of said County Clerk or employees, provided that such act was committed
in the discharge of their duties and within the scope of their employment.
