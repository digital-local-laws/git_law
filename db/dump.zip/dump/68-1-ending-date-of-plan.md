## § 68-1 Ending date of plan.


The plan of mutual self-insurance heretofore adopted by this Board pursuant
to former Subdivision 3-a of § 50 of the Workers' Compensation Law
is hereby continued through December 31, 1956.
