## § 58-1 Title.


This article of Tompkins County shall be known as "A local law providing
for designation of the official newspaper of Tompkins County and for public
notice of the adoption of local laws by the Tompkins County Board of Representatives."
