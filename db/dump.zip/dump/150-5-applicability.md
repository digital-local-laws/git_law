## § 150-5 Applicability.


This article shall, in accordance with the provisions
of § 2 of Chapter 198 of the Laws of 1990, be applicable
to the County tax for the year 1996, and the provisions of said law
shall govern the granting of an exemption under § 467 of
the Real Property Tax Law, notwithstanding any contrary provisions
of the section.
