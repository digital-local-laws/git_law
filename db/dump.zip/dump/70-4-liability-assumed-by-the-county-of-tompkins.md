## § 70-4 Liability assumed by the County of Tompkins.


Any omission or act of any employee of the county in the office of the
Sheriff done or made in the performance of an official duty or for the performance
of which the county is paid or receives compensation or fee shall be the omission
or act of the county. The damages, if any, resulting therefrom shall be deemed
the liability of the County of Tompkins.
