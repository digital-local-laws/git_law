## § 15-4 Term.


The term of each member of the Board shall be for four years; provided,
however, that, of the members first appointed, two shall be appointed for
a term of two years, two for a term of three years and three for a term of
four years. All terms shall be measured from the first day of the year of
appointment. Vacancies shall be filled for the unexpired term in the same
manner as original appointments.
