## § 162-12 Parking areas to be designated.


All parking in said restricted areas shall be in areas designated by
signs and markings or other directions posted by the Tompkins County Commissioner
of Public Works under the direction of the appropriate committee of the Board
of Representatives. It shall be unlawful for any person or operator to park
outside of the designated lined spaces or otherwise than is designated by
signs, or to use the area unreasonably and contrary to the intent of this
article, including the disposal of litter.
