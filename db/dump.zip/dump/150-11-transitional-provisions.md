## § 150-11 Transitional provisions.


The tax imposed by this article shall be paid
upon any occupancy on and after the fifth day of September 1989, although
such occupancy is pursuant to a prior contract, lease, or other arrangement.
Where rent is paid or payable on a weekly, monthly, or other term,
the rent shall be subject to the tax imposed by this article to the
extent that it covers any period on and after the fifth day of September
1989.
