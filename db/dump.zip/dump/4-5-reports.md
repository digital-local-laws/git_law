## § 4-5 Reports.


The Tompkins County Office for the Aging shall make an annual report
to the County Board of Representatives concerning its activities; in addition,
it shall make an interim report quarterly.
