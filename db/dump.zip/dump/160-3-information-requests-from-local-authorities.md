## § 160-3 Information requests from local authorities.



A. Except as provided in Subsection B of this section, when
the county obtains custody of an abandoned vehicle, it shall make an inquiry
concerning the last registered owner to the jurisdiction which issued the
number plates affixed to the vehicle, or to the New York Department of Motor
Vehicles, if there were no number plates affixed. Such inquiry shall be made
on Form DP-208, or on such other form as may be required by the jurisdiction
which issued the number plates.

B. Inquiry concerning the last registered owner shall not
be required when the abandoned vehicle is one which was left without number
plates affixed and which is of a wholesale value, taking into consideration
the condition of the vehicle, of $100 or less.

C. When the County has custody of a large number of vehicles,
it may, with the approval of the Commissioner of Motor Vehicles, submit the
request for information in such other form as may be prescribed by the Commissioner.
Requests for such approval should be mailed to Department of Motor Vehicles,
Abandoned Vehicles Unit, 504 Central Avenue, Albany, New York 12206.


