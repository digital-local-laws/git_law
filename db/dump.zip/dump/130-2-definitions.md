## § 130-2 Definitions.


All terms used herein shall be as defined in Article 33 of the New York
Environmental Conservation Law:

ABUTTING PROPERTY
Any property which has any boundary point in common with the property
on which the pesticide is to be applied.


AGENCY
Any state agency; municipal corporation; public authority; college,
as that term is defined in the Education Law; railroad, as that term is defined
in the Railroad Law; or telegraph, telephone, telegraph and telephone, pipeline,
gas, electric, or gas and electric corporation as those terms are defined
in the Transportation Corporations Law, which applies pesticides.


COMMERCIAL LAWN APPLICATION
The application of pesticides to ground, trees, or shrubs on public
or private outdoor property. For the purposes of this article the following
shall not be considered commercial lawn application:

A. 
The application of pesticide for the purpose of producing an agricultural
commodity;

B. 
Residential application of pesticides;

C. 
The application of pesticides around or near the foundation of a building
for the purpose of indoor pest control;

D. 
The application of pesticides by or on behalf of agencies, except that
agencies shall be subject to visual notification requirements pursuant to
§ 33-1003 of the Environmental Conservation Law where such application
is within 100 feet of a dwelling, multiple dwelling, public building or public
park; and

E. 
The application of pesticides on golf courses or turf farms.




COMMISSIONER
The Commissioner of the New York State Department of Environmental
Conservation.


DWELLING
Any building or structure or portion thereof which is occupied in
whole or in part as the home, residence or sleeping place for one or two families.


GENERAL USE PESTICIDE
A pesticide which does not meet the state criteria for a restricted
pesticide as established under authority of § 33-0303 of the New
York Environmental Conservation Law.


MULTIPLE DWELLING
Any dwelling which is to be occupied by or is occupied as the residence
or home of three or more families living independently of each other.


PESTICIDE

A. 
Any substance or mixture of substances intended for preventing, destroying,
repelling, or mitigating any pest; and

B. 
Any substance or mixture of substances intended for use as a plant regulator,
defoliant, or desiccant.




PREMISES
Land and improvements or appurtenances or any part thereof.


RESIDENTIAL LAWN APPLICATION
The application of general use pesticides to ground, trees, or shrubs
on property owned by or leased to the individual making such application.
For the purpose of this article the following shall not be considered residential
lawn application:

A. 
The application of pesticides for the purpose of producing an agricultural
commodity;

B. 
The application of pesticides around or near the foundation of a building
for purpose of indoor pest control;

C. 
The application of pesticides by or on behalf of agencies shall be subject
to visual notification requirements pursuant to § 33-1003 of the
New York Environmental Conservation Law where such application is within 100
feet of a dwelling, multiple dwelling, public building or public park; and

D. 
The application of pesticides on golf courses or turf farms.



