## § 150-4 False statements; penalties for offenses.


Any conviction of having made any willful false
statement of the application for such exemption shall be punishable
by a fine of not more than $100 and shall disqualify the applicant
or applicants from further exemption for a period of five years.
