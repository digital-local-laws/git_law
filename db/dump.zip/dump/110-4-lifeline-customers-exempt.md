## § 110-4 Lifeline customers exempt.


The surcharge herein shall not apply to any
"Lifeline" customers of local telephone service suppliers.
