## § 160-2 Removal and disposal.


The Sheriff of the County of Tompkins is hereby authorized to contract
with any municipality within the County of Tompkins for the purpose of removing
and disposing of abandoned vehicles. If such a contract is executed between
the Sheriff and the various municipalities, the Sheriff shall be designated
as the agent in said contracts of said municipalities while removing and disposing
of vehicles abandoned in said municipalities. Any moneys derived from the
sale of said abandoned vehicles, less the expense of removal, storage charges
and sale, shall be held by the county for a period of five years and thereafter
paid into the general fund of the county in the same manner as if the county
were the municipality entitled to the custody of the vehicle, as prescribed
by Subdivision 5 of § 1224 of the Vehicle and Traffic Law.
