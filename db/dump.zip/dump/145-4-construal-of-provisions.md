## § 145-4 Construal of provisions.


Nothing herein contained shall be construed to relieve a claimant of
the obligation to send a notice of claim as provided in § 50-e of
the General Municipal Law. Further, nothing contained in this chapter shall
be held to repeal or modify or waive any existing requirement or statute of
limitations which is applicable to these classes of actions, but, on the contrary,
shall be held to be additional requirements of the right to maintain such
actions.
