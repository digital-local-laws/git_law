## § 130-1 Legislative intent; authority; title.



A. This Legislature finds that individuals and their personal
property are, or can be, unwittingly exposed to pesticides applied on their
neighbor's property from commercial and residential lawn applications. This
Legislature further finds that pesticides may pose health and safety risks
to people, particularly children, pregnant women, the elderly, and people
with infirmities. The intent of this article is to provide information to
county residents about certain pesticide applications to which they may be
exposed, so that they can take steps to minimize such exposure to themselves,
their families, pets, crops, livestock, backyard wildlife, and property.

B. Accordingly, this Legislature hereby adopts the special
notice requirements for commercial and residential lawn applications of pesticides
as set forth in § 33-1004 of the New York Environmental Conservation
Law. It is intended that this article be read and applied consistently with
that section and all other applicable provisions of the Environmental Conservation
Law and regulations promulgated thereunder.

C. This article shall be known as the "Tompkins County Neighbor
Notification Law for Pesticides."


