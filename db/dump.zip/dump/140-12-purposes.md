## § 140-12 Purposes.


This article prescribes the methods of payment for disposal of solid
waste through private and municipal solid waste haulers and encourages the
recycling of solid waste.
