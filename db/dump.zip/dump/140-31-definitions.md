## § 140-31 Definitions.


As used in this article, the following terms shall have the meanings
indicated:

BELOW REGULATORY CONCERN RADIOACTIVE WASTE
Radioactive waste that has been deregulated by the United States
Environmental Protection Agency or Nuclear Regulatory Commission, or the New
York State Department of Health or Environmental Conservation.


DISPOSE
To abandon, discharge, deposit, inject, dump, spill, leak, or place
any substance into or on any land or water or so that such substances or any
constituent thereof may enter the environment. The placement of biodegradable
material in a properly maintained compost pile is not disposal of solid waste.


HAZARDOUS WASTE
Includes radioactive waste (including below-regulatory-concern radioactive
waste, or any radioactive waste that has been deregulated) and that waste
defined to be hazardous by any federal or New York State law, code, rule or
regulation.


PERSON
Any individual, firm, public or private corporation, political subdivision,
government agency, municipality, industry, partnership, association, institution,
trust, estate or any other legal entity whatsoever.


PROPERLY MAINTAINED COMPOST PILE
Refers to a compost pile of less than 25 cubic yards that:

A. 
Is maintained and operated in a safe nuisance-free manner;

B. 
Contains no sewage, sludge, or septage; and

C. 
Follows acceptable methods of composting that minimize odors and produce
a useful stable end product.




SOLID WASTE
All putrescible and nonputrescible materials of substances that are
discarded or rejected as being spent, worthless, useless or in excess to the
owners at the time of such discard or rejection, including but not limited
to garbage, refuse, industrial and commercial waste, sludge from air or water
treatment facilities, rubbish, tires, ashes, contained gaseous material, incinerator
residue, construction and demolition debris, discarded automobiles and offal.

