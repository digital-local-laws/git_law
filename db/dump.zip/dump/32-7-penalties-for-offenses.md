## § 32-7 Penalties for offenses.


In addition to any penalty contained in any other provision
of law, any person who shall knowingly and intentionally violate any
of the provisions of this code may be censured, fined, suspended,
or removed from office or employment, as the case may be, in the manner
provided by law.
