## § 150-32 Definitions.


As used in this article, the following terms
shall have the meanings indicated:

FARM PROPERTY
Property which consists of land used in agricultural production,
as defined in Article 25AA of the Agriculture and Markets Law. A parcel
shall be deemed to be farm property if the applicable tax roll shows
that: the parcel is exempt from taxation pursuant to §§ 305
or 306 of the Agriculture and Markets Law, or pursuant to § 483
of the Real Property Tax Law; or the Assessor has assigned to the
parcel a property classification code in the agricultural category.


PROPERTY CLASSIFICATION CODES
The property classification system prescribed by the State
Board pursuant to Real Property Tax Law § 502 and the rules
adopted thereunder.


RESIDENTIAL PROPERTY
Property which is improved by a one-, two-, or three-family
structure used exclusively for residential purposes other than property
subject to the assessment limitations of § 581 of the Real
Property Tax Law and Article 9-B of the Real Property Law. A parcel
shall be deemed to be residential property for purposes of this article
if the applicable tax roll shows that the Assessor has assigned to
the parcel a property classification code in the residential category,
or the parcel has been included in the homestead class in an approved
assessing unit, or in class one in a special assessing unit.

