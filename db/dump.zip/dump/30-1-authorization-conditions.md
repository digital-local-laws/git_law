## § 30-1 Authorization; conditions.


The County of Tompkins is hereby authorized
and empowered to submit an application for designation of certain
areas within the County as an Empire Zone; provided, however, that
such authorization and empowerment shall be conditioned upon the prior
concurrence with respect to such application of the governing bodies
of any and all cities, towns, and villages in which such zone is located.
