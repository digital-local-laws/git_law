## § 72-2 Prohibitions.


No person shall smoke or carry a lighted cigar, cigarette, pipe, or
any other form of smoking object or device in any County-owned or -occupied
building or vehicle.
