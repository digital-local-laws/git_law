## § 28-3 Election of County Legislators.


One County Legislator shall be elected from each of the above
Districts 1 through 14, inclusive.
