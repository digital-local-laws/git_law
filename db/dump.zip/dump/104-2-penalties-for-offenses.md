## § 104-2 Penalties for offenses.


A violation of the provisions of this chapter shall constitute an offense,
and a person found to be guilty of such offense may be punished by imprisonment
not exceeding 10 days in the Tompkins County Jail.
