## § 140-23 Solid waste license requirement.



A. Except as otherwise provided in this section or in the
rules and regulations promulgated pursuant to § 140-22, no person
shall engage in the business of collecting, transporting or handling solid
waste generated or originated or brought within the county without a solid
waste license issued by the Commissioner, provided that only persons who collect,
transport or handle solid waste for compensation shall be required to obtain
a solid waste license.

B. All applications for solid waste licenses or renewal
of licenses shall be in writing and shall contain such information as is required
by this article and the rules and regulations promulgated pursuant to this
article, and shall be verified by the applicant.

C. Within 30 days of receipt of the properly completed and
signed application, the Commissioner shall either issue a solid waste license
or inform the applicant, in writing, that the solid waste license applied
for has been denied with an explanation of the denial. (See § 140-24
for conditions for a solid waste license.) Any decision denying a license
shall be sent to the applicant by registered mail.

D. If a solid waste license application or renewal application
is denied, the applicant may, within 15 days of the date the denial was mailed,
file a written petition with the Commissioner demanding that a hearing be
held. The hearing shall be held before the Hearing Board in accordance with
§ 140-26 herein.

E. Renewal licenses shall be applied for and issued in the
same manner and subject to the same requirements as original licenses, and
shall also be subject to any additional requirements in effect at the time
of application for renewal. A complete and timely submitted application for
renewal shall result in the applicant's existing license remaining in effect
(provided that such license has not been suspended or revoked) until the expiration
of the license or until the renewal application is acted upon by the Commissioner,
whichever is later. If the application is denied and the applicant demands
a hearing, the Hearing Board may, in its discretion, grant the applicant a
temporary license pending the final determination of the hearing.


