## § 114-24 Fees for recording documents.


For recording, entering, indexing, and endorsing
a certificate on any instrument, the fee is increased from $5 to $20
and, in addition thereto, is increased from $3 to $5 for each page
or portion of a page. For the purpose of determining the appropriate
recording fee, the fee for any cover page shall be deemed an additional
page of the instrument. A cover page shall not include any social
security account number or date of birth. To the extent that the Tompkins
County Clerk has placed an image of such cover page on line, the County
Clerk shall make a good-faith effort to redact such information.
