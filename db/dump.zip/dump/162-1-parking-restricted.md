## § 162-1 Parking restricted.


Parking of vehicles in the parking lots on the grounds of the Tompkins
County Airport is hereby authorized and permitted only pursuant to and in
accordance with the sections following.
