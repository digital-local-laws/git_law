## § 150-3.3 Automatic renewal. 


[Added 9-3-2002 by L.L. No. 8-2002]
Any person who has been granted exemption pursuant
to this article on five consecutive completed assessment rolls, including
any years when the exemption was granted to a property owned by a
husband and/or wife while both resided on such property, shall not
be subject to the application requirements set forth in this article.
Such exemption shall be automatically granted on each subsequent assessment
roll; provided, however, that when tax payment is made by such person
a sworn affidavit must be included with such payment, which shall
state that such person continues to be eligible for such exemption.
Such affidavit shall be on a form prescribed by the State Board.
