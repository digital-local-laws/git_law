## § 150-63 Violations; penalty for late payment; interest penalty.



A. Whenever any person shall fail to pay any tax, penalty,
or penalty of interest imposed by this article, the County Attorney
shall, upon the request of the Finance Director, bring or cause to
be brought an action to enforce the payment of the same on behalf
of the County in any court of the State of New York or of any other
state or of the United States. The person who fails to pay the tax,
penalty, or penalty of interest shall be responsible for all costs
and attorney fees associated with the proceeding.

B. Any grantor or grantee failing to file a return or
to pay any tax within the time required by this article shall be subject
to a penalty of 10% of the amount of tax due plus an interest penalty
of 2% of such amount for each month of delay or fraction thereof after
the expiration of the first month after such return was required to
be filed or such tax became due, such interest penalty shall not exceed
25% in the aggregate. If the Director of Finance determines that such
failure or delay was due to reasonable cause and not due to willful
neglect, the Commissioner shall remit, abate or waive all of such
penalty and such interest penalty.


