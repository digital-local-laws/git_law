## § 55-2 Fund established for County Treasurer.


A revolving petty cash fund in the amount of $200 is hereby established
for the office of the County Treasurer, pursuant to § 371 of the
County Law.
