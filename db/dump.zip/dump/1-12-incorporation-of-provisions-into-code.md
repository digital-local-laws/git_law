## § 1-12 Incorporation of provisions into Code.


The provisions of this local law are hereby made Article I of Chapter
1 of the Code of Tompkins County, such local law to be entitled "General Provisions,
Article I, Adoption of Code," and the sections of this local law shall be
numbered §§ 1-1 to 1-13, inclusive.
