## § 92-5 Declaration of rights.



A. The opportunity to obtain employment without discrimination
because of gender identity and expression or sexual orientation is hereby
recognized as and declared to be a civil right. The opportunity to obtain
education, the use of places of public accommodation and the ownership, use
and occupancy of housing accommodations and commercial space without discrimination
because of gender identity and expression or sexual orientation is hereby
recognized and declared to be a civil right.

(1) Employment. It shall be unlawful:

(a) For an employer or licensing agency, because of the gender
identity and expression or sexual orientation of any individual, to refuse
to hire or employ or to bar or to discharge from employment such individual
or to discriminate against such individual in compensation or in terms, conditions
or privileges of employment.

(b) For an employment agency to discriminate against any
individual because of gender identity and expression or sexual orientation
in receiving, classifying, disposing or otherwise acting upon applications
for its services or in referring an applicant or applicants to an employer
or employers.

(c) For a labor organization because of gender identity and
expression or sexual orientation of any individual to exclude or to expel
from its membership such individual or to discriminate in any way against
any of its members or against any employer or any individual employed by an
employer.

(d) For any employer or employment agency to print or circulate
or cause to be printed or circulated any statement, advertisement or publication,
or to use any form of application for employment or to make any inquiry in
connection with prospective employment, which expresses, directly or indirectly,
any limitation, specification or discrimination as to gender identity and
expression or sexual orientation, or any intent to make any such limitation,
specification or discrimination, unless based on a bona fide occupational
qualification.

(e) To deny to or withhold from any person because of gender
identity and expression or sexual orientation the right to be admitted to
or participate in a guidance program, an apprenticeship training program or
other occupational training or training program.

(f) To discriminate against any person in his or her pursuit
of such programs or to discriminate against such a person in the terms, conditions
or privileges of such programs because of gender identity and expression or
sexual orientation.

(g) To print or circulate or cause to be printed or circulated
any statement, advertisement or publication, or to use any form of application
for such programs or to make inquiry in connection with such program which
expresses, directly or indirectly, any limitation, specification or discrimination
as to gender identity and expression or sexual orientation, or any intention
to make any such limitation, specification or discrimination, unless based
on a bona fide occupational qualification.



(2) Public accommodation. It shall be unlawful discriminatory
practice for any person, being the owner, lessee, proprietor, manager, superintendent,
agent or employee of any place of public accommodation, resort or amusement,
because of the gender identity and expression or sexual orientation of any
person, directly or indirectly, to refuse, withhold from or deny to such person
any of the accommodations, advantages, facilities or privileges thereof, including
the extension of credit, or, directly or indirectly, to publish, circulate,
issue, display, post or mail any written or printed communication, notice
or advertisement, to the effect that any of the accommodations, advantages,
facilities and privileges of any such place shall be refused, withheld from
or denied to any person on account of gender identity and expression or sexual
orientation, or that the patronage or custom thereat of any person of or purporting
to be any particular gender identity and expression or sexual orientation
is unwelcome, objectionable or not acceptable, desired or solicited.

(3) Housing accommodations.

(a) It shall be unlawful:

[1] To refuse to rent or lease or otherwise to deny to or
withhold from any person or group of persons such housing accommodations because
of the gender identity and expression or sexual orientation of such person
or persons.

[2] To discriminate against any person because of his or
her gender identity and expression or sexual orientation in the terms, conditions
or privileges of any publicly-assisted housing accommodation or in the furnishing
of facilities or services in connection herewith.

[3] To cause to be made any written or oral inquiry or record
concerning the gender identity and expression or sexual orientation of a person
seeking to rent or lease any publicly-assisted housing accommodation.



(b) It shall be an unlawful discriminatory practice for the
owner, lessee, sublessee, assignee, or managing agent of, or other person
having the right to sell, rent, or lease a housing accommodation, constructed
or to be constructed, or any agent or employee thereof:

[1] To refuse to sell, rent, lease or otherwise to deny to
or withhold from any person or group of persons such a housing accommodation
because of the gender identity and expression or sexual orientation of such
person or persons.

[2] To discriminate against any person because of his or
her gender identity and expression or sexual orientation in the terms, conditions
or privileges of the sale, rental or lease of any such housing accommodation
or in the furnishing of facilities or services in connection therewith.

[3] To print or circulate or cause to be printed or circulated
any statement, advertisement or publication, or to use any form of application
for the purchase, rental or lease of such housing accommodation or to make
any record or inquiry in connection with the prospective purchase, rental
or lease of such a housing accommodation which expresses, directly or indirectly,
any limitation, specification or discrimination as to gender identity and
expression or sexual orientation, or any intent to make any such limitation,
specification or discrimination.



(c) It shall be an unlawful discriminatory practice for the
owner, lessee, sublessee, or managing agent of, or other person having the
right of ownership or possession of or the right to sell, rent or lease, land
or commercial space:

[1] To refuse to sell, rent, lease or otherwise deny to or
withhold from any person or group of persons land or commercial space because
of the gender identity and expression or sexual orientation of such person
or persons.

[2] To discriminate against any person because of his or
her gender identity and expression or sexual orientation in the terms, conditions
or privileges of the sale, rental or lease of any such land or commercial
space; or in the furnishing of facilities or services in connection therewith.

[3] To print or circulate or cause to be printed or circulated
any statement, advertisement or publication, or to use any form of application
for the purchase, rental or lease of such land or commercial space or to make
any record or inquiry in connection with the prospective purchase, rental
or lease of such land or commercial space which expresses, directly or indirectly,
any limitation, specification or discrimination as to gender identity and
expression or sexual orientation or any intent to make any such limitation,
specification or discrimination.



(d) It shall be an unlawful discriminatory practice for any
real estate broker, real estate salesman or employee or agent thereof:

[1] To refuse to sell, rent or lease any housing accommodation,
land or commercial space to any person or group of persons or to refuse to
negotiate for the sale, rental or lease, of any housing accommodation, land
or commercial space to any person because of the gender identity and expression
or sexual orientation of such person or persons, or to represent that any
housing accommodation, land or commercial space is not available for inspection,
sale, rental or lease when in fact it is so available, or otherwise to deny
or withhold any housing accommodation, land or commercial space or any facilities
of any housing accommodation, land or commercial space from any person or
group of persons because of the gender identity and expression or sexual orientation
of such person or persons.

[2] To print or circulate or cause to be printed or circulated
any statement, advertisement or publication, or to use any form of application
for the purchase, rental or lease of any housing accommodation, land or commercial
space or to make any record of inquiry in connection with the prospective
purchase, rental or lease of any housing accommodation, land or commercial
space which expresses, directly or indirectly, any limitation, specification,
or discrimination as to gender identity and expression or sexual orientation
or any intent to make any such limitation, specification or discrimination.



(e) It shall be an unlawful discriminatory practice for any
real estate board, because of the gender identity and expression or sexual
orientation of any individual who is otherwise qualified for membership, to
exclude or expel such individual from membership, or to discriminate against
such individual in the terms, conditions and privileges of membership in such
board.

(f) It shall be an unlawful discriminatory practice for any
real estate broker, real estate salesman or employee or agent thereof or any
other individual, corporation, partnership or organization, for the purpose
of inducing a real estate transaction from which any such person or any of
its stockholders or members may benefit financially, to represent that a change
has occurred or will or may occur in the composition with respect to gender
identity and expression or sexual orientation of the owners or occupants in
the block, neighborhood or area in which the real property is located, and
to represent, directly or indirectly, that this change will or may result
in undesirable consequences in the block, neighborhood or area in which the
real property is located, including but not limited to the lowering of property
values, an increase in criminal or antisocial behavior, or a decline in the
quality of schools or other facilities.

(g) Credit.

[1] It shall be an unlawful discriminatory practice for any
creditor or any officer, agent or employee thereof:

[a] In the case of applications for credit with respect to
the purchase, acquisition, construction, rehabilitation, repair or maintenance
of any housing accommodation, land or commercial space, to discriminate against
any such applicant because of the gender identity and expression or sexual
orientation of such applicant or applicants or any member, stockholder, director,
officer or employee of such applicant or applicants, or of the prospective
occupants or tenants of such housing accommodation, land or commercial space,
in the granting, withholding, extending or renewing, or in the fixing of the
rates, terms or conditions, of any such credit.

[b] To discriminate in the granting, withholding, extending
or renewing, or in the fixing of the rates, terms or conditions of, any form
of credit, on the basis of gender identity and expression or sexual orientation.

[c] To use any form of application for credit or use or make
any record or inquiry which expresses, directly or indirectly, any limitation,
specification, or discrimination as to gender identity and expression or sexual
orientation.

[d] To make any inquiry of an applicant concerning his or
her capacity to reproduce, or his or her use of advocacy of any form of birth
control or family planning.

[e] To refuse to consider sources of an applicant's
income or to subject an applicant's income to discounting, in whole or
in part, because of an applicant's gender identity and expression or
sexual orientation.



[2] Without limiting the generality of Subsection A(3)(g)[1],
it shall be considered discriminatory if, because of an applicant's or
class of applicants gender identity and expression or sexual orientation,
an applicant or class of applicants is denied credit in circumstances where
other applicants of like overall credit worthiness are granted credit; or
special requirements or conditions, such as requiring co-obligers or reapplication
upon marriage, are imposed upon an applicant or class of applicants in circumstances
where similar requirements or conditions are not imposed upon other applicants
of like overall credit worthiness.





(4) Education.

(a) It shall be an unlawful discriminatory practice for an
education corporation or association which holds itself out to the public
to be nonsectarian and exempt from taxation pursuant to the provisions of
Article 4 of the Real Property Tax Law to deny the use of its facilities to
any person otherwise qualified by reason of his or her gender identity and
expression or sexual orientation.

(b) It shall be an unlawful educational practice for an educational
institution:

[1] To exclude or limit or otherwise discriminate against
any person or persons seeking admission as students to such institution or
to any educational program or course operated or provided by such institution
because of gender identity and expression or sexual orientation; except that
nothing in this section shall be deemed to affect, in any way, the right of
a religious or denominational educational institution to select its students
exclusively or primarily from members of such religion or denomination or
from giving preference in such selection to such members or to make such selection
of its students as is calculated by such institution to promote the religious
principles for which it is established or maintained. Nothing contained herein
shall impair or abridge the right of an independent institution, which establishes
or maintains a policy of educating persons of one sex exclusively, to admit
students of only one sex.

[2] To penalize any individual because he or she has initiated,
testified, participated or assisted in any proceedings under this section.





(5) Civil rights.

(a) All persons within the jurisdiction of this County shall
be entitled to the equal protection of the laws of this County.

(b) No person, because of gender identity and expression
or sexual orientation, shall be subjected to any discrimination in his or
her civil rights, or to any harassment in the exercise thereof, by any person
or by any firm, corporation, institution, or by the County or any agency of
the County.



(6) County contracts. Any contracts to which the County of
Tompkins is the sole municipal party shall include substantially the following
provision: “The contractor hereby agrees to administer their obligation
in a manner which shall be fair and impartial to all applicants and employees
and shall not discriminate against any applicant or employee by reason of
race, color, sex, religion, age, marital status, national origin, disability,
Vietnam Era status, actual or perceived gender identity and expression or
sexual orientation, or record of prior arrest or conviction.”



B. Enforcement.

(1) Any person claiming to be aggrieved by an unlawful discriminatory
practice may, by himself or herself, or his or her attorney-at-law, sign and
file with the Tompkins County Human Rights Commission a verified complaint,
in writing, which shall state the name and address of the person/company alleged
to have committed the unlawful discriminatory practice complained of and which
shall set forth the particulars thereof and contain such information as may
be required.

(2) After the filing of any complaint, the Investigator shall
promptly serve a copy thereof upon the respondent and all persons he or she
deems to be necessary parties, and make prompt investigation in connection
therewith. Within 180 days after the complaint is filed, the Investigator
shall determine whether she or he has jurisdiction and, if so, whether there
is probable cause to believe that the person named in the complaint, hereinafter
referred to as the respondent, has engaged or is engaging in an unlawful discriminatory
practice. If the Investigator finds with respect to any respondent that it
lacks jurisdiction or that probable cause does not exist, the Investigator
shall issue and cause to be served on the complainant an order dismissing
such allegations of the said complaint as to such respondent.

(3) Investigations.

(a) The Investigator may hold fact-finding conferences, compel
the attendance of witnesses and take the testimony of any person and, in connection
thereof, require the production of evidence relating to any matter under investigation,
and take the necessary action, through the County Attorney, to enforce the
provisions of this section.

(b) Subpoenas. At the request of the Investigator the County
Attorney may issue and serve subpoenas in the manner provided for in the civil
practice law and rules compelling the attendance of witnesses, or requiring
the production of any evidence material or relevant to any investigation.
Proceedings to enforce, quash, fix conditions, or modify subpoenas shall be
governed by Article 23 of the New York Civil Practice Law and Rules.



(4) Conciliation.

(a) If in the judgment of the Investigator the circumstances
so warrant, it may, at any time after filing of the complaint, endeavor to
eliminate such unlawful discriminatory practice by conference, conciliation
and persuasion. Each conciliation agreement shall include provisions requiring
the respondent to refrain from the commission of unlawful discriminatory practices
in the future and may contain such further provisions as may be agreed upon
by the Investigator and the respondent, including a provision for the entry
in the Supreme Court of Tompkins County of a consent decree embodying the
terms of the conciliation agreement. The Investigator shall not disclose what
has transpired in the course of such endeavors.

(b) If the respondent and the Investigator agree upon conciliation
terms, the Investigator shall serve upon the complainant and the respondent
a copy of the proposed conciliation agreement. If the parties agree to the
terms of the agreement, the Investigator will arrange for a written agreement
to be executed by the parties which either party may submit to a court of
competent jurisdiction for incorporation into an order.



(5) Not later than one year from the date of a conciliation
agreement and at any other times in its discretion, the Investigator shall
investigate whether the respondent is complying with the terms of the agreement.

(6) No officer, agent, or employee of the Investigator shall
make public with respect to a particular person without his or her consent
information from reports obtained by the Investigator except as necessary
to the conduct of a proceeding under this section.

(7) Any person claiming to be aggrieved by an unlawful discriminatory
practice shall have a cause of action in any court of appropriate jurisdiction
for damages and such remedies as may be appropriate, unless such person had
filed a complaint hereunder and such complaint has been dismissed as lacking
probable cause or a conciliation agreement has been reached. If a complaint
is filed but a conciliation agreement is not reached or an agreement is reached
but subsequently determined by the Investigator to have been breached by the
respondent, such person shall maintain all rights to bring suit as if no complaint
had been filed. No person who has initiated any action in a court of competent
jurisdiction may file a complaint with respect to the same grievance under
this section.



C. A complaint pursuant to this section must be filed no
later than one year after the alleged unlawful practice.


