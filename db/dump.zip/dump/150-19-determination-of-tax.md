## § 150-19 Determination of tax.


If a return required by this article is not
filed, or if a return when filed is incorrect or insufficient, the
amount of tax due shall be determined by the County Administrator
from obtainable information. If necessary, the tax may be estimated
on the basis of external indices, such as number of rooms, location,
scale of rents, comparable rents, type of accommodations and service,
number of employees and/or other factors. Notice of such determination
shall be given to the person liable for the collection and/or payment
of the tax. Such determination shall finally and irrevocably fix the
tax unless the person against whom it is assessed, within 30 days
after giving notice of such determination, applies to the County Administrator
for a hearing, or unless the County Administrator redetermines the
same. After such a hearing, the County Administrator shall give notice
of the determination to the person against whom the tax is assessed.
The determination of the County Administrator shall be reviewable
for error, illegality, unconstitutionality, or any other reason whatsoever
by proceeding under Article 78 of the Civil Practice Law and Rules
if application thereof is made to the Supreme Court within 30 days
after the filing of the notice of such determination. A proceeding
under Article 78 of the Civil Practice Law and Rules shall not be
instituted unless the amount of any tax sought to be reviewed with
penalties and interest thereon, if any, is first deposited with the
County Administrator and an undertaking is filed with the County Administrator,
issued by a surety company authorized to transact business in this
state, approved by the Superintendent of Insurance of this state as
to solvency and responsibility, in an amount approved by a Supreme
Court Justice, to the effect that if the proceeding is dismissed or
the tax confirmed, the petitioner will pay all charges and costs which
may accrue in the prosecution of the proceeding, or, at the option
of the applicant, such undertaking filed with the County Administrator
may be in a sum sufficient to cover the taxes, penalties and interest
thereon stated in such determination plus the costs and charges which
may accrue against it in the prosecution of the proceeding. In that
event, the applicant will not be required to deposit such taxes, penalties
and interest as a condition precedent to the application.
