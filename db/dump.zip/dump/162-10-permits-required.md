## § 162-10 Permits required.


Parking of vehicles by persons or operators in any of the designated
restricted areas is prohibited unless said person or operator shall have a
parking permit duly issued by Tompkins County or otherwise granted official
permission to park in said areas, which permits shall be restricted to county
employees, elected officials, certain state employees, and handicapped individuals
designated by the County Public Works Committee, and such other persons having
business in county buildings whose circumstances warrant a special parking
permit.
