## § 1-5 Severability.


If any clause, sentence, paragraph, section, article, chapter or part
of this local law or of any local law or ordinance included in this Code now
or through supplementation shall be adjudged by any court of competent jurisdiction
to be invalid, such judgment shall not affect, impair or invalidate the remainder
thereof but shall be confined in its operation to the clause, sentence, paragraph,
section, article, chapter or part thereof directly involved in the controversy
in which such judgment shall have been rendered.
