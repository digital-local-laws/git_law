## § 150-55 Commencement date.


This tax shall apply to any conveyance occurring
on or after December 1, 2006, but shall not apply to conveyances made
on or after December 1, 2006, pursuant to binding written contracts
entered into prior to such date, provided that the date of the execution
of such contract is confirmed by independent evidence such as the
recording of the contract, payment of a deposit, or other facts and
circumstances as determined by the County Finance Director.
