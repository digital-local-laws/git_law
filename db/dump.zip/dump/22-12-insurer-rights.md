## § 22-12 Insurer rights.


The provisions of this article shall not be construed to impair, alter,
limit, or modify the rights and obligations of any insurer under any policy
of insurance.
