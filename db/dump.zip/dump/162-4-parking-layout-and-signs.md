## § 162-4 Parking layout and signs.


The parking layout and signs may be changed by the Airport Manager after
recommendation by the Commissioner of Public Works and the County Administrator.
