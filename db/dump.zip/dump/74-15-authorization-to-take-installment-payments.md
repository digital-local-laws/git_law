## § 74-15 Authorization to take installment payments.


Pursuant to § 1184 of the Real Property Tax Law, the Tax Enforcement
Officer is hereby empowered to take installment payments of delinquent taxes.
Said installment payments shall have a payment term of 24 months with payments
due every three months. The Tax Enforcement Officer shall add $1 to each delinquent
tax bill to cover the cost of notifying the taxpayer of this right. All delinquent
taxpayers shall be entitled to use this installment payment option. All installment
agreements shall be entered on or before September 30 of the year in which
the tax becomes a lien. The Tax Enforcement Officer shall collect 25% of the
tax due at the time the taxpayer signs the installment payment agreement.
The remaining seven installments are payable every quarter, with the first
one due on or before December 1, following the execution of the installment
agreement.
