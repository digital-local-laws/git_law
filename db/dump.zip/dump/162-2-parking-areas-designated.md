## § 162-2 Parking areas designated.


The manager of the Tompkins County Airport is authorized to designate
by appropriate signs, in addition to others, the following parking areas:

A. Tower area.

B. Aircraft tiedown area.

C. T-hangar area.

D. Airport tenant area.

E. Public parking area.

F. Rental vehicle parking area.


