## § 1-1 Legislative intent.


In accordance with Subdivision 3 of § 20 of the Municipal
Home Rule Law, the local laws and ordinances of Tompkins County, as codified
by General Code Publishers Corp., and consisting of Chapters 1 through 162,
together with an Appendix, shall be known collectively as the "Code of Tompkins
County," hereafter termed the "Code." Wherever reference is made in any of
the local laws and ordinances contained in the "Code of Tompkins County" to
any other local law or ordinance appearing in said Code, such reference shall
be changed to the appropriate chapter title, chapter number, article number
or section number appearing in the Code as if such local law or ordinance
had been formally amended to so read.
