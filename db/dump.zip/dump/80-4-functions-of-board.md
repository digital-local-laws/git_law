## § 80-4 Functions of Board.


The Board is authorized:

A. To promote and encourage street and highway traffic safety.

B. To formulate county-wide highway safety programs and
coordinate efforts of interested parties and agencies engaged in traffic safety
education.

C. To cooperate with local officials within the county in
the formulation and execution of traffic safety programs and activities.

D. To study traffic conditions on streets and highways within
the county, study and analyze reports of accidents and causes thereof and
recommend to the appropriate legislative bodies, departments or commissions,
such changes in rules, orders, regulations and existing law as the board may
deem advisable.

E. To conduct meetings within the county whenever and wherever
the Board shall deem it advisable and to invite to such meetings parties and
agencies, public and private, interested in traffic regulation, control and
safety education.

F. To promote safety education for drivers and pedestrians.

G. To obtain and assemble motor vehicle accident data, and
to analyze, study and consolidate such data for educational and informational
purposes.


