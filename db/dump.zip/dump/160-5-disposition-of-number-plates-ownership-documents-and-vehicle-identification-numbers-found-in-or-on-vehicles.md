## § 160-5 Disposition of number plates, ownership documents and vehicle identification numbers found in or on vehicles.



A. Number of plates. The county shall remove and store number
plates for 30 days, after which plates shall be destroyed. A list of all destroyed
plates, with the name of the last registered owner of the vehicle, shall be
submitted monthly to the Department of Motor Vehicles Division of Data Preparation
and Control, The South Mall, Swan Street, Albany, New York 12228.

B. Ownership documents. Registration, title and other ownership
documents shall be retained by the county for a period of six months, after
which they shall be disposed of in a manner approved by the Commissioner of
Motor Vehicles or his agent.

C. Vehicle identification number plates.

(1) If a vehicle is sold for reuse on a public highway, vehicle
identification number plates shall not be removed.

(2) The vehicle identification number plates of all vehicles
sold for scrap or parts shall be removed by the county and forwarded to the
Division of State Police at the State Campus, Albany, New York 12226.




