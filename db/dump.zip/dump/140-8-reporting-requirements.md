## § 140-8 Reporting requirements.



A. All parties. To the extent provided in the rules and
regulations, all persons engaged in the collection of regulated recyclables
and other recoverable materials, including but not limited to tires, lead-acid
batteries, scrap metal, clothing, through a waste reduction program, or through
any other such activities (e.g., paper drives, bottle redemption, waste exchanges,
etc.) shall provide an annual report to the Solid Waste Manager, who shall
then file a summary report with the Board of Representatives. Such information
is essential for the county to maintain data and comply with waste reduction
and recycling goals required by the New York State Department of Environmental
Conservation.

B. Haulers.

(1) All licensed haulers must maintain separate records of
recyclables collected, transported or disposed of by the licensed hauler,
as provided by the Flow Control and Hauler Licensing Law[1] and the rules and regulations thereunder.
[1]:
Editor's Note: See Article III, Facilities; Licensing of Haulers,
of this chapter.

(2) All licensed haulers shall keep records of the county-provided
notice (given pursuant to § 140-9C) given to customers who do not
comply with this article and the rules and regulations promulgated hereunder,
which records shall include: the customer's name, address, and date of issuance
of each notice. The record maintained by the licensed hauler shall be made
available for review upon request by the county, and shall be compiled and
delivered to the Solid Waste Manager on or before February 1, May 1, August
1 and November 1 of each calendar year for each preceding quarter.




