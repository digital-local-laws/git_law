## § 87-3 Flying clubs.


Flying clubs shall present the list of members to the Airport Manager
on request. The club is responsible to see that all members are familiar with
the Airport rules and regulations, and applicable security and other rules.
The County reserves the right to revoke the privilege of use of the Airport
and its facilities to any club member for violation of regulations or directives.
