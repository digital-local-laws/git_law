## § 127-3 Applicability; exemptions.



A. Generally. Nothing in this chapter shall apply to sales
or purchases conducted pursuant to statute or by order of any court, or to
any persons selling personal property at wholesale to dealers in such article.
The licensing provisions of this chapter shall not apply to merchants having
an established place of business within the county or their employees; to
farmers and truck gardeners who themselves or through their employees vend,
sell or dispose of the products of their own farms or gardens; party plans;
private sales or sales or services by prior invitation, nor shall this chapter
be construed to prevent route salesmen or other persons having established
customers to whom they make periodic deliveries from calling upon such customers
or from making calls upon prospective customers to solicit an order for future
periodic route deliveries.

B. This chapter shall not apply to solicitations by local
charitable, religious or civic organizations. Similar organizations from outside
the County of Tompkins shall be exempt from the provisions of this chapter,
but must obtain and display a certificate of exemption, which shall be issued
by the Sheriff upon payment of a fee of $5. The provisions for use and display
of this permit shall be the same as those required of any licensed transient
business.


