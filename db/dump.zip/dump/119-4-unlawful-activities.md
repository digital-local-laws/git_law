## § 119-4 Unlawful activities.



A. In Tompkins County, it shall be unlawful for any person to:

(1) Launch, haul, or attempt to enter or exit a watercraft into or from
a water body with any plant or animal, or parts thereof, visible to
the human eye in, on, or attached to any part of the watercraft, including
in live wells, bilges or confined spaces, the motor, raw water cooling
system, rudder, anchor or other appurtenance, any equipment or gear,
or trailer or any other device used to transport or launch a watercraft
that may come into contact with the water;

(2) Enter the County, or transport within the County, watercraft without
first removing by hand any and all plant or animal, or parts thereof,
visible to the human eye in, on, or attached to any part of the watercraft,
including in live wells, bilges, the motor, rudder, anchor or other
appurtenance, any equipment or gear, or the trailer or any other device
used to transport or launch a watercraft that may come into contact
with the water;

(3) Introduce, throw, dump, deposit, place, allow or cause to be propagated,
transplanted, introduced, thrown, dumped, deposited or placed in any
water body, in whatever capacity and for whatever purpose, an aquatic
invasive species.



B. In addition, any and all items removed pursuant to the requirements
of this article must be discarded away from the shoreline in such
a manner as to prevent the removed items from re-entering any water
body.


