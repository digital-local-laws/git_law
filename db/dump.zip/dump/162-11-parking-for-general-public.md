## § 162-11 Parking for general public.


The county may also set aside designated areas for parking by the general
public, with or without fee, and may contract with others for parking service.
