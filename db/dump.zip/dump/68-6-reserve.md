## § 68-6 Reserve. 


[Amended 1-14-1963 by L.L.
No. 1-1963]
A reserve in the maximum amount of $100,000 is hereby established for
the plan; such reserve shall be accumulated and replenished by including in
each annual estimate a sum not exceeding $10,000.
