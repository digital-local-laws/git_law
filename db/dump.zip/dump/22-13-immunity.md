## § 22-13 Immunity.


Except as otherwise specifically provided for in this article, the provisions
of this article shall not be construed in any way to impair, alter, modify,
abrogate, limit, or restrict any immunity to liability available to or conferred
upon any unit, entity, office, or employee of Tompkins County by, in accordance
with, or by reason of any other provision of state or federal statutory or
common law.
