## § 145-3 Clerk to keep indexed record of notices.


The Clerk of the Board of Representatives or the County Board of Representatives
shall keep an indexed record, in a separate book, of all written notices which
she shall receive of the existence of such defective, unsafe, dangerous or
obstructed condition, or of such snow or ice, which record shall state the
date of receipt of the notice, the nature and location of the condition stated
to exist, and the name and addresses of the person from whom the notice is
received.
