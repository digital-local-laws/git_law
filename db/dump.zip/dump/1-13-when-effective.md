## § 1-13 When effective.


This local law shall take effect immediately upon filing with the Secretary
of State of the State of New York.
