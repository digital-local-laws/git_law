## § 15-2 Purpose.


The purpose of this chapter is to encourage the development of preventative,
rehabilitative and treatment services through new community mental health
programs, the improvement and expansion of existing community services in
the field of mental illness, mental deficiency, epilepsy, and behavior or
emotional conditions, and the integration of community, regional and state
mental health services and facilities.
