## § 48-2 Resolution required.


Said reimbursement or payment of said moving expenses shall be authorized
only when approved by the Board of Supervisors of the County of Tompkins by
resolution duly adopted by said Board.
