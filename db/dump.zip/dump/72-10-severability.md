## § 72-10 Severability.


If any section of this article or the application thereof to any individual,
partnership, or circumstance shall be adjudged invalid or unconstitutional
by any court of competent jurisdiction, such order or judgment shall not affect,
impair or invalidate the remainder thereof, but shall be confined in its operation
to the controversy in which such order or judgment was rendered.
