## § 4-6 Staff.



A. The Tompkins County Office for the Aging shall have a
professional and an auxiliary staff to fulfill the obligations as defined
in § 4-3 entitled "Powers and duties."

B. The administrative officer of the office will be responsible
to and appointed by the Board of Representatives.

C. The number and nature of such staff will be determined
by the Board of Representatives in consultation with the New York State Office
for the Aging.


