## § 68-4 Administration.


The plan shall be administered in accordance with the provisions of
the Workmen's Compensation Law by an administrator appointed by the Board
of Supervisors.
