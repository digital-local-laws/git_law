## § 119-5 Exceptions.


The provisions of § 119-4 of this article shall not
apply to:

A. The use of the above-water portions of native or noninvasive plants
for camouflage of the watercraft for the purpose of hunting, consistent
with all applicable laws and regulations related to the use, possession
and harvesting of plants and provided that the source of any such
plant is the water body in which it is used.

B. The intentional transport of plants or animals for food, research,
or landscaping, provided they are fully and securely contained within
or on board the watercraft.

C. Dredging approved by the New York State Department of Environmental
Conservation or the appropriate regulatory agency.


