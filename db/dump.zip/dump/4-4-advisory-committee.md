## § 4-4 Advisory Committee.



A. The County Board of Representatives will appoint an Advisory
Committee of 15 members with broader geographic representation to advise the
administrative officer of such office on all operations of such an office.[Amended 2-13-1978 by L.L.
No. 1-1978]

B. Initially, 1/3 of the membership will be appointed
for one year, 1/3 for two years and 1/3 for three years, thus permitting
the Board of Representatives in subsequent years to appoint 1/3 of the
membership on a yearly basis for three-year terms. At least half of the membership
of the Committee shall include actual or potential consumers of services provided
by the county for older persons, with the remainder of the group to be broadly
representative of major public and private agencies and organizations in the
county concerned with the interests of older persons and other persons who
are interested in or have demonstrated special interests in the special needs
of the elderly. In the event of the death or resignation of any member, his
successor shall be appointed to serve for the unexpired period of the term
for which such member has been appointed. The Board of Representatives may
appoint county officials to serve ex officio on the Committee.

C. The Chairman shall be elected from the membership of
the Committee by the Committee members to serve for a term of one year. The
Chairman shall preside at all Committee meetings and represent the Committee.

D. The Vice Chairman shall be elected from the membership
of the Committee by the Committee members to serve for a term of one year.
The Vice Chairman shall, in the absence of the Chairman, act in his place.


