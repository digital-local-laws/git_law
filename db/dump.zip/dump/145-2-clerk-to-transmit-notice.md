## § 145-2 Clerk to transmit notice.


The Clerk of the Board of Representatives of the County Board of Representatives
shall transmit to the County Commissioner of Public Works within three days
after the receipt of such written notice a copy of such written notice.
