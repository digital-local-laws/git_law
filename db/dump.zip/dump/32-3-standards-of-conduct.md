## § 32-3 Standards of conduct.



A. General
prohibition on use of office or employment for private gain.

(1) A County officer or employee shall not use his or her official position
or office, or take or fail to take any action, in a manner that he
or she knows or has reason to know may result in a personal financial
benefit for any of the following persons:

(a) 
The County officer or employee;

(b) 
His or her outside employer or business;

(c) 
A customer or client;

(d) 
A relative, including a member of his or her household;

(e) 
A person or entity with which the County officer or employee
has had a financial relationship within the previous 12 months;

(f) 
Any person or entity from which the County officer or employee
has received a gift, or any goods or services for less than fair market
value, during the previous 12 months; or

(g) 
A person from whom the County officer or employee has received
election campaign contributions of more than $500 in the aggregate
during the previous 24 months.



(2) A County officer or employee shall not use his or her official position
to advance his or her private interest or the interest of others listed
in Subsection A(1) to obtain any unwarranted privileges, exemptions,
or advantages for any of the persons listed in Subsection A(1).

(3) A County officer or employee shall not use or permit the use of County
resources for personal or private purposes. A County officer or employee
shall not use County letterhead, personnel, equipment, supplies, or
resources for a nongovernmental purpose or engage in personal or private
activities during times when he or she is required to work for the
County. However, this subsection shall not be construed as prohibiting:

(a) 
Any use of County resources authorized by law or County policy;

(b) 
The use of County resources for personal or private purposes
when provided to a County officer or employee as part of his or her
compensation;

(c) 
The occasional and incidental use during the business day of
County telephones and computers for personal matters such as family
care and changes in work schedule in accordance with any established
County policy; or

(d) 
Legislators from engaging in outside employment.



(4) No County officer or employee shall knowingly cause the County to
spend more than is reasonably necessary for transportation, meals,
or lodging in connection with official travel.

(5) No County officer or employee shall misuse his or her office to obtain
a benefit for the employee or other persons or private entities.



B. Conflicts
of interest: recusal; abstention; disclosure.

(1) A County officer or employee, whether paid or unpaid, who participates
in the discussion of, or consideration of, or who gives an opinion
on, any legislation before the County Legislature must publicly disclose
on the official record the nature and extent of any direct or indirect
financial or other private interest that the officer or employee knows
or should know exists.

(2) A Legislator with such a conflict can abstain from voting if the
County Attorney so advises.

(3) A County officer or employee shall promptly recuse himself or herself
from acting or discussing a matter before the County when acting on
the matter, or failing to act on the matter, may financially affect
any of the persons listed in Subsection A(1). The act of recusal should
be considered to be an abstention under the rules of the Legislature.



C. Confidential
information.

(1) For the purposes of the Code of Ethics, and as detailed in the Public
Officers Law, all information falls into one of three categories:
the class of information which is never confidential, the class of
information that is always confidential, and the class of information
that may be confidential.

(a) 
Never confidential.

[1] 
Information that is:

[a] 
The result of an external audit;

[b] 
Statistical data;

[c] 
An instruction to staff that affects the public; or

[d] 
A final policy or determination made by the County or one of
its departments.



[2] 
Disclosure or use of such information is not restricted by the
Code of Ethics.



(b) 
Always confidential.

[1] 
Information, the disclosure of which would:

[a] 
Impair current or imminent contract awards or collective bargaining
negotiations;

[b] 
Interfere with law enforcement investigations or judicial proceedings;

[c] 
Deprive a person of his or her right to a fair trial or impartial
adjudication;

[d] 
Constitute an unwarranted invasion of privacy (NOTE: The legal
issues involved in determining whether a given act constitutes an
unwarranted invasion of personal privacy can be complicated and will
not be addressed here. Interested persons may refer to § 89,
Subdivision 2, of the aforementioned Public Officers Law of New York
State as a starting point, or contact the County Attorney.); or

[e] 
Endanger the life or safety of any person.



[2] 
Information that is always confidential also includes:

[a] 
Civil service examination questions or answers prior to the
administration of the exam;

[b] 
Computer access codes; or

[c] 
Information that is specified as nondisclosable by federal or
state law.



[3] 
No employee or officer of the County may ever disclose such
information or use such information to further a personal interest.



(c) 
Any information that does not clearly fall into just one of
the above categories may be confidential. To be certain of complying
with the Code of Ethics, all officers and employees must first request
and receive an official determination from the County Attorney that
a given piece of information is not confidential before disclosing
or making personal use of it.



(2) The restrictions on disclosure and use of confidential information
described herein apply without regard to the circumstances in which
the information was acquired and include information gained through
means other than the possessor's association with the County.



D. Nepotism.
Except as otherwise required by law:

(1) No County officer or employee, either individually or as a member
of a board, may participate in any decision specifically to appoint,
hire, promote, discipline, or discharge a relative for any County
position or any County board.

(2) No County officer or employee may directly or indirectly supervise
a relative in the performance of the relative's official duties
unless such supervision is in compliance with an individual written
plan that has been proposed by the affected department in conjunction
with the Commissioner of Personnel and reported to the appropriate
Legislative Committee to which the particular department reports.
Nothing in this policy should be construed to interfere with the appointment
of Election Commissioners and their appointed staff, although best
practice would have them conform with this nepotism portion of the
code.



E. Gifts
and gratuities.

(1) A County
officer or employee shall not solicit a gift from any person who or
entity that has received or sought a financial or material benefit
from the County or accept a gift from any person who the County officer
or employee knows or has reason to know has received or sought a financial
benefit from the County or who will be seeking such a benefit in the
future.

(2) A County officer or employee shall not request or accept anything
from any person or entity other than the County for doing his or her
County job.

(3) A County officer or employee shall not accept or receive any gifts
having a value of $50 or more, whether in the form of money, services,
loan, travel, entertainment, hospitality, thing or promise, or any
other form, under circumstances in which it could reasonably be expected
to influence the performance of official duties or was intended as
a reward for any official action.



F. Political
solicitations.

(1) Exclusive of mass advertising or solicitations, a County officer
or employee shall not directly or indirectly solicit, compel, or induce
a subordinate County officer or employee to make, or promise to make,
any political contribution, whether by gift of money, service, or
other thing of value.

(2) A County officer or employee may not act or decline to act in relation
to appointing, hiring, or promoting, discharging, disciplining, or
in any manner changing the official rank, status, or compensation
of any County officer or employee, or an applicant for a position
as a County officer or employee, or the awarding of any contract on
the basis of giving and withholding or neglecting to make any contribution
of money or service or any other valuable thing for any political
purpose.



G. Investments
in conflict with official duties.

(1) A County officer or employee shall not invest or hold any investment
directly or indirectly in any financial, business, commercial, or
other private transaction that creates a conflict with official duties.
An investment in which a County officer or employee has an interest
shall be exempt if such interest was acquired prior to the time he
or she was elected or appointed as such officer or employee, but this
subsection shall in no event authorize a renewal of any such contract
or investment. Such contract or investment is of course subject to
the disclosure and recusal provisions of the code.

(2) This subsection does not prohibit a County officer or employee from
acquiring any other investments or the following assets:

(a) 
Real property located within the County and used as his or her
personal residence;

(b) 
Less than 5% of the stock of a publicly traded corporation;
or

(c) 
Bonds or notes issued by the County and acquired more than one
year after the date on which the bonds or notes were originally issued.





H. Representation.
A County officer or employee shall not represent any person or entity
in any matter that is before the County or represent any person or
entity in any matter that involves the County. Excluded from this
prohibition is a Legislator performing his or her normal duty of constituent
representation and the County Attorney performing his or her official
duties.

I. Appearances. Except Legislators appearing with or for constituents,
a County officer or employee shall not appear before any agency of
the County, except on his or her own behalf or in his or her capacity
as an employee of the County in furtherance of his or her official
duties,


