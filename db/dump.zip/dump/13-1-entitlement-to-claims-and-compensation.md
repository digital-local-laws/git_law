## § 13-1 Entitlement to claims and compensation.


Physicians who are county officers or employees shall be entitled to
make claims and receive fees or compensation in accordance with the provisions
of the Workers' Compensation Law or the Volunteer Firefighters' Benefit Law
for compensable professional services rendered by them to or on account of
persons applying for or receiving benefits from the county in accordance with
and subject to the provisions of such laws; provided, however, that payment
of fees or compensation for such services shall not be so authorized in any
event if:

A. It is the official duty of the officer or employee to
render services;

B. The officer or employee has the power to authorize the
services of payments therefor;

C. It is the duty of the officer or employee to audit bills
or claims for the services rendered; or

D. The terms of employment of the officer or employee prohibit
or prevent him from maintaining a private practice, occupation or calling
to furnish the type of services for which he seeks the fee or compensation.


