## § 150-37 Statutory authority.


This article is enacted pursuant to § 459-c
of the Real Property Tax Law of the State of New York as enacted by
Chapter 315 of the laws of 1997.
