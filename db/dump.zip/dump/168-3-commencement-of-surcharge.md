## § 168-3 Commencement of surcharge.


The wireless communications service supplier shall begin to add such
surcharge to the billings of its customers on January 2, 2003.
