## § 150-28 Returns to be secret. 


[Amended 5-7-1991 by L.L. No. 1-1991]
Except in accordance with the proper judicial
order, or as otherwise provided by law, it shall be unlawful for the
County Administrator or any officer or employee of the County Administrator's
Office to disclose in any manner the rents or other information relating
to the business of a taxpayer contained in any return required under
this article except to such persons and at such times as necessary
to carry out this article. The officers charged with the custody of
such returns shall not be required to produce any of them or evidence
of anything contained in them in any action or proceeding in any court,
except on behalf of the County Administrator in an action or proceeding
under the provisions of this article, or on behalf of any party to
any action or proceeding under the provisions of this article when
the returns or facts shown thereby are directly involved in such action
or proceeding. In any of these events, the Court may require the production
of and may admit into evidence as much of said returns or the facts
shown thereby as are pertinent to the action or proceeding, and no
more. Nothing herein shall be construed to prohibit the delivery to
the taxpayer or his/her duly authorized representative of a certified
copy of any return filed in connection with his/her tax nor to prohibit
the publication of statistics classified so as to prevent the identification
of particular returns and the items thereof. In addition, nothing
herein shall be construed to prohibit the inspection by the County
Attorney or other legal representatives of the County of the return
of the taxpayer who shall bring action to set aside or review the
tax based thereon, or against whom an action or proceeding has been
instituted for the collection of a tax or penalty. Returns shall be
preserved for five years and thereafter until the County Administrator
permits them to be destroyed.
