## § 119-2 Intent.


The Tompkins County Legislature hereby finds and determines
that aquatic invasive species can displace native species and alter
natural ecosystems and cause negative environmental and economic impacts
such as that presently occurring with regard to the infestation by
the invasive submerged aquatic plant, Hydrilla verticillata (Hydrilla),
in Cayuga Inlet. Ultimately, residents and visitors to Tompkins County
alike are negatively impacted by the decline in quality of any water
body subjected to aquatic invasive species. It is the intent of this
article to protect the ecology of water bodies wholly or partially
located and/or accessed in Tompkins County by preventing the introduction
of any aquatic invasive species and therefore helping to protect the
environment and economy of Tompkins County.
