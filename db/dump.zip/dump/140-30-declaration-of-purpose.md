## § 140-30 Declaration of purpose.



A. The purpose and intent of this article is to prohibit
the disposal of solid waste at any location other than at properly authorized
facilities or sites and to prevent the unauthorized use of dumpsters and other
solid waste containers.

B. The Tompkins County Board of Representatives acknowledges
the growing costs associated with the disposal of solid waste and the resulting
inclination of those who may seek to avoid such costs by depositing such material
along highways, in vacant lots, on business sites, in the private dumpsters
of others and in other unauthorized places. Such activities are hereby deemed
to pose an imminent hazard to the public health, safety, and welfare of the
residents of the county.

C. The adoption and vigorous enforcement of this article
is intended to be an effective deterrent to dumping of solid waste. This article
shall be liberally construed to effectuate its objectives and purposes.


