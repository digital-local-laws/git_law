## § 68-8 Rules and regulations.


The rules and regulations hereinafter set forth are hereby adopted pursuant
to Article 5 of the Workers' Compensation Laws for the administration of the
Tompkins County Self-Insurance Plan.

A. Participation. In addition to the county, participation
in the Tompkins County Self-Insurance Plan shall be available to cities, towns
and villages. All other types of public corporations are hereby expressly
excluded from such participation.

B. Entry and withdrawal.

(1) The City of Ithaca by resolution of its Common Council,
any town in the county by resolution of its Town Board, and any village in
the county by resolution of its Board of Trustees may elect to become a participant
in the plan, provided that a certified copy of the resolution shall have been
filed with the Clerk of the Board of Supervisors on or before the preceding
July 15. Any participant may withdraw from the plan as of the end of any fiscal
year by filing with the Clerk of the Board of Supervisors on or before the
preceding July 15 a certified copy of a resolution of its governing body electing
to withdraw.

(2) The assessment percentage for such participant shown
in the last annual estimate and apportionment of costs shall be applied to
the amount of the plan's outstanding liabilities at the date of withdrawal,
to produce the amount payable by the participant. The amount payable by a
participant upon withdrawal shall be collected in full, or in such installments
and at such dates as the Board of Supervisors may determine.



C. Administration. The plan shall be administered by an
administrator appointed by the Board of Supervisors upon recommendation of
the Compensation Committee. The first such appointment shall be made at the
first meeting of the Board of Supervisors after the effective date of this
article for a term of office expiring December 31, 1957. Subsequent appointments
shall be made biannually at the organization meeting of the Board in January
of each even-numbered year for the term of office for which the then members
of such Board were elected; and any vacancy in the office of administrator
shall be filled in the manner provided by law for the filling of vacancies
in appointive county offices. The Compensation Committee of the Board shall
act in an advisory capacity to the administrator and perform such other duties
in connection with the administering of the plan as may be assigned to it
by the Board of Supervisors.

D. Annual estimate. The administrator shall annually, not
later than the 15th day of August, file with the Board of Supervisors an estimate
of the several amounts necessary for the ensuing calender year to meet the
payments with respect to the liability of participants required to be made
by the county, to pay the administrative expenses of the plan, to repay any
amounts advanced to the plan, and to provide for contributions to the reserve.
The administrator shall then determine the share of amounts chargeable to
each participant, furnish to the County Treasurer a list of the amounts payable
by each participant, and notify each participant, in writing, not later than
September 1 of the amount of its share.

E. Apportionment of costs and payments by participants.

(1) The total of the several amounts set forth in the annual
estimate shall be apportioned to each participant in the proportion that the
full valuation of its taxable real property bears to the aggregate full valuation
of all participants. The full valuation of taxable real property shall be
determined by the use of state equalization rates established pursuant to
Article 2-a of the Tax Law.

(2) The share apportioned to each town participating in the
plan shall be collected by inclusion in the next succeeding tax levy against
the taxable real property in such town. The share apportioned to each village
participating in the plan shall be paid to the County Treasurer by the Village
Treasurer not later than 30 days after the commencement of the next fiscal
year of such village following notification by the administrator of the amount
of such share. If the City of Ithaca is a participant in the plan, the share
apportioned to the city shall be paid to the County Treasurer not later than
30 days after the commencement of the next fiscal year of the city following
notification by the administrator of the amount of such share.



F. Capital reserve. The administrator shall determine from
year to year the amount required to establish or replenish the reserve and
the share of each participant therein for the ensuing calendar year; provided,
however, that the maximum amount of such reserve shall not at any time exceed
the sum of $100,000, and not more than 10% of the maximum amount of the reserve
fund shall be raised in any one calendar year.[Amended 12-26-1961 by L.L.
No. 2-1961]

G. Limitation of responsibility of the New York State Department
of Health, state aid reimbursement will be made on all New York State Department
of Health programs that are directly covered by workers' compensation in an
amount not to exceed the lesser of the following: the premiums appropriated
for any current year; or the amount equal to the workers' compensation insurance
fund reserve of $100,000.[Added 2-26-1961 by L.L.
No. 2-1961; amended 1-14-1963 by L.L.
No. 1-1963]

H. Coverage of officers. Any of the participants may bring
its officers, whether elective or appointive, within the coverage provided
by this plan by appropriate action of its governing Board, provided that a
certified copy of the resolution is filed with the Clerk of the Board of Supervisors
on or before July 15 of any year, the additional coverage to commence on the
first day of January of the following year. Such coverage may be withdrawn
in the same manner, but it shall be deemed to continue from year to year for
so long as the municipality continues its participation in the plan, unless
and until it is withdrawn in the manner herein specified.

I. Cooperation by participants and reports.

(1) Participants in the plan shall cooperate with the administrator
by promptly filing all required reports, by aiding in the investigation of
claims, by developing and enforcing safety programs and by furnishing any
additional aid or information that may be required to carry out the provisions
and the intent of the Workers' Compensation Law.

(2) Each participant shall maintain a record of all injuries
received by employees in the course of their employment. An executive officer
of the participant, or the head of the department in which the injured employee
was employed at the time of the accident, shall, within five days after the
happening of the accident, mail or deliver to the administrator a written
report of the accident on a form provided for the purpose, giving all the
information required on such form.

(3) Each participant shall file annually with the administrator
an employment report indicating by names of individuals the positions filled
or vacated. Each participant shall also file annually with the administrator
a roster of the active volunteer firemen, certified by the Chief of the Fire
Department. Forms for reports to be filed by participants pursuant to this
subsection shall be furnished by and be an expense of the plan.




