## § 140-22 Rules and regulations.



A. The Board of Representatives is authorized to promulgate,
revise, amend and publish rules, regulations and orders necessary to carry
out the purposes of this article. Such rules, regulations and orders may,
but shall not be limited to or required to, include the following:

(1) Establish or modify the disposal or other fee charged
or imposed at any county owned, operated or contracted facility, which authority
may not be delegated to a designee.

(2) Establish or modify the fee or fees charged for any solid
waste license, or renewal, required by this article, which authority may not
be delegated to a designee.

(3) Establish or modify the fee or fees charged for any permit
required by this article, which authority may not be delegated to a designee.

(4) Identify, designate and refine categories of solid waste,
including categories of acceptable solid waste.

(5) Establish and maintain standards for solid waste that
may be delivered and accepted at any county owned, operated or contracted
solid waste facility, including prohibiting one or more categories of solid
waste from being delivered or disposed of at a county owned, operated or contracted
facility.

(6) Establish the detailed requirements and procedures for
solid waste license applications and renewals, as well as license revocations
and suspensions, consistent with the provisions of this article.

(7) Determine the form, content and procedure of records
to be maintained by solid waste licensees.



B. Except as limited above, the Board of Representatives
may delegate to its designee all or part of its power to promulgate rules,
regulations and orders.


