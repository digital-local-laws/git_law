## § 135-3 Definitions.


As used in this chapter, the following terms shall have the
meanings indicated:

BOND
A commercial bond to ensure that the condition of the County
roads is not adversely impacted by high-frequency, high-impact truck
traffic. The County Legislature may accept an equivalent financial
guarantee in lieu of bond.


BOND RELEASE
A bond release given by the County Highway Manager based
on satisfactory road conditions at completion of the high-frequency,
high-impact truck traffic.


HIGH-FREQUENCY, HIGH-IMPACT TRUCK TRAFFIC
Traffic to and from a project site that generates more than
1,000 truck trips. For purposes of this chapter, a truck trip is a
trip to or from the project site involving a truck with a gross weight
of 30 or more tons (truck and load combined). A single truck makes
two truck trips if it meets the weight limit traveling to the project
site and meets the weight limit traveling from the project site.


PERMITTEE
The person responsible under this chapter to obtain a permit
regardless of whether the person in fact obtains a permit. The permittee
is the person responsible for the project generating the truck traffic.
In any instance in which another permit is required, such as a building,
drilling, or mining permit, any person who obtained any such permit
or was required to obtain such other permit shall be deemed the permittee
for purposes of this chapter. In the event no other permit is required,
the owner of any property on which the activity is taking place shall
be deemed the permittee for purposes of this chapter.


PERSON
Any individual, public or private corporation, political
subdivision, government agency, municipality, industry, copartnership,
association, firm, trust, estate, or any other legal entity whatsoever.


TEMPORARY PROJECT

A. 
Any nonpermanent activity that generates high-frequency, high-impact
truck traffic on County roads whether or not the project itself is
located in the County.

B. 
Projects include, but are not limited to, construction projects,
mining, and drilling activities. With regard to projects that require
another permit, such as a building, drilling, or mining permit, all
activities covered by that other permit are considered part of the
temporary project for purposes of this chapter.

C. 
Agricultural operations as defined by New York State Agricultural
District Law and the movement of agricultural products are excluded.
Also excluded are school buses, law enforcement vehicles, fire-fighting
vehicles, military vehicles, and municipal vehicles engaging in road
work on behalf of municipalities.



