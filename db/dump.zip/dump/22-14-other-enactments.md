## § 22-14 Other enactments.


Except as otherwise provided for in this article, benefits accorded
to employees under this article shall supplement and be available in addition
to defense or indemnification protection conferred by any other enactment
of the Tompkins County Board of Representatives.
