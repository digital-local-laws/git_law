## § 150-44 Legislative intent.



A. This real property tax exemption for historic properties,
authorized by § 444-a of the Real Property Tax Law, is being
enacted in order to achieve the following goals: to increase incentives
for property owners in historic districts to invest in the upkeep
and rehabilitation of properties; to provide an incentive for the
restoration and rehabilitation of commercial structures which qualify
as landmarks in order to provide financial advantages which may help
to attract and retain businesses in the County; to assist homeowners
who are interested in restoring their own properties, but may not
be able to afford to do so when faced with potential increases in
taxation as the result of alterations which would qualify for this
exemption; to provide financial incentives for investment in low-income
residential neighborhoods which may contain landmarked buildings or
districts designated within the area; and to provide a concrete benefit
for restoring or improving historically or architecturally significant
properties.

B. This article is intended to create a real property
tax exemption that preserves or increases the historic character of
real property located in the County of Tompkins.


