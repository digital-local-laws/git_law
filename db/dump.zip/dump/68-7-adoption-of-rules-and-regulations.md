## § 68-7 Adoption of rules and regulations.


The Board of Supervisors shall by local law adopt rules and regulations
not inconsistent with this article or with the Workmen's Compensation law
for the fair and equitable administration and operation of the plan.
