## § 140-4 Definitions.


As used in this article, the following terms shall have the meanings
indicated:

AUTHORIZED RECYCLING FACILITY
Any and all state-permitted or specifically exempt facilities for
accumulation, processing, recovery, reprocessing and/or recycling materials
which are specified in the rules and regulations promulgated pursuant to § 140-5A
of this article, including but not limited to the county's recycling dropoff
centers and to the recycling and solid waste center. This term shall exclude
incineration facilities, waste-to-energy facilities, and landfills.


BOARD OF REPRESENTATIVES
The Tompkins County Board of Representatives.


COUNTY
The County of Tompkins.


COUNTY RECYCLING HAULER
The county or a hauler under contract with the county that collects
recyclables from waste generators as part of a county-sponsored recycling
program.


COUNTY-SPONSORED RECYCLING PROGRAM
Any program sponsored or administered by the county to handle recyclable
materials, including but not limited to programs for the collection of recyclables
by county employees or agents.


ECONOMIC MARKETS
Instances in which the full avoided costs of proper collection, transportation,
and disposal of a source separated recyclable material is equal to or greater
than the cost of collection, transportation, and sale of the recyclable material,
less the amount received from the sale of the recyclable material.


EXEMPT
The status granted to any person who can demonstrate an inability
to comply with this article and who applies to the Solid Waste Manager and
receives a certificate of exemption from this article, or parts thereof, pursuant
to the rules and regulations, or who by rules and regulations promulgated
hereunder is exempt from this article or parts thereof.


HAZARDOUS WASTE

A. 
Any waste that by reason of its quality, concentration, composition
or physical, chemical or infectious characteristics may do any of the following:
cause or significantly contribute to an increase in mortality or an increase
in serious irreversible, or incapacitating reversible illness; or pose a substantial
threat or potential hazard to human health or the environment when improperly
treated, stored, transported, or disposed of or otherwise mismanaged; or any
waste that is defined or regulated as a hazardous waste, hazardous substance,
toxic substance, hazardous chemical substance or mixture, or asbestos under
applicable law, as amended from time to time, including but not limited to:
the Resource Conservation and Recovery Act, 42 U.S.C. § 6901 et
seq., and the regulations contained in 40 CFR Parts 260-281; the Toxic Substances
Control Act, 15 U.S.C. § 2601 et seq., and the regulations contained
in 40 CFR Parts 761-766; and future additional or substitute federal, state
or local laws pertaining to the identification, treatment, storage or disposal
of toxic substances or hazardous waste; except that hazardous waste shall
not include household hazardous waste which is accorded treatment as other
than hazardous waste under applicable law;

(1) 
Radioactive materials that are source, special nuclear or by-product
material as defined by the Atomic Energy Act of 1954, 42 U.S.C. § 2011
et seq., and the regulation contained in 10 CFR Part 40;

(2) 
Radioactive waste that has been deregulated or is not regulated by the
United States Environmental Protection Agency or Nuclear Regulatory Commissioner,
or the New York State Department of Health or Environmental Conservation;
or

(3) 
Solid waste so designated by the rules and regulations promulgated pursuant
to this article.






LICENSED HAULER
A person licensed by Tompkins County pursuant to the Tompkins County
Solid Waste and Haulers Licensing Local Law[1] to collect, transport or handle solid waste or regulated recyclables.


OTHER RECOVERABLE MATERIAL
Any material, substance, by-product, compound, or any other item
generated or originated within the county not treated by the waste generator
as solid waste, and separated from solid waste at the point of generation
for separate collection, donation, sale, external reuse, recycling, or reprocessing
and/or lawful disposition other than by disposal in landfills, sewage treatment
plants or incinerators. The disposition of other recoverable material is not
regulated by this article, except to the extent of certain reporting requirements
set forth in § 140-8 of this article.


PERSON
Any natural person, partnership, association, joint venture, corporation,
estate, trust, county, city, town, village, improvement district, school district,
governmental entity, or any other legal entity.


RECYCLABLE MATERIALS or RECYCLABLES
Materials that would otherwise be solid waste, and which can be collected,
separated, and/or processed, treated, reclaimed, used or reused so that its
component materials or substances can be beneficially used or reused.


RECYCLING CONTAINER
A bin or other container, whether set at curbside or at recycling
dropoff centers, supplied by the county or its designee for use by waste generators
within the county, or any other durable container readily identifiable by
a hauler as a container for recyclable materials. Containers supplied by the
county shall be used exclusively for the storage and collection of recyclables
pursuant to a county-sponsored recycling program, and such containers shall,
at all times, remain the property of the county.


RECYCLING DROPOFF CENTER
Any supervised county-coordinated facility to which a person can
deliver recyclables during designated hours and in accordance with appropriate
preparation standards and utilizing designated containers.


REGULATED RECYCLABLES or REGULATED RECYCLABLE MATERIALS
Recyclables which the waste generator has left for collection or
has delivered to a solid waste management facility for disposal, and which
are designated for source separation, pursuant to this article and the rules
and regulations. Recyclables that are not designated as regulated recyclables
may also be recycled and reused.


SOLID WASTE
All putrescible and nonputrescible solid waste materials generated
or originated within the county, including but not limited to materials or
substances discarded or rejected, whether as being spent, useless, worthless,
or in excess to the owners at the time of such discard or rejection or for
any other reason; or being accumulated, stored, or physically, chemically
or biologically treated prior to being discarded or rejected, having served
their intended use; or a manufacturing by-product, including but not limited
to garbage, refuse, waste materials resulting from industrial, commercial,
community, and agricultural activities, sludge from air or water pollution
control facilities or water supply treatment facilities, rubbish, ashes, contained
gaseous material, incinerator residue, demolition and construction debris
and offal; but not including sewage and other highly diluted water-carried
materials or substances and those in gaseous form, or hazardous waste as defined
in this article; or any unregulated recyclable materials, but shall include
regulated recyclable materials.


SOLID WASTE MANAGER
The Tompkins County Solid Waste Manager or designee thereof.


SOURCE SEPARATION
The segregation of recyclables and other recoverable materials from
nonrecyclable solid waste at the point of generation for separate collection,
donations, sale or other disposition.


WASTE GENERATOR
Any person or legal entity which produces solid waste in Tompkins
County requiring disposal.


WASTE REDUCTION PROGRAM
Programs designed to reduce the volume of solid waste, to enhance
reclamation and recovery of solid waste or recyclables otherwise destined
for the municipal waste stream, and includes recycling programs; changes to
the packaging portion of the waste stream to reduce solid waste generated;
and activities and enterprises of scrap dealers, processors and consumers.
For purposes of this definition, such waste stream reduction programs shall
not include the processing of waste for incineration or disposal by landfill
or other means.

[1]:
Editor's Note: See Article III, Facilities; Licensing of Haulers,
of this chapter.
