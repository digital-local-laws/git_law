## § 150-26 Reference to tax.


Whenever reference is made to this tax in placards
or advertisements or in any other publications, such reference shall
be substantially in the following form: "Tax on occupancy of hotel
rooms" or "occupancy tax," except that in any bill, receipt, statement,
or other evidence or memorandum of occupancy or rent charge issued
or employed by the operator, the word "tax" will suffice.
