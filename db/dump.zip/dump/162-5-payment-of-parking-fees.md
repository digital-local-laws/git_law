## § 162-5 Payment of parking fees.


All persons required to pay for parking in any paid parking area of
the airport shall pay the required parking fee prior to leaving the area or
immediately when parking in a metered space.
