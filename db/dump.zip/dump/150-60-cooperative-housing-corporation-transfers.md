## § 150-60 Cooperative housing corporation transfers.


The provisions of Article 31-G of the State
Tax Law shall govern transfers involving cooperative housing corporations.
