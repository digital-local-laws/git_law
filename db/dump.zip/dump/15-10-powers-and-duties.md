## § 15-10 Powers and duties.


Subject to the provisions of the Mental Hygiene Law of the State of
New York and the regulations of the Commissioner, the Community Mental Health
Board shall have all of the powers and duties as set forth in § 190-c
of the Mental Hygiene Law of the State of New York,[1] as the same may be amended from time to time.
[1]:
Editor's Note: the Mental Hygiene Law was recodified by L. 1972, c.
251. See now § 41.13.
