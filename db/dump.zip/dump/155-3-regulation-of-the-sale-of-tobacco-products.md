## § 155-3 Regulation of the sale of tobacco products.


No person, business, or tobacco retailer shall sell, permit to be sold,
offer for sale or display any tobacco product by means of self-service merchandising.
This section shall not apply to the sale of tobacco products in vending machines
located in a bar or in vending machines in the bar area of a food service
establishment with a valid on-premises full liquor license or in a tobacco
business.
