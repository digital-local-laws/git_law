## § 150-61 Deposit and disposition of revenue.


The Finance Director or his duly authorized
agent shall be responsible for the deposit of revenue collected or
received from the tax imposed. The Finance Director shall maintain
a system of accounts showing the revenue collected or received from
the tax imposed. All revenue derived from the imposition of such tax
shall be deposited into the general fund of the County of Tompkins.
