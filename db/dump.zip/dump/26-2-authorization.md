## § 26-2 Authorization.


The Tompkins County Probation Department is hereby designated to be
responsible for the collection and administration of a fee payment of $30
per month from each probationer who is convicted in accordance with Article
31 of the Vehicle and Traffic Law as authorized by § 257-c of the
Executive Law of the State of New York. The Tompkins County Probation Department
shall:

A. Institute collection procedures as provided for in § 420.10(6)
of the Criminal Procedure Law of the State of New York.

B. Be responsible for the collection of data on a monthly
basis regarding the number of fees imposed, the number of fees satisfied,
and the total amount of fees collected.

C. Submit all fees collected within the first 10 days following
the end of the month to the office of the Director of Finance.[Amended 10-4-1994 by L.L.
No. 6-1994]

D. Waive all or part of such fees where, because of the
indigence of the offender, payment would work an unreasonable hardship on
the person convicted, his or her immediate family, or any other person who
is dependent on the probationer for financial support.

E. Within 30 days of the adoption of this chapter, establish
specific criteria for determining eligibility and rate of fee not to exceed
$30 per month per individual probation sentence case, or criteria for exemption
from such fee.

F. Seek to enforce payment in any manner permitted by law
for enforcement of a debt.


