## § 22-2 Insurance.


The County of Tompkins shall arrange for purchase and maintain appropriate
insurance with any insurance company authorized to do business in the State
of New York for coverage against such liability.
