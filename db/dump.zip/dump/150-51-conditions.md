## § 150-51 Conditions.


No such exemption shall be granted unless the
residential property so constructed or reconstructed is the principal
place of residence of the owner.
