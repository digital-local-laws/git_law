## § 22-7 Duty to notify.


The duty to indemnify or hold harmless and defend as prescribed by this
article shall be conditioned upon:

A. Delivery by the employee to the County Attorney or to
the Chairman of the Board of Representatives of a written request to provide
for his/her defense, together with the original or copy of any summons, complaint,
process, notice, pleading or demand within 10 days after he/she is served
with such document; and

B. The full cooperation of the employee in the defense of
such action or proceeding and in defense of any action or proceeding against
Tompkins County based upon the same act or omission, and in the prosecution
of any appeal.


