## § 127-6 License fees.


The following fees shall be paid for the license herein required:

A. Where a vehicle or vehicles is or are to be used by the
applicant, the fees shall be:

(1) For the first such vehicle so used: for one year, $50;
for any period less than one year, at the rate of $10 per month, except that
the minimum fee shall be $20.

(2) For each additional vehicle so used by any one licensee:
for one year, $25; for any period less than one year, at the rate of $5 per
month, except that the minimum fee shall be $10.



B. Where no vehicle is used by the applicant, or where an
additional license is required by Subsection A of § 127-7 hereof:
for one year, $25; for any period less than one year, at the rate of $5 per
month, except that the minimum fee shall be $10.


