## § 155-2 Definitions.


The following words and phrases, whenever used in this chapter, shall
be construed as defined in this section:

BAR
As defined in Subdivision 2 of § 1399-n of the Public Health
Law.


BUSINESS
Any sole proprietorship, joint venture, corporation or other business
entity formed for profit-making purposes, including retail establishments
where goods or services are sold, as well as professional corporations and
other entities where legal, medical, engineering, architectural or other professional
services are delivered.


PERSON
Any individual, partnership, cooperative association, private corporation,
personal representative, receiver, trustee, assignee, or any other legal entity.


SELF-SERVICE MERCHANDISING
Open display of tobacco products that the public has access to without
the intervention of an employee.


TOBACCO BUSINESS
As defined as in Subdivision 13 of § 1399-n of the Public
Health Law.


TOBACCO PRODUCT
Any tobacco cigarette, cigar, pipe tobacco, smokeless tobacco, snuff
or any other form of tobacco which may be utilized for smoking, chewing, inhalation
or other manner of ingestion.


TOBACCO RETAILER
Any person or governmental entity that operates a store, stand, booth,
concession, or other place at which sales of tobacco products are made to
purchasers for consumption or use.

