## § 15-12 Powers and duties of Director.


The Director of the Community Mental Health Board shall have all powers
and duties as set forth in § 190-d of the Mental Hygiene Law,[1] as the same may be amended from time to time.
[1]:
Editor's Note: The Mental Hygiene Law was recodified by L. 1972, c.
251. See now §§ 41.05, 41.09 and 41.13.
