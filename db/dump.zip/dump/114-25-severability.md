## § 114-25 Severability.


If any section, subsection, sentence, clause,
phrase or other portion of this article is for any reason declared
unconstitutional or invalid, in whole or in part, by any court of
competent jurisdiction, such portion shall be deemed severable and
such unconstitutionality or invalidation shall not affect the validity
of the remaining portions of this article, which remaining portions
shall remain in full force and effect.
