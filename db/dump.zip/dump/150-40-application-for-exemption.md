## § 150-40 Application for exemption.


Application for such exemption must be made
by the owner or all of the owners of the property on forms prescribed
by the State Board to be furnished by the Tompkins County Assessment
Department and shall furnish the information and be executed in the
manner required or prescribed in such forms, and shall be filed in
the Assessment Department office on or before the appropriate taxable
status date.
