## § 150-30 Exempted percentage reduced to zero.


The per centum of real properly tax exemption
pursuant to § 485-b  of the Real Property Tax
Law of the real property constructed, altered, installed or improved
for the purpose of commercial, business, or industrial activity in
the County of Tompkins is hereby reduced to zero for County tax purposes.
