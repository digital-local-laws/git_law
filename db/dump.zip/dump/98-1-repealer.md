## § 98-1 Repealer.


Local Law No. 1-1983 entitled "Declaration that the County of Tompkins
will not enforce the New York State Uniform Fire Prevention and Building Code,"
adopted December 20, 1993, is hereby repealed.
