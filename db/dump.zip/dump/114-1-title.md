## § 114-1 Title.


This article shall be known as the "Annual Solid
Waste Fee Local Law."
