## § 1-3 Repeal of enactments not included in Code.


All local laws and ordinances of a general and permanent nature of Tompkins
County in force on the date of the adoption of this local law and not contained
in such Code or recognized and continued in force by reference therein are
hereby repealed from and after the effective date of this local law.
