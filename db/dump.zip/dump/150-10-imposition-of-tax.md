## § 150-10 Imposition of tax. 


[Amended 5-7-1991 by L.L. No. 1-1991; 12-5-2001 by L.L. No. 7-2001; 6-4-2002 by L.L. No. 2-2002]
On or after the fifth day of September 1989,
there is hereby imposed and there shall be paid a tax of 3% of a room
or rooms in a hotel in this County of the rent for every occupancy,
except that the tax shall not be imposed upon a permanent resident
of the hotel, nor where the rent is not more than at the rate of $4
per day. On or after the first day of May 2002, there is hereby imposed
and there shall be paid a tax of 4% of the rent for every occupancy
of a room or rooms in a hotel in this County, except that the tax
shall not be imposed upon a permanent resident of the hotel, nor where
the rent is not more than at the rate of $4 per day. On or after the
first day of December 2002, there is hereby imposed and there shall
be paid a tax of 4.5%, except that the tax shall not be imposed upon
a permanent resident of the hotel, nor where the rent is not more
than at the rate of $4 per day. On or after the first day of June
2003, there is hereby imposed and there shall be paid a tax of 5%,
except that the tax shall not be imposed upon a permanent resident
of the hotel, nor where the rent is not more than at the rate of $4
per day.
