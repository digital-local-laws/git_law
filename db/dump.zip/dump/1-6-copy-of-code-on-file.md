## § 1-6 Copy of Code on file.


A copy of the Code, in loose-leaf form, has been filed in the office
of the Clerk of the Board of Representatives of Tompkins County and shall
remain there for use and examination by the public until final action is taken
on this local law; and, if this local law shall be adopted, such copy shall
be certified by the the Clerk of the Board of Representatives of Tompkins
County by impressing thereon the Seal of the county, and such certified copy
shall remain on file in the office of said Clerk of the Board of Representatives
to be made available to persons desiring to examine the same during all times
while said Code is in effect. The enactment and publication of this local
law, coupled with the availability of a copy of the Code for inspection by
the public, shall be deemed, held and considered to be due and legal publication
of all provisions of the Code for all purposes.
