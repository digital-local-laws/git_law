## § 140-3 Declaration of purpose.


This article is adopted pursuant to the laws of the State of New York,
including General Municipal Law § 120-aa, to:

A. Institute a plan for the management of recyclables and
reusables generated or originated in Tompkins County, to promote the safety,
health and well-being of persons and property within Tompkins County; and

B. Implement the express policy of the State of New York
encouraging waste stream reduction through recycling.


