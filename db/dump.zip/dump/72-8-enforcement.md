## § 72-8 Enforcement.



A. For the purpose of this article the term “enforcement
officer” shall mean the Tompkins County Board of Health, or its designee.

B. If the enforcement officer determines after a hearing
that a violation of this article has occurred, a penalty may be imposed by
the enforcement officer pursuant to this article. Nothing herein shall be
construed to prohibit an enforcement officer from commencing a proceeding
for injunctive relief to compel compliance with this article.

C. The enforcement officer may bring an action to recover
all penalties provided in this article as well as for all cost and attorneys
fees incurred as a result of any violation of this article.

D. The owner, operator, manager, or person in charge of
any premises subject to this article shall permit the Director of the County
Health Department or designee entrance to the facility to determine compliance
with this article.


