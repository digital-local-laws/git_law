## § 1-11 Changes in previously adopted legislation; new provisions.


In compiling and preparing the local laws and ordinances for publication
as the Code of Tompkins County, no changes in the meaning or intent of such
local laws and ordinances have been made. Certain grammatical changes and
other minor nonsubstantive changes were made in one or more of said pieces
of legislation. It is the intention of the Board of Representatives that all
such changes be adopted as part of the Code as if the local laws and ordinances
had been previously formally amended to read as such.
