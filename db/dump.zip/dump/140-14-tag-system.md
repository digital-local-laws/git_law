## § 140-14 Tag system.



A. All container program solid waste placed at curbside
for collection must, to the extent practical, be placed in a garbage can or
a plastic bag.

B. All containers holding container program solid waste
collected by solid waste haulers in Tompkins County must bear a tag stating
the current disposal fee. The tag may also include a cost for hauling, administrative
and collection fees charged by the solid waste hauler if those costs are listed
separately from the disposal fee.

C. It shall be a violation of this article for any person
to place solid waste at curbside for collection without a tag required by
this article.

D. No solid waste hauler may pick up container program solid
waste unless the container holding the solid waste bears a tag required by
this article.

E. All solid waste haulers must sell tags to their customers
suitable for display on garbage cans and bags. Such tags shall be issued in
weight denominations determined by the Commissioner of Public Works or his
designee. All solid waste haulers must make single trash tags available for
purchase by the public at at least one location or by mail.

F. Trash tags shall expire at the effective date of a change
of the tipping fee charged by the county, or earlier if stated on the trash
tag. All solid waste haulers must refund the cost of the trash tag to purchasers
if the request for refund is made 90 days after the expiration date or sooner.

G. All solid waste haulers required to use the above described
tag system are required to itemize administration, collection and hauling
charges separately from trash tag fees on all billings or invoices provided
to customers.


