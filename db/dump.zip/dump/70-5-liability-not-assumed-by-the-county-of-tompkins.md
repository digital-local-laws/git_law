## § 70-5 Liability not assumed by the County of Tompkins.


Nothing contained in this chapter shall make the county responsible
for the acts of the Sheriff thereof, nor relieve said Sheriff from any liability
to which he is lawfully subject.
