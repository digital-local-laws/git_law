## § 150-20 Disposition of revenues.


All revenues resulting from the imposition of
the tax under this article shall be paid into the treasury of the
County, credited to and deposited in the general fund of the County,
thereafter to be allocated for tourism and convention development;
except, however, that the County is hereby authorized to retain up
to a maximum of 10% of such revenue to defer the necessary expenses
of the County in administering the tax. The revenue derived from the
tax, after deducting the amount provided for administering such tax,
as so authorized by this article, shall be allocated to enhance the
general economy of Tompkins County, its cities, towns and villages,
through promotion of tourist activities, conventions trade shows,
special events and other directly related and supporting activities.
