## § 15-16 State reimbursement and fees.


State reimbursement and fees charged by the clinics shall be governed
in accordance with Article 8-a of the Mental Hygiene Law and amendments thereto.
