## § 13-8 Review. 


[Amended 10-4-1994 by L.L.
No. 6-1994]
The Administrator of the Assigned Counsel Program reserves the right
to disapprove or reduce any claim for compensation received more than 90 days
after completion of services on notice to the attorney. In the event the Administrator
disapproves or reduces any such claim, the attorney may, within 30 days of
notice by the Administrator, appeal the Administrator's decision to the Advisory
Board on Indigent Representation for final review. The Advisory Board on Indigent
Representation shall consider such appeal at the next scheduled meeting thereof
and shall immediately issue a determination to the Director of Finance regarding
payment of said claim, which determination shall be binding on the Director.
