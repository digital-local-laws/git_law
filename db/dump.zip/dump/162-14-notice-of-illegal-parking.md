## § 162-14 Notice of illegal parking.


The Commissioner of Public Works or his designee shall post a notice
of illegal parking to the person or operator unlawfully parking a vehicle
in the area contrary to the provisions of this article. A copy of such notice
of illegal parking shall be delivered to the County Personnel Office.
