## § 114-11 Administration.


The County Administrator is hereby empowered
to administer this article and to issue rules, regulations and orders
as necessary or advisable to carry out the purposes of this article.
