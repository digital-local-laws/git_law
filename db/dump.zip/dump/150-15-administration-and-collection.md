## § 150-15 Administration and collection.



A. The tax imposed by this article shall be administered
and collected by the Tompkins County Administrator, or other fiscal
officers of the County as the Administrator may designate by such
means and in such manner as are other taxes which are now administered
and collected by such officers in accordance with the County Charter
and Code, or as otherwise provided by this article.

B. The tax to be collected shall be stated and charged
separately from the rent and shown separately on any record thereof
at the time when the occupancy is arranged or contracted or contracted
and charged for, and upon every evidence of occupancy or any bill,
statement or charge made for said occupancy issued or delivered by
the operator. The tax shall be paid by the occupant to the operator
as trustee for and on account of the County, and the operator shall
be liable for the tax and collection of same. The operator and any
officer of any corporate operator shall be personally liable for the
tax collected or required to be collected under this article. The
operator shall have the same right in respect to collecting the tax
from the occupant, or in respect to nonpayment of the tax by the occupant,
as if the tax were a part of the rent for the occupancy payable at
the time such tax shall become due and owing, including all rights
of eviction, dispossession, repossession and enforcement of an innkeeper's
lien that the innkeeper may have in the event of nonpayment of rent
by the occupant; provided, however, that the County Administrator
or other designated fiscal officer(s), employees or agents shall be
joined as a party in any action or proceeding brought by the operator
to collect or enforce collection of the tax.

C. The County Administrator may, wherever deemed necessary
for the proper enforcement of this article, provide by regulation
that the occupant shall file returns and pay directly to the County
Administrator the tax herein imposed, at such times as returns are
required to be filed and payment made by the operator.

D. The tax imposed by this article shall be paid upon
any occupancy on and after September 5, 1989, although such occupancy
is had pursuant to a contract, lease, or other arrangement made prior
to such date. Where rent is paid, charged, billed or falls due on
either a weekly, monthly or other term basis, the rent so paid, charged,
billed or falling due shall be subject to the tax herein imposed to
the extent that it covers any portion of the period on and after September
5, 1989. Where any tax has been paid hereunder upon any rent which
has been ascertained to be worthless, the County Administrator may,
by regulation, provide for the credit and/or refund of the amount
of such tax upon application therefor as provided in § 150-21
of this article.

E. For the purpose of the proper administration of this
article, and to prevent evasion of the tax hereby imposed, it shall
be presumed that all rents are subject to tax until the contrary is
established. The burden of proving that a rent for occupancy is not
taxable hereunder shall be upon the operator, except that, where by
regulation pursuant to Subsection C of this section, an occupant is
required to file returns and pay directly to the County Administrator
the tax herein imposed, the burden of proving that a rent for occupancy
is not taxable shall be upon the occupant. Where an occupant claims
exemption from the tax under the provisions of § 150-12
of this article, the rent shall be deemed taxable hereunder unless
the operator shall receive from the occupant claiming such exemption
a certificate duly executed by an exempt corporation or association
certifying that the occupant is its agent, representative, or employee,
together with a certificate executed by the occupant that the occupancy
is paid or to be paid by such exempt corporation or association, and
is necessary or required in the course of or in connection with the
occupant's duties as a representative of such corporation or association.
Where deemed necessary by the operator, the operator may further require
that any occupant claiming exemption from the tax furnish a copy of
a certificate issued by the County Administrator certifying that the
corporation or association therein named is exempt from the tax under
§ 150-12 of this article.


