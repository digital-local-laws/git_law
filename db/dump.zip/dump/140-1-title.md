## § 140-1 Title.


This article shall be known as the "Mandatory Recycling Law."
