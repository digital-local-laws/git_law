## § 150-3.2 Renewals. 


[Added 5-2-2000 by L.L. No. 5-2000]
Notwithstanding any other provisions of this
article, the Assessor may accept applications for renewal of exemptions
pursuant to this article after the appropriate taxable status date.
In the event that the owner, or all of the owners, of property which
has received an exemption pursuant to this article on the preceding
assessment roll fail to file the application required pursuant to
this article on or before the taxable status date, such owner or owners
may file the application, executed as if such application had been
filed on or before the taxable status date, with the Assessor on or
before the date for the hearing of complaints.
