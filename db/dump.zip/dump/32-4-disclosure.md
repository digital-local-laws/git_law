## § 32-4 Disclosure.



A. Elected
officials and key employees of Tompkins County shall file by May 15
of each year an annual disclosure statement. This shall be submitted
to the Clerk of the Tompkins County Legislature in the form prescribed
by resolution of the Tompkins County Legislature upon recommendation
of the Ethics Advisory Board. The Clerk shall retain the forms on
behalf of the Ethics Advisory Board and make them available for inspection
as detailed below.

B. The
Clerk of the Tompkins County Legislature shall make the information
submitted on annual disclosure statements available, on request, to
the members of the Ethics Advisory Board, County Attorney, County
Administrator, Director of Finance, State Auditor, Commissioner of
Personnel, District Attorney, and State Attorney General. The Clerk
shall also make the information submitted on annual disclosure statements
available pursuant to the Freedom of Information Law.[1]
[1]:
Editor's Note: See Art. 6 of the Public Officers Law.

C. The
County Attorney shall confirm filing by all required filers. Requests
for determination regarding conflicts shall be referred by the County
Attorney to the Ethics Advisory Board. If the County Attorney determines
that any required filers have not filed a correctly completed disclosure
form, the County Attorney shall report this to the appropriate supervisor.
If a member of the Tompkins County Legislature has failed to complete
and file an accurate and complete disclosure form, the County Attorney
shall report this to the Chair of the Tompkins County Legislature,
or to the Vice Chair if the Chair is in default of filing.


