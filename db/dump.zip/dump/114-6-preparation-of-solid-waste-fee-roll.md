## § 114-6 Preparation of solid waste fee roll.



A. Each parcel of improved real property situated in
the county shall be assigned to a class of parcels as set forth in
the rate schedule, based upon the use of the parcel as of the fee
status date.

B. The County Administrator shall make a reasonable effort
to ascertain the name of the owner, last known owner or reputed owner
and the use of the parcel as of the fee status date. The County Administrator
shall prepare a solid waste fee roll listing each parcel in the county,
its owner, its class as a parcel on the rate schedule, and the number
of billing units assigned to it.

C. The County Administrator shall complete the tentative
solid waste fee roll on or about May 1 and shall file a copy with
the County Division of Solid Waste and the Division of Budget and
Finance. The County Administrator shall forthwith cause a notice of
such filing to be published once in the official newspaper of the
county on or about May 8. The notice shall state that a tentative
solid waste fee roll has been completed; that a copy has been filed
with the County Division of Solid Waste and the Division of Budget
and Finance and may be examined by any person during regular business
hours until the third Tuesday in May; and that an appeal must be filed
with the County Administrator c/o the Solid Waste Manager on or before
June 1. Such notice shall also state the date, time and place of the
meeting or meetings of the Appeals Board.[Amended 3-1-1994 by L.L. No. 1-1994]

D. Within seven business days following the filing of
the tentative solid waste fee roll, the County Administrator shall
mail to each owner of real property for which a change from the previous
year has been made, a notice setting forth any reclassification of
such parcel on the solid waste fee roll or any change in the number
of billing units assigned to a parcel. Such notice shall also state
that an appeal must be filed with the County Administrator on or before
June 1. Such notice shall also state the date, time and place of the
meeting or meetings of the Appeals Board. Failure to mail such notice
or failure of the owner to receive the notice shall not prevent the
charging, collection and enforcement of the annual solid waste fee
against the owner and property.

E. Appeals with respect to the classification of a parcel,
or property measurements (e.g. square footage, number of living units,
etc.) may be filed with the County Administrator on or before June
1. Complainants shall file a statement under oath, specifying the
parcel of property, why the assigned classification or measurement
is erroneous or illegal, what the complainant believes is the correct
classification or measurement, and a brief description of the facts
supporting the claim. The statement must be made by the owner of the
parcel in question or by some other person authorized by the owner
to make the statement who has knowledge of the facts stated therein.

F. The Appeals Board shall meet to hear appeals on specified
dates between June 1 and June 15. The Appeals Board shall consider
all complaints filed with them, whether or not the complainant appears
in person before the Appeals Board. Any complainant appearing before
the Appeals Board may be represented by counsel and may offer evidence
in support of the claim. The Appeals Board shall render a written
decision on each complaint, determining the correct classification,
property measurement and/or number of billing units of said parcel,
and shall mail such decision to the complainant on or before July
1, setting forth the basis for the determination.

G. The County Administrator shall complete the solid
waste fee roll, including the determinations of the Appeals Board,
and file such completed roll with the County Division of Solid Waste
and the Division of Budget and Finance on or about July 1. When the
completed roll has been filed, the County Administrator shall forthwith
cause a notice to be published in the official newspaper of the county,
stating that the solid waste fee roll has been completed and filed
with the County Division of Solid Waste and the Division of Budget
and Finance.[Amended 3-1-1994 by L.L. No. 1-1994]

H. For purposes of this article, the Appeals Board shall
consist of three persons, appointed by the Board of Representatives,
who shall not be elected or appointed officials of Tompkins or of
any local municipality within Tompkins County. Each member of the
Appeals Board shall serve for specified terms to be determined by
the Board of Representatives.


