## § 15-11 Director.


The Director of the Community Mental Health Board shall be a psychiatrist
appointed by the Community Mental Health Board whose qualifications meet standards
fixed by the State Commissioner of Mental Hygiene. Said Director need not
be a resident of the county, and he may be employed on a full- or part-time
basis.
