## § 110-5 Certain Cornell University switches exempt.


The surcharge herein shall not apply to Cornell
University, A.T.T. switch 85 with exchange 253, 254, and 255.
