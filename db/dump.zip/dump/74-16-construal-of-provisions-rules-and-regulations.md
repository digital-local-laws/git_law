## § 74-16 Construal of provisions; rules and regulations.


Nothing contained herein shall be construed to supersede or replace
applicable state law. The County Finance Director is empowered to draft the
necessary rules and procedures to implement this article.
