## § 160-1 Definition of abandoned vehicle.


For purposes of this chapter, a motor vehicle shall be deemed to be
an abandoned vehicle if left unattended:

A. With no number plates affixed thereto, for more than
six hours on any highway or other public place.

B. For more than 24 hours on any highway or other public
place, except a portion of a highway or public place on which parking is legally
permitted.

C. For more than 48 hours, after the parking of such vehicle
shall have become illegal, if left on a portion of a highway or public place
on which parking is legally permitted.

D. For more than seven days on property of another if left
initially without permission of the owner.


