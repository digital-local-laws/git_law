## § 150-57 Liability for tax.



A. The real estate transfer tax shall be paid by the
grantor. If the grantor has failed to pay the tax or if the grantor
is exempt from such tax, the grantee shall have the duty to pay the
tax. Where the grantee has the duty to pay the tax because the grantor
has failed to pay, such tax shall be the joint and several liability
of the grantor and the grantee.

B. For the purpose of the proper administration of this
article and to prevent evasion of the tax hereby authorized, it shall
be presumed that all conveyances are taxable. Where the consideration
includes property other than money, it shall be presumed that the
consideration is the fair market value of the real property or interest
therein. These presumptions shall prevail until the contrary is proven,
and the burden of proving the contrary shall be on the person liable
for payment of the tax.


