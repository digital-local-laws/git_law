## § 1-2 Continuation of existing provisions.


The provisions of the Code, insofar as they are substantively the same
as those of local laws and ordinances in force immediately prior to the enactment
of the Code by this local law, are intended as a continuation of such local
laws and ordinances and not as new enactments, and the effectiveness of such
provisions shall date from the date of adoption of the prior local law or
ordinance. All such provisions are hereby continued in full force and effect
and are hereby reaffirmed as to their adoption by the Board of Representatives
of Tompkins County, and it is the intention of said Board that each such provision
contained within the Code is hereby reaffirmed as it appears in said Code.
Only such provisions of former local laws and ordinances as are omitted from
this Code shall be deemed repealed or abrogated by the provisions of § 1-3
below.
