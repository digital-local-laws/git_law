## § 32-1 Introduction.


Pursuant to the provisions of § 806 of the General
Municipal Law, the Tompkins County Legislature recognizes that there
is a need for clear and reasonable standards of ethical conduct. Public
officers and employees must observe a high degree of moral conduct
to maintain public confidence. It is the purpose of this chapter to
set forth these rules of ethical conduct for the officers and employees
of Tompkins County. These rules shall serve as a guide for official
conduct with regard to disclosure of interests in legislation before
the local governing body, holding of investments in conflict with
official duties, future employment, and such other standards as may
be deemed advisable.
