## § 114-12 Correction of errors.


The Board of Representatives may authorize the
correction of an error in the solid waste fee roll based upon a petition
subscribed by the County Administrator, and, when it shall appear
that such annual solid waste fee has not been paid because of errors
or omissions not the fault of the owner, may modify or waive the penalties,
charges, costs and interest to be paid on such fee.
