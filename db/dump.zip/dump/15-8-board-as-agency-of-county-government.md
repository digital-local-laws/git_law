## § 15-8 Board as agency of county government.


The Community Mental Health Board shall be an agency of the county and
subject to the laws and requirements relating to such agency.
