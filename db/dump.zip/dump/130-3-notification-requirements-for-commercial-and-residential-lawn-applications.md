## § 130-3 Notification requirements for commercial and residential lawn applications.


The provisions in this section are adopted in their entirety and without
exception, pursuant to § 33-1004 of the New York Environmental Conservation
Law.

A. Retail consumer information sign. All retail establishments
that sell general use pesticides for commercial or residential lawn application
shall display a sign meeting standards established by the Commissioner pursuant
to Subdivision 1 of § 33-1005 of the Environmental Conservation
Law, in a conspicuous place, and such sign shall be placed as close as possible
to the place where such pesticides are displayed.

B. Prior notification of commercial lawn applications.

(1) At least 48 hours prior to any commercial lawn application
of a pesticide, the person or business making such application shall supply
written notice, as defined in Subdivision 3 of § 33-1005 of the
Environmental Conservation Law, to:

(a) Occupants of all dwellings on abutting property with
a boundary that is within 150 feet of the site of such application; and

(b) Owners, owners' agents, or other persons in a position
of authority for all other types of premises that are on abutting property
with a boundary that is within 150 feet of the site of such application. Owners
or owners' agents of multiple-family dwellings and for all other types of
premises, owners, owners' agents or other persons in a position of authority
shall post such written notice in a manner specified by the Commissioner.



(2) Such prior notification provisions shall not apply to
the following:

(a) The application of antimicrobial pesticides and antimicrobial
products as defined by the Federal Insecticide, Fungicide, and Rodenticide
Act (FIFRA) in 7 U.S.C. Section 136 (mm) and 136 q (h) (2);

(b) The use of an aerosol product with a directed spray,
in containers of 18 fluid ounces or less, when used to protect individuals
from an imminent threat from stinging and biting insects, including venomous
spiders, bees, wasps and hornets. This section shall not exempt from notification
the use of any fogger product or aerosol product that discharges to a wide
area;

(c) The use of nonvolatile insect or rodent bait in a tamper-resistant
container;

(d) The application of a pesticide classified by the United
States Environmental Protection Agency as an exempt material under 40 CFR
Part 152.25;

(e) The application of a pesticide which the United States
Environmental Protection Agency has determined satisfies its reduced-risk
criteria, including a biopesticide;

(f) The use of boric acid and disodium octaborate tetrahydrate;

(g) The use of horticultural soap and oils that do not contain
synthetic pesticides or synergists;

(h) The application of a granular pesticide, where "granular
pesticide" means any ground-applied solid pesticide that is not a dust or
powder;

(i) The application of a pesticide by direct injection into
a plant or the ground;

(j) The spot application of a pesticide, where "spot application"
means the application of pesticide in a manually pressurized or nonpressurized
container of 32 fluid ounces or less to an area of ground less than nine square
feet;

(k) The application of a pesticide to the ground or turf
of any cemetery; and

(l) An emergency application of a pesticide when necessary
to protect against an imminent threat to human health; provided, however,
that prior to any such emergency application, the person providing such application
shall make a good-faith effort to supply the written notice required pursuant
to this chapter. Upon making an emergency application, the person making such
application shall notify the Commissioner of the New York State Department
of Health, using a form developed by such Commissioner for such purposes that
shall include minimally the name of the person making such application, the
pesticide business registration number or certified applicator number of the
person making such application, the location of such application, the date
of such application, the product name and United States Environmental Protection
Agency registration number of the pesticide applied and the reason for such
application.





C. Posting of residential lawn applications.

(1) All persons performing residential lawn applications
treating an area more than 100 square feet shall affix markers to be placed
within or along the perimeter of the area where pesticides will be applied.
Markers are to be placed so as to be clearly visible to persons immediately
outside the perimeter of such property. Such markers shall be posted at least
12 inches above the ground and shall be at least four inches by five inches
in size.

(2) Such markers shall be in place on the day during which
the pesticide is being applied and shall instruct persons not to enter the
property and not to remove the signs for a period of at least 24 hours. Such
instruction shall be printed boldly in letters at least 3/8 of an inch
in height.




