## § 13-7 Restriction.


Claims submitted more than 90 days after completion of services shall
be accompanied by an affidavit by the attorney to the Administrator of the
Assigned Counsel Program certifying that the attorney has not previously applied
for payment or been paid for the services in question, and explaining the
reasons for delay in submission.
