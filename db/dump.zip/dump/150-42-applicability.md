## § 150-42 Applicability.


This article shall be applicable to the County
tax for the year 1999 and thereafter and the provisions of said article
shall govern the granting of an exemption under § 459-c
of the Real Property Tax Law, notwithstanding any contrary provisions
of the section.
