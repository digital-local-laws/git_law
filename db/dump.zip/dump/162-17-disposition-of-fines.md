## § 162-17 Disposition of fines.


All fines assessed by the Municipal Court shall become the property
of the municipality.
