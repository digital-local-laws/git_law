## § 70-2 Status of existing employees.


All such deputies and employees of the Sheriff of Tompkins County who
have served on a permanent full-time basis for one year in duly established
positions immediately preceding June 26, 1984 shall continue to hold such
positions on a permanent basis without examination, and shall have all the
rights and privileges of the Civil Service jurisdictional classification to
which such positions may be allocated; provided, however, that all such employees
employed for less than one year in their respective position immediately preceding
June 26, 1984 of this chapter shall be deemed qualified for provisional or
noncompetitive class appointment as may be appropriate to their position,
and shall be further deemed qualified to participate in the next scheduled
open competitive examination to be given for such position if then still employed
in the office of the Sheriff. On or after June 26, 1984, all new positions
created and vacancies occurring in existing positions shall be filled in accordance
with Civil Service Law of the State of New York and the Tompkins County Civil
Service Rules and appendices.
