## § 30-2 Boundaries.


 The boundaries of said areas to be included
in said Empire Zone shall be as set forth in Schedule A, which is
attached hereto and made a part hereof.[1]
[1]:
Editor's Note: Schedule A is on file in the
County offices.
