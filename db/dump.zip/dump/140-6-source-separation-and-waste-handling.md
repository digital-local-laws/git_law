## § 140-6 Source separation and waste handling.



A. Solid waste generated or originated within the county
that is left for collection or that is delivered by the waste generator to
a solid waste management facility shall be handled and disposed of as follows:

(1) Prior to initial collection or transport, such solid
waste shall be source separated by the waste generator into regulated recyclables
and remaining solid waste as provided in the rules and regulations promulgated
hereunder.

(2) Source separated regulated recyclables shall not be commingled
with other solid waste during collection, transportation, processing, or storage
following collection.

(3) All source separated regulated recyclables must be either
collected by a licensed hauler or county recycling hauler, delivered to a
recycling dropoff center or authorized recycling facility, or handled through
a waste reduction program.

(4) Any waste generator using a county recycling dropoff
center or authorized recycling facility shall source-separate regulated recyclable
material from other solid waste, and shall dispose of regulated recyclables
in separate containers that shall be made available at each dropoff center
or authorized recycling facility. Once deposited in the containers provided,
all recyclable materials become the property of Tompkins County.



B. Disposal of solid waste that is barred from authorized
recycling facilities by rules, regulations, or orders promulgated pursuant
to § 140-5 of this article, or by any other law, regulation, or
ordinance, shall not otherwise be regulated by this article.

C. No hazardous waste and no solid waste other than recyclable
materials may be put in a recycling container or delivered to a recycling
dropoff center or authorized recycling facility.

D. No facility other than an authorized recycling facility
or a waste reduction program shall accept regulated recyclables that have
been source separated.

E. No person shall deliver or dispose of solid waste at
any solid waste management facility unless the regulated recyclables have
been separated and removed from the solid waste for separate handling.


