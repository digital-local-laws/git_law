## § 114-18 Judicial review.


Any determination made hereunder by the County
of Tompkins shall be reviewable pursuant to Article 78 of the Civil
Practice Law and Rules.
