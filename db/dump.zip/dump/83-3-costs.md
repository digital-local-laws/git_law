## § 83-3 Costs.


The cost of all the items furnished for such Permanent Personal Registration
and the annual cost of the operation thereof, except as otherwise provided
by law, shall be a charge upon the County of Tompkins.
