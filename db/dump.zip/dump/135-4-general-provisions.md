## § 135-4 General provisions.



A. The County Legislature determines that high-frequency, high-impact
truck traffic associated with temporary projects would materially
injure County roads.

B. Upon a determination by the County Highway Manager that a temporary
project may damage a County highway as a result of high-impact, high-frequency
truck traffic on the County highway, the Highway Manager shall erect
signs on the appropriate sections of County highways setting forth
the notice that such vehicles are excluded, and the notice shall also
be published in the official newspaper in Tompkins County.

C. Any permittee may apply to the County Highway Department for a permit
providing for an appropriate exemption for the vehicles serving the
temporary project. Such permit shall be granted, upon appropriate
terms and conditions, if the vehicles are performing essential local
pickup or delivery. For purposes of this chapter, pickup and delivery
associated with New York State-permitted mining or gas-drilling operations
shall be deemed essential local pickup or delivery.

D. Any such permit shall designate the route(s) to be traversed and
contain other reasonable restrictions or conditions deemed necessary
by the County Highway Manager. The conditions may include, but not
be limited to, requiring the permittee to make road improvements to
ensure that the roads have the strength and capacity to handle the
anticipated traffic. The permit shall be carried on all vehicles serving
the project and shall be open to inspection by any peace officer acting
pursuant to his special duties, or police officer. Such permit shall
be for the duration of the temporary project.

E. In order to obtain a permit, the permittee must submit a permit application
to the County Highway Department, which shall include all information
required by the County Highway Manager, including but not limited
to vehicle identification and owners/operators, vehicle weights, load
weights, materials carried, route(s) to be followed from the state
highway to the site, duration of activity (beginning date and end
date), frequency of trips and times of operation. The applicant shall
pay a permit fee to be established by the County Legislature, but
in no event shall the fee be less than $50.

F. The County Highway Manager may require the permittee to submit documentation
(including, but not limited to, photographs and videos) of the condition
of the roads, shoulders, and all structures (culverts, bridges, etc,)
that will be traversed by the permitted traffic as a condition of
the permit.

G. In addition to the restrictions on routes and other reasonable restrictions,
the County Highway Manager will decide if the scope of work is such
that a bond is required, and the amount of any such bond. The determination
of the need and amount of any bond shall be based on a determination
of potential damage to County roads based on the truck routes, weight
of the vehicles, frequency of travel, seasonal conditions and the
type-category (classification) of the roads on the approved routes.

H. A permittee aggrieved by a determination of the Highway Manager regarding
the need for or conditions of a permit may, within 10 days of the
determination, appeal to the County Administrator. No action inconsistent
with the determination of the County Highway Manager shall take place
pending the determination of the County Administrator.

I. The permittee shall be responsible for assuring that the high-frequency,
high-impact truck traffic does not prevent any impacted County road
from remaining in safe and usable condition for all legal uses of
the road throughout the duration of the temporary project.

J. Upon completion of the high-frequency, high-impact truck traffic
project, the permittee will apply to the Highway Manager for a bond
release. Upon inspection of the traveled roads, as necessary, the
Highway Manager may approve the release of the bond. If the release
is not approved, the Highway Manager will specifically document the
tasks that must be accomplished in order for the bond to be released,
which may include, but not be limited to, the payment of money for
the repair to damaged roads. The permittee must remedy the specified
problems before the bond may be released.

K. If the permittee does not comply with this chapter and all the terms
and conditions of the permit and operate within the parameters specified
on the permit, the permit may be revoked at the discretion of the
Highway Manager.

L. In the event that high-frequency, high-impact truck traffic uses
any County roads without the required valid permit, the Highway Manager,
any law enforcement officer or code enforcement officer has the authority
to deny access to the roads and, in cases where a County permit was
required, to shut down the project. This relief is in addition to
any and all damages and penalties.

M. The permittee will be responsible for the repair of any damages that
occur to any County road when a project proceeds with or without a
proper permit, as well as for all fines and penalties specified in
this chapter.

N. In lieu of obtaining a permit, any person who may be responsible
to obtain a permit may enter into a road use agreement with the County
although the County has no obligation to enter into a road use agreement.
In such case the requirements shall be governed by the agreement,
rather than by permit conditions.


