## § 168-1 Findings.


The Tompkins County Legislature, in order to provide for the protection
of the health, safety, and welfare of persons in the County, finds it in the
public interest for there to be a surcharge on wireless communications services
operating in Tompkins County.
