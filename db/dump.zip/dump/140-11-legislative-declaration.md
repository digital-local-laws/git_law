## § 140-11 Legislative declaration.



A. It is hereby declared that waste stream recycling and
reduction is of importance to the health, safety, and welfare of the residents
of the County of Tompkins.

B. It is further declared that the imposition of solid waste
disposal costs upon generators of solid waste on the basis of the weight of
solid waste disposed of provides a necessary incentive to reduce the generation
of solid waste by recycling and waste reduction.


