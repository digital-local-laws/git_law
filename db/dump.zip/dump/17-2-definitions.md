## § 17-2 Definitions.


As used in this chapter, the following terms shall mean and include:

ACTING CHAIRMAN
A member of the Board of Supervisors who is elected at the organization
meeting each year to serve as Chairman of the Board in the absence of the
Chairman, with all of the powers and duties of the Chairman, who shall serve
as such Acting Chairman in the event of an attack or public disaster as defined
in this section.


ATTACK
Any attack, actual or imminent, or series of attacks by an enemy
or foreign nation upon the United States causing, or which may cause, substantial
damage or injury to civilian property or persons in the United States in any
manner by sabotage or by the use of bombs, shell fire or nuclear, radiological,
chemical, bacteriological or biological means or other weapons or processes.


DEPUTY CHAIRMAN
Those members of the Board of Supervisors duly appointed by the Chairman
of the Board at the organization meeting each year to serve as Chairman of
the Board with all the Chairman's powers and duties in the absence of the
Chairman and the Acting Chairman by reason of attack or public disaster as
defined in this section.


DULY AUTHORIZED DEPUTY
A person authorized to perform all the powers and duties of a public
office in the event that the office is vacant or at such times as it lacks
administration due to the death, absence or disability of the incumbent officer
where such authorization is provided pursuant to the provisions of any general,
special or local law other than this chapter.


EMERGENCY INTERIM SUCCESSOR
A person designated pursuant to this chapter, exclusive of the Acting
Chairman and Deputy Chairman as outlined in this section, for possible temporary
succession to the power and duties, but not the office, of a county officer
in the event that neither such officer nor any duly authorized deputy is able,
due to death, absence from the county or other physical, mental or legal reasons,
to perform the powers and duties of the office.


PUBLIC DISASTER
A disaster, catastrophe or emergency, actual or imminent, of such
unusual proportions or extent that: a substantial number of the residents
of the County of Tompkins either sustain injury, become ill, are infected
with disease, have their lives imperiled, are killed or die as the result
of injury, disease or exposure, or the property of a substantial number of
such residents is imperiled, damaged or destroyed; and it is necessary and
essential in the interest of public safety, health and welfare that the continuity
of the government of the County of Tompkins be assured in order that it be
enabled to function properly and efficiently and to exercise its essential
powers in meeting emergency conditions. Such disasters, catastrophes and emergencies
may include but shall not be limited to conflagrations, explosions, earthquakes
or other convulsions of nature, floods, tidal waves, pestilence, riots, insurrections,
storms, prolonged failure of electric power or essential transportation services,
or any incident or occurrence which causes or threatens to cause danger to
life, health or property from exposure to noxious materials or radiation.

