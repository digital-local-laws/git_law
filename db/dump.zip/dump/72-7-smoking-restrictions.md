## § 72-7 Smoking restrictions.



A. Smoking shall not be permitted and no person shall smoke
in the following areas:

(1) Places of employment;

(2) Bars;

(3) Food service establishments.



B. This article shall in no way limit any restriction on
smoking imposed by state law.

C. The exceptions and defenses that exist in Article 13-E
of State Public Health Law as of July 25, 2003, are incorporated into this
article.


