## § 90-3 Additional fees.


In addition to the $10 for the first impoundment of any dog owned by
any person as provided by § 118 Subdivision 4(a) of the Agriculture
and Markets Law, there shall be paid $3 for each additional 24 hours of part
thereof following the first 24 hours of first impoundment.
