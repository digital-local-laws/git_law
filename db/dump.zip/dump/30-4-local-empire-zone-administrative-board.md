## § 30-4 Local Empire Zone Administrative Board.



A. Pursuant to Article 18-B of the General Municipal
Law, a Local Empire Zone Administrative Board is hereby established
to consist of not less than six members.

B. All appointments to the Board shall be made by the
Tompkins County Legislature.

C. The members shall not include the Local Empire Zone
Certification Officer and shall include a representative of local
business, organized labor, financial institutions, local educational
institutions, community organizations and at least one resident of
the Empire Zone.

D. The Chairperson of the Board shall be the Tompkins
County Commissioner of Planning.

E. The Local Empire Zone Administrative Board shall perform
all duties required of it pursuant to § 963(b) of the General
Municipal Law.


