## § DL-1 Disposition of legislation.







Enactment


Adoption Date


Subject


Disposition






L.L. No. 3-1999


8-3-1999


Crimes Records Management System 911 surcharge


Expired




L.L. No. 4-1999


8-3-1999


Retirement incentive program


NCM




L.L. No. 5-1999


9-21-1999


Adoption of Code


Ch. 1, Art. I




L.L. No. 1-2000


3-7-2000


Traffic Safety Board amendment


Ch. 80




L.L. No. 2-2000


3-7-2000


Taxation: exemption for historical properties


Ch. 150, Art. VII




L.L. No. 3-2000


4-4-2000


Senior citizens tax exemption amendment


Ch. 150, Art. I




L.L. No. 4-2000


4-4-2000


Tax exemption for disabled persons amendment


Ch. 150, Art. VI




L.L. No. 5-2000


5-2-2000


Senior citizens tax exemption amendment


Ch. 150, Art. I




-----


5-9-2000


Sanitary Code amendment


Arts. I, IV, VI, IX and XI




L.L. No. 6-2000


8-1-2000


Retirement incentive program


NCM




L.L. No. 7-2000


9-19-2000


Sale of tobacco settlement rights


NCM




L.L. No. 8-2000


11-21-2000


E-911: call routing


Ch. 110, Art. II




L.L. No. 1-2001


3-6-2001


Tax exemption for disabled persons amendment


Ch. 150, Art. VI




L.L. No. 2-2001


3-6-2001


Taxation: exemption for living quarters for
parents and grandparents


Ch. 150, Art. VIII




L.L. No. 3-2001


5-31-2001


Election districts amendment


Ch. 28




L.L. No. 4-2001


6-19-2001


Charter amendment: workforce development


Art. 25




L.L. No. 5-2001


11-7-2001


Charter amendment: vacancies on Board of Representatives


Temporary measures




L.L. No. 6-2001


12-5-2001


Hotel room occupancy tax amendment


Ch. 150, Art. II




L.L. No. 7-2001


12-5-2001


Hotel room occupancy tax amendment


Ch. 150, Art. II




L.L. No. 8-2001


12-18-2001


Charter amendment


Arts. 3, 4 and 27A




L.L. No. 1-2002


4-16-2002


Hotel room occupancy tax amendment


Ch. 150, Art. II




L.L. No. 2-2002


6-4-2002


Hotel room occupancy tax amendment


Ch. 150, Art. II




L.L. No. 3-2002


7-2-2002


Retirement incentive program


NCM




L.L. No. 4-2002


7-16-2002


Airport


Ch. 87




L.L. No. 5-2002


8-6-2002


Charter amendment: Department of Planning


Superseded by L.L. No. 1-2003




L.L. No. 6-2002


8-6-2002


Charter amendment: Department of Emergency Response


Superseded by L.L. No. 1-2003




L.L. No. 7-2002


8-20-2002


Empire Zones


Superseded by L.L. No. 5-2005




L.L. No. 8-2002


9-3-2002


Senior citizens tax exemption amendment


Ch. 150, Art. I




L.L. No. 9-2002


10-1-2002


Surcharge on wireless communications


Ch. 168




L.L. No. 10-2002


8-6-2002


Charter amendment: vacancies on Board of Representatives


Superseded by L.L. No. 1-2003




L.L. No. 11-2002


12-17-2002


Neighbor notification for pesticides


Ch. 130, Art. I




L.L. No. 1-2003


4-1-2003


Charter revision


Charter




L.L. No. 2-2003


5-20-2003


Motor vehicle use fee amendment


Ch. 114, Art. II




L.L. No. 3-2003


8-5-2003


Smoking in bars, food-service establishments
and work places


Ch. 72, Art. II




L.L. No. 1-2004


2-17-2004


Antidiscrimination


Ch. 92




-----


4-13-2004


Sanitary Code amendment


Art. XIII




L.L. No. 2-2004


10-5-2004


Charter amendment: Special Negotiating Committee


§ C-2.08




L.L. No. 3-2004


10-19-2004


Charter amendment: failure to attend meetings


§ C-2.20




L.L. No. 1-2005


5-17-2005


Taxation: exemption for historic barns


Ch. 150, Art. IX




L.L. No. 2-2005


5-17-2005


Taxation: exemption for improvements to property
made pursuant to Americans With Disabilities Act of 1990


Ch. 150, Art. X




L.L. No. 3-2005


7-19-2005


Charter amendment


§ C-10.01 and Art. 11




L.L. No. 4-2005


9-6-2005


Taxation: alternate veterans tax exemption


Ch. 150, Art. V




L.L. No. 5-2005


9-20-2005


Empire Zones


Ch. 30




-----


10-11-2005


Sanitary Code amendment


Arts. I and IX




L.L. No. 6-2005


12-20-2005


Charter amendment


§ C-4.02.20




L.L. No. 1-2006


9-5-2006


Real estate transfer tax


Ch. 150, Art. XI




L.L. No. 1-2008


5-20-2008


Code of Ethics amendment


Ch. 32




L.L. No. 2-2008


9-2-2008


Fees: enhanced personal-privacy protection for
recorded documents


Ch. 114, Art. III




L.L. No. 1-2009


11-4-2009


E-911: implementation of system amendment


Ch. 110, Art. I




L.L. No. 1-2011


9-6-2011


Road preservation


Ch. 61




L.L. No. 2-2011


10-4-2011


2012 tax levy limit override


NCM




L.L. No. 1-2012


5-15-2012


Taxation: opting out of exemption for certain energy systems


Ch. 150; Art. XII




L.L. No. 2-2012


6-19-2012


2013 tax levy limit override


NCM




L.L. No. 3-2012


7-17-2012


Charter amendment


Art. 9




L.L. No. 4-2012


7-17-2012


Aquatic invasive species


Ch. 119, Art. I




L.L. No. 5-2012


9-4-2012


Election districts amendment


Ch. 28




L.L. No. 1-2013


6-18-2013


2014 tax levy limit override


NCM




L.L. No. 2-2013


7-16-2013


Code of Ethics amendment


Ch. 32




L.L. No. 3-2013


12-17-2013


Sale or lease of County property amendment


Ch. 19





