## § 140-16 Penalties for offenses.



A. Any person, including any solid waste hauler, who violates
this article shall be guilty of an offense and subject to a fine of not more
than $500 and/or imprisonment for not more than 15 days. Each and every act
committed which is prohibited by § 140-14 of this article shall
constitute a separate violation.

B. Upon the failure of any solid waste hauler to comply
with the requirements of this article, the hauler's solid waste license shall
be subject to suspension, revocation or to the imposition of conditions. The
Commissioner of Public Works or his designee may initiate such action in the
manner prescribed by L.L. No. 3-1992.[1]
[1]:
Editor's Note: Local Law No. 3-1992 was superseded by L.L. No. 6-1993.
See now Article III, Facilities; Licensing of Haulers, of this chapter.


