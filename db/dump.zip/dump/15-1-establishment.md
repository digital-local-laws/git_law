## § 15-1 Establishment.


A Community Mental Health Board is hereby established by the Board of
Supervisors of Tompkins County.
