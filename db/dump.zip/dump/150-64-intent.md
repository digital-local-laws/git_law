## § 150-64 Intent.


It is the intent of this article to provide no exemption from
taxation as authorized in Real Property Tax Law § 487.
