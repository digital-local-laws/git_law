## § 155-5 Waiver. 


[Added 12-15-1998 by L.L.
No. 6-1998]
Any person, business, tobacco retailer or owner, manager or operator
of any establishment subject to this chapter may request a waiver from strict
compliance with its provisions. Such request must be in writing, addressed
to the Tompkins County Board of Health and shall set forth and document the
reason strict compliance will cause a significant hardship to the applicant.
The request shall also state alternative means of compliance. The Board of
Health shall consider the request and either deny the request or grant the
request, subject to such conditions as the Board of Health shall impose in
order that the purpose and intent of this chapter will be achieved, that is,
to make it difficult for minors to purchase or obtain tobacco products.
