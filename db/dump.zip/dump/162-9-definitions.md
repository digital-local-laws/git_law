## § 162-9 Definitions.



A. The following words, when used in this article, shall
have the meaning as set forth in this section:

AREA
Includes the county-owned property heretofore described in § 162-1.


CONTROLLED PARKING AREA
The parking areas used in conjunction with county office buildings
and courthouses, all subject to control by the provisions of this article.


OPERATOR
Includes every person who shall operate a vehicle as the owner thereof
or as the agent, employer, or permittee of the owner, or who is in actual
physical control of a vehicle.


PARK
Includes the permitting of any vehicle to be parked or put in place
and let remain or leave standing in or upon the county-owned property heretofore
described in § 162-1.


PERSON
Includes every natural person, firm, copartnership, association,
or corporation.


RESTRICTED PARKING AREA
Designated portions of the controlled parking areas set aside by
the county for the exclusive use by designated county and state officials
and including parking areas marked and designated for use by the handicapped.


VEHICLE
Any device in, upon, or by which a person or property is or may be
transported upon a highway, except a device which is operated upon rails or
tracks.


B. Unless otherwise herein indicated, all words used shall
have the meanings as defined in the General Construction Law of the State
of New York.


