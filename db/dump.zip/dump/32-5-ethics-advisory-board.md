## § 32-5 Ethics Advisory Board.



A. Membership
and eligibility. There shall be an Ethics Advisory Board that consists
of five members, each appointed by a majority vote of the Tompkins
County Legislature. Each member shall be a resident of the Tompkins
County. One of the members of the Ethics Advisory Board shall be a
member of the Tompkins County Legislature. None of the remaining members
shall be an elected or appointed official of Tompkins County.

B. Chair.
The Chair of the Ethics Advisory Board shall be one of the appointed
members of the Ethics Advisory Board selected by the Chair of the
Tompkins County Legislature upon advice of the Ethics Advisory Board
for a term of one year.

C. Term.
The members of the Ethics Advisory Board will serve a term of four
years; however, two of the original appointees shall be appointed
to serve an initial term of two years.

D. Quorum.
Three members of the Ethics Advisory Board shall constitute a quorum,
with the vote of four members being required for action by the Board.

E. Compensation.
The members of the Ethics Advisory Board shall not be compensated;
however, they may be reimbursed for reasonable expenses incurred in
the performance of their duties.

F. Bylaws.
The Ethics Advisory Board may propose bylaws for its governance, which
bylaws shall become effective upon approval by the Tompkins County
Legislature.

G. Responsibilities.

(1) Meetings.

(a) 
The members of the Ethics Advisory Board will meet at least
once a year and at such other times as the Chair of the Ethics Advisory
Board shall convene them and within 30 days after receipt of a written
complaint.

(b) 
At each meeting of the Ethics Advisory Board, an opportunity
shall be given to hear or receive complaints of alleged unethical
practices, which may be brought in writing by any County employee
or official. Any other person may submit a complaint to the County
Attorney, who, if unable to resolve the complaint to the satisfaction
of the complainant, shall submit the complaint to the Ethics Advisory
Board.



(2) Review of disclosure statement.

(a) 
No later than July 1 of each year, the Ethics Advisory Board
shall review the report of the County Attorney on the filed financial
disclosure statements and the attestations that have been submitted
by officials and employees and determine if any are not timely filed
or are incomplete.

(b) 
The Ethics Advisory Board, or its designee, may grant limited
extensions of time in which to file financial disclosure statements
due to justifiable cause or to undue hardship.

(c) 
The Ethics Advisory Board may permit an official or employee
to delete from his/her financial disclosure statement one or more
items of information upon a finding by a majority of the entire Ethics
Advisory Board that the information that would otherwise be required
to be disclosed has no material bearing on the discharge of the duties
of the official or employee. In this connection, the Ethics Advisory
Board may, when requested, issue advisory opinions.



(3) Review of complaints and questions.

(a) 
The Ethics Advisory Board shall review all filed disclosure
statements referred to it by the County Attorney and complaints received
to ascertain whether a conflict of interest, actual or potential,
exists between the public duties of the official or employee and his
or her private activities pursuant to this chapter.

(b) 
The Ethics Advisory Board shall, upon the written request of
any individual, receive, review, and hear all signed complaints that
the Board determines to have merit alleging violation(s) of this chapter.
Any such complaint must be signed by the individual complainant and
must include his/her address and telephone number.

(c) 
Complaints from any person will be received in the following
manner: A signed written complaint in the above form should be delivered
to the County Attorney who, if unable to resolve the complaint to
the satisfaction of the complainant, shall refer the complaint to
the Ethics Advisory Board or to the Chair of the Ethics Advisory Board
if the complainant so prefers.



(4) Authority to take testimony. The Ethics Advisory Board shall have
the authority to take testimony under oath and to recommend to the
Tompkins County Legislature that subpoenas be issued to compel the
attendance of witnesses and to require the production of any books
or records. The County Legislature shall take action on any such recommendation;
a majority vote of the total membership of the Tompkins County Legislature
shall be required for the issuance of a subpoena by the Ethics Advisory
Board.

(5) Option to recommend resolution of conflict. In addition to such other
powers conferred by this section, the Ethics Advisory Board may recommend
to the official or the employee of the County the manner in which
the conflict of interest may be resolved. An affidavit by the official
or employee detailing his or her compliance with the recommendations
may be sufficient reason to rescind the Ethics Advisory Board's
recommendation for disclosure or other action. The affidavit must
be delivered to the Board at a specified time and place as set forth
in the Board's certified, return-receipt-requested letter to
such official or employee. If the official or employee fails to follow
the recommendations of the Ethics Advisory Board in eliminating the
conflict of interest, that fact shall also be disclosed. Nothing herein
contained shall be construed or interpreted to mean that the Ethics
Advisory Board is under a duty to make such recommendations to the
official or the employee.

(6) Rendering advisory opinions to other municipalities.

(a) 
The Ethics Advisory Board shall, as provided by state law, render
advisory opinions to officers and employees of municipalities wholly
or partly within the County with respect to this chapter and any other
applicable municipal Code of Ethics. The advisory opinion shall be
rendered pursuant to a written request of any such officer or employee
under such rules and regulations as the Board may prescribe, and the
Board shall have the advice of the County Attorney.

(b) 
In addition, upon the request of the governing body of any municipality
in the County, the Board may make recommendations with respect to
the drafting and adoption of a Code of Ethics or amendment thereto
for that municipality.

(c) 
The County Ethics Advisory Board shall not act with respect
to the officials or employees of any municipality located within the
County or agency thereof, where such a municipality has established
its own Board of Ethics, except that the local board may, at its option,
refer the matter to the County Ethics Advisory Board.



(7) Written decision rendered. It is the intent of this Code of Ethics
that complaints be resolved promptly, and, therefore, a written decision
should be forthcoming within 90 days after the conclusion of the fact-gathering
process.

(8) Written record of actions and determinations. The Ethics Advisory
Board shall state in writing the disposition of every request for
opinion and every investigation it conducts, and the reasons for the
disposition. All such statements and written requests shall be kept
on file as public records.

(9) Review of Code of Ethics. The Ethics Advisory Board shall review
the Code of Ethics and recommend to the County Legislature any changes
that it deems appropriate. Any changes in this chapter that are recommended
by the Ethics Advisory Board shall, to the extent reasonably consistent
with the other responsibilities of the County Legislature, be discussed
and acted upon by the County Legislature in open session at a regular
meeting within two months of the issuance of the recommendations.

(10) Annual review of ethics training. The Ethics Advisory Board shall
annually confer with the Commissioner of Personnel and review the
training provided to employees as to ethics and provide any suggestions
deemed appropriate.




