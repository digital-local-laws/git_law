## § 150-3.1 Late applications. 


[Added 5-2-2000 by L.L. No. 5-2000]
Notwithstanding § 150-3, an application
for such exemption may be filed with the Assessor after the appropriate
taxable status date but not later than the last date on which a petition
with respect to complaints of assessment may be filed, where failure
to file a timely application resulted from: a death of the applicant's
spouse, child, parent, brother or sister; or an illness of the applicant
or of the applicant's spouse, child, parent, brother or sister, which
actually prevents the applicant from filing on a timely basis, as
certified by a licensed physician. The assessor shall approve or deny
such application as if it had been filed on or before the taxable
status date.
