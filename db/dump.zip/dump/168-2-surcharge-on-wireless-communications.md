## § 168-2 Surcharge on wireless communications.



A. Pursuant to the authority granted to the Tompkins County
Legislature by County Law § 308-a, there is hereby imposed a surcharge
of $0.30 per month on wireless communications service in the County of Tompkins.
The surcharge shall be imposed on each wireless communications device and
shall be reflected and made payable on bills rendered for wireless communications
service that is provided to a customer whose place of primary use is within
the County.

B. For purposes of this section, the term "place of primary
use" shall mean the street address that is representative of where the customer's
use of the wireless communications service primarily occurs, which address
must be a residential street address or the primary business street address
of the customer, and within the licensed service area of the wireless communications
service supplier; provided, however, that a wireless service supplier may
treat the address used by such supplier for any wireless communications customer
under a service contract or agreement in effect on July 28, 2002, as that
wireless communications customer's place of primary use for the remaining
term of such service contract or agreement, excluding any extension or renewal
of such service contract or agreement, for purposes of determining the taxing
jurisdiction with respect to taxes on wireless communications service.


