## § 114-23 Legislative authority; authorization to increase fees.


In accordance with Subparagraph (2) of Paragraph
4 of Subdivision (a) of § 8021 of the Civil Practice Law
and Rules, as amended by Chapter 78 of the Laws of 1989, the Tompkins
County Legislature authorizes the Tompkins County Clerk to increase
the fees charged for certain documents recorded with the County Clerk's
office.
