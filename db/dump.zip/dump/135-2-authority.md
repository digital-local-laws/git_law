## § 135-2 Authority.


The County is authorized to adopt this chapter by § 1650(4)
of the New York State Vehicle and Traffic Law as well as by the Municipal
Home Rule Law that authorizes the County to adopt local laws to protect
the health and safety of its citizens.
