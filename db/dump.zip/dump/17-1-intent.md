## § 17-1 Intent.


The New York State Defense Emergency Act, in § 29-a thereof,[1] authorizes political subdivisions of the state to provide for
the continuity of their governments in the event of an actual or imminent
attack upon the United States by an enemy or foreign nation. The General Municipal
Law, in § 60 thereof, authorizes political subdivisions to provide
for the continuity of their governments in the event of other public disasters,
catastrophes or emergencies. Based on the authority contained in such laws,
this chapter is adopted so that on such occasions the government of the County
of Tompkins, New York may continue to function properly and efficiently under
emergency circumstances.
[1]:
Editor's Note: See Unconsolidated Laws § 9134-a.
