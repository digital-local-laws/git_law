## § 168-4 Collection of surcharge.



A. Each wireless communications service supplier providing
such service within the County of Tompkins shall act as collection agent for
the County and shall remit the funds collected pursuant to the surcharge imposed
under the provisions of this chapter to the chief fiscal officer of the County
of Tompkins every month. Such funds shall be remitted no later than 30 days
after the last business day of the month.

B. Each wireless communications service supplier shall be
entitled to retain, as an administrative fee, an amount equal to 2% of its
collections of the surcharge imposed under the provisions of this chapter.

C. The surcharge required to be collected by a wireless
communications service supplier shall be added to and stated separately in
its billings to customers.

D. Each wireless communications service customer who is
subject to the provisions of this chapter shall be liable to Tompkins County
for the surcharge until it has been paid to the County, except that payment
to a wireless communications service supplier is sufficient to relieve the
customer from further liability for such surcharge.

E. No wireless communications service supplier shall have
a legal obligation to enforce the collection of any surcharge imposed under
the provisions of this chapter; provided, however, that whenever the wireless
communications service supplier remits the funds collected to the County of
Tompkins, it shall also provide the County of Tompkins with the name and address
of any customer refusing or failing to pay the surcharge imposed under the
provisions of this chapter and shall state the amount of such surcharge remaining
unpaid.

F. Each wireless communications service supplier shall annually
provide to the County of Tompkins an accounting of the surcharge amounts billed
and collected in the time and manner provided by the County Director of Finance.


