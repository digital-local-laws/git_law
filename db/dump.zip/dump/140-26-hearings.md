## § 140-26 Hearings.



A. Hearings shall be held before a Hearing Board, which
shall consist of the following people:

(1) One member of the Board of Representatives appointed
by the Chair of the Board of Representatives;

(2) One member of the County Solid Waste Management Advisory
Committee appointed by the Chair of the Committee;

(3) The County Administrator or designee thereof; and

(4) The County Attorney, or designee thereof, shall be an
ex-officio, nonvoting member of the Hearing Board.



B. Except as provided in § 140-25C, hearings shall
be scheduled to be held before the Hearing Board within 10 days of the receipt
of the demand for the hearing. The hearing shall be held during regular business
hours and may be adjourned or continued thereafter as the Hearing Board shall
deem necessary or convenient. The Commissioner shall notify the licensee or
applicant, in writing, of the time and place of the hearing at least five
days before the hearing date.

C. The licensee or applicant may be represented by counsel
at the hearing, and may offer evidence and cross-examine witnesses. Upon request
of the licensee or applicant, the hearing shall be recorded by a stenographer.

D. The Hearing Board shall make a final determination within
10 days after the last day of the hearing, except for hearings held pursuant
to § 140-25C. Final determination, on hearings held pursuant to
§ 140-25C shall be made within two days after the last day of the
hearing.

E. The Hearing Board shall promptly notify the licensee,
in writing, of its final determination, including the effective date.


