## § 22-11 Payments.


All payments made under the terms of this article, whether for insurance
or otherwise, shall be deemed to be for a public purpose and shall be audited
and paid in the same manner as other public charges.
