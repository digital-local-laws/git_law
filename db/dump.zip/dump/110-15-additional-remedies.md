## § 110-15 Additional remedies.


The County Attorney is authorized to pursue
any appropriate legal remedy, including, but not limited to, an injunction
to effectuate the purpose of this article.
