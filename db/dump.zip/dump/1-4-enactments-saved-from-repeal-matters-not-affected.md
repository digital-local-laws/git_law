## § 1-4 Enactments saved from repeal; matters not affected.


The repeal of local laws and ordinances provided for in § 1-3
of this local law shall not affect the following classes of local laws, ordinances,
rights and obligations, which are hereby expressly saved from repeal:

A. Any right or liability established, accrued or incurred
under any legislative provision of Tompkins County prior to the effective
date of this local law or any action or proceeding brought for the enforcement
of such right or liability.

B. Any offense or act committed or done before the effective
date of this local law in violation of any legislative provision of Tompkins
County or any penalty, punishment or forfeiture which may result therefrom.

C. Any prosecution, indictment, action, suit or other proceeding
pending or any judgment rendered prior to the effective date of this local
law brought pursuant to any legislative provision of Tompkins County.

D. Any agreement entered into or any franchise, license,
right, easement or privilege heretofore granted or conferred by Tompkins County.

E. Any local law or ordinance of Tompkins County providing
for the laying out, opening, altering, widening, relocating, straightening,
establishing grade, changing name, improvement, acceptance or vacation of
any right-of-way, easement, street, road, highway, park or other public place
within Tompkins County or any portion thereof.

F. Any local law or ordinance of Tompkins County appropriating
money or transferring funds, promising or guaranteeing the payment of money
or authorizing the issuance and delivery of any bond of Tompkins County or
other instruments or evidence of the county's indebtedness.

G. Local laws or ordinances authorizing the purchase, sale,
lease or transfer of property or any lawful contract, agreement or obligation.

H. The levy or imposition of special assessments or charges.

I. The annexation or dedication of property.

J. Any local law or ordinance relating to salaries and compensation.

K. Any local law or ordinance amending the Zoning Map.

L. Any local law or ordinance relating to or establishing
a pension plan or pension fund for county employees.

M. Any local law or ordinance or portion of a local law
or ordinance establishing a specific fee amount for any license, permit or
service obtained from the county.

N. Any local law adopted subsequent to 4-6-1999.


