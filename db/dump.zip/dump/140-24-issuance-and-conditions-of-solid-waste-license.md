## § 140-24 Issuance and conditions of solid waste license.



A. Solid waste licenses required by § 140-23 shall
be issued as follows:

(1) Solid waste licenses must be obtained and renewed on
an annual basis from the Commissioner.

(2) The solid waste license fee or fees, including fees,
if any, for each vehicle used to collect or transport solid waste by or on
behalf of the licensee, shall be established by the Board of Representatives.



B. Solid waste licenses and renewals shall be subject to
the following conditions:

(1) All licensees must comply with this article and the rules,
regulations, and orders promulgated pursuant to this article. A solid waste
license application or renewal application may be denied based on the failure
of the applicant to comply with this article and the rules, regulations and
orders promulgated pursuant to this article, or with any other federal, state
or local law governing the licensee's operations.

(2) All licensees must maintain records of acceptable solid
waste and regulated recyclables collected, transported or disposed of by the
licensee, in accordance with the rules and regulations promulgated pursuant
to this article.

(3) The licensee shall provide evidence of security from
a reliable insurer or surety authorized to do business in New York State,
in the form of policies for insurance or surety bonds providing for coverages
as determined by the rules and regulations promulgated pursuant to this article.

(4) As a term and condition of being issued a solid waste
license, a licensee shall consent that any vehicle being operated by or on
behalf of the licensee may be searched and its contents examined by any police
officer, County Inspector or other person designated by the Board of Representatives
at any facility or while engaged in the collection, transportation or carrying
of solid waste.

(5) No solid waste license shall be issued upon original
application or renewal application to any applicant convicted of a misdemeanor
or felony violation of any federal, state or local law pertaining to the collection
or disposal of solid waste, unless the Commissioner finds the denial of a
solid waste license to such person would not be in public interest.

(6) As a condition for renewal of a solid waste license,
the licensee shall file with the Commissioner a certificate executed before
a notary public attesting that the licensee has complied with this article
and any and all rules, regulations and orders promulgated pursuant thereto
during the term of the prior license.

(7) If the Board of Representatives has designated a facility
pursuant to § 140-21 of this article, all licensees must deliver
any solid waste required to go to a particular facility within 48 hours of
picking up the solid waste. Weekends and holidays shall be excluded from the
forty-eight-hour computation. If any solid waste is delivered to the designated
facility or facilities in a different vehicle from that in which the solid
waste was picked up, the licensee must inform the Commissioner prior to or
upon delivery that the delivery vehicle contains solid waste that was picked
up in other vehicles, and the other vehicles must be identified. The Commissioner
may excuse a licensee from the time limit for a particular pickup if the licensee
notifies the Commissioner prior to the expiration of the time period that
the time requirement cannot be satisfied because of a vehicle mechanical failure
or other unanticipated delay.

(8) All licensees shall be required to post a bond, security
deposit or other guaranty or payment as determined by the Director of Finance.[Amended 10-4-1994 by L.L.
No. 6-1994]

(9) The time for payment of all fees, including but not limited
to the per-ton fee for solid waste, shall be determined by the Commissioner,
and all licenses must comply with these payment requirements.



C. The Commissioner is hereby empowered to administer the
issuance, denial, revocation or suspension of solid waste licenses, in accordance
with this article and the rules and regulations promulgated hereunder.


