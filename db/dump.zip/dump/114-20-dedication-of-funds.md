## § 114-20 Dedication of funds.


Two dollars and fifty cents of each fee collected
hereunder and remitted to Tompkins County shall be applied to the
budget of the Department of Motor Vehicles and used to finance its
operations. The balance of all fees collected shall be applied to
the Tompkins County budget for maintenance of County roads and bridges.
