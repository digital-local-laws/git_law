## § 110-13 Prohibited acts.



A. No wireless telephone service supplier shall knowingly
fail to route wireless 911 telephone calls originating within Tompkins
County to the Tompkins County PSAP as required by § 110-12
above.

B. No owner, official, employee or agent of a wireless
telephone supplier shall design, implement, arrange or cause, either
directly or indirectly, a process or activity whereby 911 calls are
routed other than as provided in § 110-12 above.

C. No person or entity shall either directly or indirectly
solicit, suggest, implore, agree or otherwise take action so as to
cause or seek to cause a wireless telephone service supplier to route
wireless 911 calls from within Tompkins County to other than the Tompkins
County PSAP.


