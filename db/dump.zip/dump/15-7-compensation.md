## § 15-7 Compensation.


Members of the Community Mental Health Board may receive such per diem
compensation as may be provided by local appropriations therefor.
