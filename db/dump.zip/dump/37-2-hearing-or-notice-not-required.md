## § 37-2 Hearing or notice not required.


The County of Tompkins may lease real property which yields an annual
rental of $1,500 or less at its airport or any part thereof for the rendering
of various services or the conduct of business activities without necessity
of prior public hearing on notice. All such contracts not subject to a public
hearing shall still be subject to approval by the Public Works and Construction
Management Committee and by the County Board of Representatives.
