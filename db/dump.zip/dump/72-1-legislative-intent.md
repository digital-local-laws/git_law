## § 72-1 Legislative intent.


This article implements the smoking policy adopted by the Tompkins County
Board of Representatives as a result of negotiations with the Tompkins County
Unit, Local 855, Civil Service Employees' Association, Inc. and the Tompkins
County Deputy Sheriffs' Association and reflects said Board's concern for
the health and safety of County employees and members of the general public
that use County-owned or -occupied buildings and vehicles.
