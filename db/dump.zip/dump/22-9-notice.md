## § 22-9 Notice.


This article shall not in any way affect the obligation of any claimant
to give notice to Tompkins County under § 10 of the Court of Claims
Act, § 50-e of the General Municipal Law, or any other provision
of law.
