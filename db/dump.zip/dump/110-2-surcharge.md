## § 110-2 Surcharge.


[Amended 11-4-2009 by L.L. No. 1-2009]
Pursuant to the authority granted to the Tompkins
County Legislature by County Law, § 303, there is hereby
imposed a surcharge of $1 per month on each local telephone exchange
access line in the county, subject to the restrictions contained herein.
