## § 77-1 Department established; Director.


There shall be in the County of Tompkins a County Tax Department. Such
Department shall have a Director to be appointed by and serve at the will
of the Board of Supervisors. The Director shall be the head of such Department
and may employ such other employees as shall be authorized by the Board.
