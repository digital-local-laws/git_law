## § 74-13 Statutory authority.


Pursuant to Article 11 of the Real Property Tax Law, the Tompkins County
Board of Representatives hereby exercises the following options for the collection
of delinquent taxes in Tompkins County.
