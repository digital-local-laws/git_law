## § 15-6 Removal.


Any appointive Board member may be removed by the Chairman of the Board
of Supervisors for neglect of duty, misconduct or malfeasance in office, after
being given a written statement of the charges and an opportunity to be heard
thereon.
