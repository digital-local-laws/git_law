## § 22-4 Definitions.


As used in this article, the following terms shall have the meanings
indicated:

EMPLOYEE
Any commissioner, member of a public board or commission, trustee,
director, officer, employee, volunteer expressly authorized to participate
in a publicly sponsored volunteer program, or any other person holding a position
by election, appointment, or employment in the service of Tompkins County,
whether or not compensated, but shall not include the Sheriff of the county
or an independent contractor. The term "employee" shall include a former employee,
his/her estate, or judicially appointed personal representative.

