## § 55-3 Conditions for expenditures.


Expenditures from either of the petty cash funds herein established
may be made only for payment in advance of audit of properly itemized and
verified or certified bills for materials, supplies or services, other than
employment, furnished to the county for the conduct of its affairs and upon
terms calling for the payment to the vendor upon the delivery of any such
materials or supplies or the rendering of any such services, provided that
moneys in either of such funds also may be used for the purpose of making
change when such is required in the performance of official duties. Upon audit
of bills, such petty cash funds shall be reimbursed from the appropriate budgetary
item or items in an amount equal to the amount audited and allowed.
