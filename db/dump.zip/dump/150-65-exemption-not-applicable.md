## § 150-65 Exemption not applicable.


No exemption from taxation shall be applicable with respect
to any solar or wind energy system or farm waste energy system.
