## § 72-9 Penalties for offenses.



A. It shall be unlawful for any person who owns, manages,
operates, or otherwise controls the use of any premises subject to regulation
under this article to fail to comply with any of its provisions.

B. It shall be unlawful for any person to smoke in any area
where smoking is prohibited by the provisions of this article.

C. Penalty by the Board of Health. Pursuant to the provisions
of § 309 of the Public Health Law, the Board of Health may impose
a penalty not to exceed $1,000 upon a person for any violation of or failure
to comply with any provisions of this article or any order made pursuant to
such article after holding a hearing thereon. Each day on which such violation
or failure continues shall constitute a separate offense. Nothing herein contained
shall be construed to exempt an offender from any other prosecution or penalty
provided by law.


