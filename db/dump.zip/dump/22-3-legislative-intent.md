## § 22-3 Legislative intent.


The New York State Legislature has enacted legislation permitting public
entities, including counties, to provide for the defense and indemnification
of officers and employees. The Tompkins County Board of Representatives, through
prior legislation, has agreed in principle to this concept. This article implements
that concept.
