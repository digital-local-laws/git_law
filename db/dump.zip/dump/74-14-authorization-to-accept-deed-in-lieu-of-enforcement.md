## § 74-14 Authorization to accept deed in lieu of enforcement.


Pursuant to § 1170 of the Real Property Tax Law, the Tax Enforcement
Officer, who is the County Finance Director, is hereby authorized to accept
a deed in lieu of enforcement of collection of delinquent taxes under Article
11.
