## § 58-3 Publication of notice of adoption.


Within 10 days after approval of a local law by the Board of Representatives,
the Clerk of the Board shall cause to be published in the official newspaper
of Tompkins County a notice of adoption of a local law. The notice of adoption
shall be published once and shall contain a synopsis of the law, and a notice
that the full text of the law may be examined at the Office of the Clerk of
the Board during normal business hours.
