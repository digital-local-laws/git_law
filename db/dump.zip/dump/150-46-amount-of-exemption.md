## § 150-46 Amount of exemption.


Historic property, altered or rehabilitated
subsequent to the effective date of this article, shall be exempt
from taxation to the extent of any increases in value attributable
to such alteration or rehabilitation pursuant to the following schedule:





Year of Exemption


Percentage of Exemption






1


100%




2


100%




3


100%




4


100%




5


100%




6


80%




7


60%




8


40%




9


20%




10


0%





