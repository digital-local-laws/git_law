## § 127-7 Employees, agents, representatives, sales personnel.



A. Number, limited. Any person using a vehicle may employ
under the same license not more than one person to assist in selling and delivering
but such person shall so act only when accompanying a licensed hawker, peddler,
solicitor or transient business, and when any additional persons are so employed,
an additional license shall be required for each such additional person and
the fee fixed in Subsection B of § 127-6 shall be paid therefor.

B. Identification card required. The one employee, agent
or sales person mentioned in Subsection A above who acts with a licensee shall
at all times carry and on demand display a card of identification issued by
the Sheriff, which card shall contain the following information: the name
of the employee, agent or sales person, the name of the employer or company
and the date of expiration of the employer's or company's license. Such identification
cards shall be valid until the expiration of the license under which they
are issued.

C. Personal statement required. Each such employee or sales
person shall file with the Sheriff a statement including his name, age, permanent
and county address and name and address of his employer or company and the
telephone numbers of all such firms and/or individuals responsible for supervision
of such activity.

D. Refusal, revocation of card. The provisions of § 127-8
respecting revocation of license shall apply to the revocation of cards of
identification. The issuance of a card of identification may be refused upon
the same grounds as set forth in § 127-5A for the refusal of a license.


