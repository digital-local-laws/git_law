## § 114-10 Special provisions for fees for Fiscal Year 1993.


Notwithstanding anything to the contrary herein,
the following special provisions shall apply to the annual solid waste
fees charged for the year January 1 through December 31, 1993:

A. The taxable status date shall be March 1, 1993.

B. The Board shall by resolution concurrent with this
article establish the unit charge to be applied for 1993 in calculating
the annual solid waste fees to be charged. The Board may amend the
unit charge on or before June 15, 1993.

C. Within 10 business days following the taxable status
date, by March 10, 1993, the County Administrator shall mail to all
owners of real property a notice setting forth the classification(s)
of each parcel on the solid waste fee roll, the number of billing
units and the proposed fee currently assigned to such parcel. Failure
to mail such notice or failure of the owner to receive the notice
shall not prevent the charging, collection and enforcement of the
annual solid waste fee against the owner and property.

D. Complaints with respect to the classification of a
parcel or property measurements (e.g. square footage, number of living
units, etc.) may be filed with the County Administrator on or before
April 16. Complainants shall file a statement under oath, specifying
the parcel of property, why the assigned classification or measurement
is erroneous or illegal, what the complainant believes is the correct
classification or measurement, and a brief description of the facts
supporting the claim. The statement must be made by the owner of the
parcel in question or by some other person authorized by the owner
to make the statement who has knowledge of the facts stated therein.
The County Administrator shall determine, in writing, the proper classification
or measurement of each parcel for which a complaint has been filed
and shall mail a copy of such determination to the complainant on
or before May 10. Such decision shall also include information regarding
the procedure to appeal the decision to the Appeals Board and the
date, time and place of the meeting or meetings of the Appeals Board.
Any person desiring to appeal the decision of the County Administrator
may file an appeal with the Appeals Board on or before June 1. Such
appeal shall be in writing and shall include a copy of the complaint
filed with the County Administrator, a copy of the County Administrator's
decision and a brief description of the reason for the appeal.

E. The bills for the 1993 annual solid waste fee shall
be mailed on or about August 1, 1993, and shall be due on August 1,
1993, and payable without interest or penalties through August 31,
1993.

F. Except as set forth in the foregoing, all other provisions
of this article shall apply to the annual solid waste fees charged
for 1993.


