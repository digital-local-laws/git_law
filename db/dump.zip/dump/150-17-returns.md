## § 150-17 Returns.



A. Every operator shall file with the County Administrator
a return of occupancy, of rents, and of taxes payable thereon for
the periods ending February 28, May 31, August 31, and November 30
of each year, on and after September 5, 1989. Such returns shall be
filed within 20 days from the expiration of the period covered thereby.
The County Administrator may permit or require returns to be made
by other periods and upon such dates as may be specified. If the County
Administrator deems it necessary in order to ensure the payment of
the tax imposed by this article, returns may be required for shorter
periods than those prescribed pursuant to the foregoing provisions
of this section and upon such dates as may be specified.

B. The form of returns shall be prescribed by the County
Administrator and shall contain such information as may be deemed
necessary for the proper administration of this article. The County
Administrator may require amended returns to be filed within 20 days
after notice and to contain the information specified in the notice.

C. If a return required by this article is not filed,
or a return when filed is incorrect or insufficient on its face, the
County Administrator shall take the necessary steps to enforce the
filing of such a return or of a corrected return.


