## § 127-14 Applicability.


This chapter shall not supersede the local law of any other municipality
in effect now and hereinafter adopted.
