## § 32-6 Distribution of Code of Ethics.



A. The Chair of the Tompkins County Legislature shall cause a copy of
this Code of Ethics to be distributed electronically or by hard copy
to every officer and employee of the County of Tompkins within 30
days after the effective date of this chapter. Each officer and employee
elected or appointed thereafter shall be furnished an electronic or
a hard copy before entering upon the duties of his/her office or employment.

B. A copy of the code shall be available in each County department and
posted on the County website. In addition, each County officer and
employee shall receive an annual reminder about the existence of the
code, where it can be accessed, and the importance of complying with
it.

C. The failure of a County officer or employee to receive a copy of
the code or any other amendment thereto does not affect either the
applicability or enforceability of the code or amendments thereto.


