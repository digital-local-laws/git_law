## § 15-3 Membership.


The Community Mental Health Board shall consist of nine members including
the two ex officio members, seven of which shall be appointed by the Chairman
of the Board of Supervisors of Tompkins County on recommendation of the Health
Committee. Two of the said members shall be physicians actively engaged in
private practice. The Board shall be representative of interested groups in
the community, and at the discretion of the Chairman of the Board may include
a member of the governing body of the county; an officer or employee of a
school district within the county; persons familiar with practice in courts
of criminal jurisdiction or family courts, and members or employees of voluntary
health, welfare or mental health agencies.
