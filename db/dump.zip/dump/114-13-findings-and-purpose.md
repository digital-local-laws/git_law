## § 114-13 Findings and purpose.



A. This Legislature hereby finds and determines that
Chapter 68 of the New York State Laws of 1991, which amended Tax Law
§ 1202, allows the Commissioner of the New York State Department
of Motor Vehicles to collect a special motor vehicle use fee imposed
by the County.

B. This Legislature also finds and determines the County
is required under its Charter to balance its operating budget during
the fiscal year.

C. This Legislature further finds and determines that
imposing a local fee on the vehicles registered in Tompkins County
would generate annual revenues necessary to help meet the budget expenses
of our local Department of Motor Vehicle Office and maintain our County
roads and bridges.

D. Therefore, the purpose of this article is to impose
a special motor vehicle use fee on vehicle registration and authorize
the collection of said fee by the New York State Department of Motor
Vehicles.


