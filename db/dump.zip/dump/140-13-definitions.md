## § 140-13 Definitions.


As used in this article, the following terms shall have the following
meanings:

CONTAINER PROGRAM SOLID WASTE
Any solid waste generated or originated on residential property and
any solid waste generated or originated on commercial property that is placed
at curbside for collection. Container program solid waste shall not include
hazardous waste under any applicable law or regulation, or construction or
demolition debris.


DISPOSAL FEE
The cost per pound for the disposal of solid waste at the facility
or facilities specified by the Tompkins County Board of Representatives pursuant
to L.L. No. 3-1992.[1] The disposal fee shall not include any fees charged by solid waste
haulers for the collection, hauling or handling of solid waste.


SOLID WASTE
All putrescible and nonputrescible materials or substances discarded
or rejected as being spent, useless, worthless or in excess to the owners
at the time of such discard or rejection, including but not limited to garbage,
refuse, industrial, commercial, and agricultural waste, sludges from air or
water pollution control facilities or water supply treatment facilities, rubbish,
tires, ashes, contained gaseous material, incinerator residue, demolition
and construction debris and offal, but not including sewage and other highly
diluted water-carried materials or substances and those in gaseous form, special
nuclear or by-product material within the meaning of the Atomic Energy Act
of 1954, as amended, or waste which appears on the list or satisfies the characteristics
of hazardous waste promulgated by the Commissioner of Environmental Conservation
pursuant to § 27-0903 of the Environmental Conservation Law. Solid
waste shall not include any scrap or other material of value separated from
the waste stream and held for purposes of materials recycling.


SOLID WASTE HAULER
Any person, corporation or partnership in the business of collecting,
transporting or handling solid waste generated or originated within the county.
For purposes of this article, "solid waste hauler" includes municipalities
providing hauling services.

[1]:
Editor's Note: Local Law No. 3-1992 was superseded by L.L. No. 6-1993.
See now Article III, Facilities; Licensing of Haulers, of this chapter.
