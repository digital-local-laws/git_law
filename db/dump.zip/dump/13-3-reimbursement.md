## § 13-3 Reimbursement.


If the inmate has such coverage, the Sheriff of Tompkins County shall
seek reimbursement for all services, medical or dental, rendered to such inmate
as required by said Correction Law.
