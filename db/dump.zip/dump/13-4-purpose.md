## § 13-4 Purpose.


This article is adopted pursuant to § 10(ii)(a)(5) and (3)
of the Municipal Home Rule Law of the State of New York to provide a method
for the presentment of claims for compensation to attorneys assigned to represent
indigent individuals under Article 18-B of the County Law.
