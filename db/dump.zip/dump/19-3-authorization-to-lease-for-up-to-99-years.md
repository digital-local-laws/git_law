## § 19-3 Authorization to lease for up to 99 years.


[Added 12-17-2013 by L.L. No. 3-2013[1]]
The County of Tompkins is authorized to lease real property
no longer needed for public use for a term of up to 99 years.
[1]:
Editor's Note: This local law also superseded former
§ 19-3, Chapter adopted subject to permissive referendum.
