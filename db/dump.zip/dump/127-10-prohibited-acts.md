## § 127-10 Prohibited acts.



A. Unlawful sales. A hawker, peddler, solicitor or transient
businessman shall not falsely or fraudulently misrepresent the quantity, character
or quality of any article offered for sale or purchase; or offer for sale
any unwholesome, tainted or diseased provisions or merchandise.

B. Sanitary conditions. A hawker, peddler, solicitor or
transient businessman shall keep the vehicles and receptacles used by him
in a clean and sanitary condition and the food stuffs and edibles offered
for sale well covered and protected from dirt, dust and insects.

C. Noises. A hawker, peddler, solicitor or transient businessman
shall not blow a horn, ring a bell or use any other noisy device to attract
public attention to his wares, or shout or cry his wares.

D. Obstructions. A hawker, peddler, solicitor or transient
businessman shall not create or maintain any booth or stand or place any barrels,
boxes, crates or other obstruction upon any street or public place for the
purpose of selling or exposing for sale or purchasing any goods, wares or
merchandise.

E. Measuring devices. A hawker, peddler, solicitor or transient
businessman shall not use any weighing or measuring device unless the same
shall have been examined and sealed by the city or county sealer of weights
and measures.


