## § 119-6 Penalties for offenses.


Any person who engages in any activity prohibited by this article
shall be guilty of a violation. Every person convicted of a violation
of this article shall be subject to a fine of not more than $250.
