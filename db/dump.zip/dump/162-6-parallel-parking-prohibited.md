## § 162-6 Parallel parking prohibited.


There shall be no parallel parking on the airport driveways.
