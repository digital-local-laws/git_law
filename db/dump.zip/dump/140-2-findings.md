## § 140-2 Findings.


The Board of Representatives of Tompkins County finds that:

A. Removal and reduction of certain materials from the solid
waste stream will decrease the flow of solid waste to landfills, aid in the
conservation of valuable resources, and reduce the required capacity and associated
costs of existing and proposed solid waste disposal facilities.

B. The New York State Solid Waste Management Act of 1988
mandates that all municipalities adopt a local law or ordinance by September
1, 1992 requiring that solid waste which has been left for collection or which
is delivered by the generator of such waste to a solid waste management facility
shall be separated into recyclable, reusable or other components for which
economic markets for alternate uses exist.

C. Methods of solid waste management emphasizing source
reduction, reuse and recycling are essential in Tompkins County for long-term
preservation of public health, economic productivity, and environmental quality.


