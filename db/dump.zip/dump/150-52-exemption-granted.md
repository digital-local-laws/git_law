## § 150-52 Exemption granted.


Pursuant to § 483-b of the Real Property
Tax Law, there shall be an exemption from taxation to the extent provided
in that section of the Real Property Tax Law.
