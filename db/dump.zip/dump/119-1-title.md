## § 119-1 Title.


This article shall be known and may be cited as "A Local Law
to Prevent the Spread of Aquatic Invasive Species in Tompkins County."
