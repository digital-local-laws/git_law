## § 127-8 Revocation of license.



A. The Sheriff may at any time for a violation of this chapter,
or any other ordinance of any law, revoke the license. When a license shall
be revoked, no refund of any unearned portion of the license fee shall be
made.

B. Notice of such revocation and the reason or reasons therefor,
in writing, shall be served upon the person named in the application by delivering
the same to him personally, or, if circumstances render this impossible, by
mailing the same to the address given in the application, certified mail,
return receipt requested; such revocation shall be immediately effective if
served personally and shall become effective 24 hours after mailing if served
by mail.

C. Licenses obtained by fraud or misrepresentation of any
material fact shall be wholly invalid and shall be surrendered upon demand;
no refund of the license fee shall be made, and the violators shall be subject
to the provisions of § 127-13.


