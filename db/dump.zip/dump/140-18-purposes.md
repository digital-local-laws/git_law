## § 140-18 Purposes.


This article is adopted pursuant to the laws of the State of New York
to:

A. Advance the implementation of a plan for the management
of solid waste generated, originated, or brought within the County of Tompkins,
to promote the safety, health and well-being of persons and property within
the County of Tompkins;

B. Allow for the equitable payment of solid waste management
costs by those responsible for generating the solid waste and thereby foster
waste reduction, recycling and integrated solid waste management;

C. Carry out the policy of the state to foster efficient
solid waste management and disposal organized and administered by the county
as the appropriate planning unit; and

D. Foster the state legislative purpose of encouraging the
development of economical and environmentally sound projects for the present
and future collection, treatment and management of solid waste.


