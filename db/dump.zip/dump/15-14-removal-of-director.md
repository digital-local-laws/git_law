## § 15-14 Removal of Director.


The Board may remove the Director for cause, upon written charges, and
after such Director, upon due notice, has been given an opportunity to be
heard.
