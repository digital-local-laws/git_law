## § 110-9 Authority.


This article is enacted under authority of § 10
of the Municipal Home Rule Law of the State of New York, Article IX
of the State Constitution of New York, the county law and other applicable
statutory and decisional law.
