## § 13-6 Authorization and payment. 


[Amended 10-4-1994 by L.L.
No. 6-1994]
The assigned attorney shall submit simultaneously the original voucher
to the presiding judge and a copy to the supervising attorney. The supervising
attorney shall review and may authorize payment of the voucher not objected
to by the presiding judge, in writing, within 21 days of submission. All authorized
vouchers shall be submitted to the Director of Finance for payment as if signed
by the presiding judge.
