## § 114-3 Purposes.


This article is enacted pursuant to the laws
of the State of New York, including Municipal Home Rule Law § 10(1)(ii)(a)(9-a)
and County Law § 226-b, to: institute a plan to charge users
of recycling, solid waste and related services and facilities provided
by the county, a fee for the use of such services and facilities,
which fees shall cover the cost of the services being provided, and
which fees shall be charged on an equitable basis, related to the
level of recycling and solid waste services available to the class
of users.
