## § 15-5 Ex officio members.


The Commissioner of Public Welfare and the Commissioner of the Tompkins
County Health Department shall be members ex officio.
