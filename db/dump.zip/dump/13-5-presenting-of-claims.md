## § 13-5 Presenting of claims. 


[Amended 10-4-1994 by L.L.
No. 6-1994]
Claims by attorneys for services rendered pursuant to § 18-B
of the County Law shall be submitted to the Administrator of the Tompkins
County Assigned Counsel Program for forwarding to the Tompkins Director of
Finance within 90 days of completion of services.
