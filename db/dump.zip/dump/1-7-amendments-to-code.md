## § 1-7 Amendments to Code.


Any and all additions, deletions, amendments or supplements to any of
the local laws and ordinances known collectively as the "Code of Tompkins
County" or any new local laws or ordinances, when enacted or adopted in such
form as to indicate the intention of the Board of Representatives to be a
part thereof, shall be deemed to be incorporated into such Code so that reference
to the Code shall be understood and intended to include such additions, deletions,
amendments or supplements. Whenever such additions, deletions, amendments
or supplements to the Code shall be enacted or adopted, they shall thereafter
be printed and, as provided hereunder, inserted in the loose-leaf book containing
said Code as amendments and supplements thereto. Nothing contained in this
local law shall affect the status of any local law or ordinance contained
herein, and such local laws or ordinances may be amended, deleted or changed
from time to time as the Board of Representatives deems desirable.
