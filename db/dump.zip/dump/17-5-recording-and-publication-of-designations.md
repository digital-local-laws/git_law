## § 17-5 Recording and publication of designations.


The name, address and rank in order of succession of each duly authorized
deputy or emergency interim successor shall be filed with the County Clerk,
and each designation, replacement or change in order of succession of any
emergency interim successor, Acting Chairman of the Board of Supervisors or
Deputy Chairman of the Board of Supervisors shall become effective when the
designator files with such Clerk the successor's name, address and rank in
order of succession. Such Clerk shall keep an up-to-date file of all such
data regarding duly authorized deputies, Acting Chairman of the Board of Supervisors,
Deputy Chairman of the Board of Supervisors, and emergency interim successors,
and the same shall be open to public inspection. The Clerk shall notify, in
writing, each designated person of the filing of his name as an emergency
interim successor, Acting Chairman of the Board of Supervisors or Deputy Chairman
of the Board of Supervisors and his rank in order of succession, and also
shall notify, in writing, any person previously designated who is replaced
or whose place in order of succession is changed.
