## § 19-1 Authorization to sell without bidding.


The County of Tompkins is authorized to lease
or sell county real property no longer needed for public use for adequate
consideration to a private entity or entities without bidding, provided
that the county shall first determine that said property is no longer
needed for public use in accordance with § 215 of the County
Law.
