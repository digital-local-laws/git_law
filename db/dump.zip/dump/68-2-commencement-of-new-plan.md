## § 68-2 Commencement of new plan.


On and after January 1, 1957, the County of Tompkins shall participate
in the plan of self-insurance provided for in Article 5 of the Workers' Compensation
Law; and such plan is hereby established, to be known as the "Tompkins County
Self-Insurance Plan."
