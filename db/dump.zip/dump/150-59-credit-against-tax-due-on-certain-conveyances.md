## § 150-59 Credit against tax due on certain conveyances.


A grantor shall be allowed a credit against
the tax due on a conveyance of real property to the extent tax was
paid by such grantor on a prior creation of a leasehold of all or
a portion of the same real property or on the granting of an option
or contract to purchase all or a portion of the same real property,
by such grantor. Such credit shall be computed by multiplying the
tax paid on the creation of the leasehold or on the granting of the
option or contract by a fraction, the numerator of which is the value
of the consideration used to compute such tax paid that is not yet
due to such grantor on the date of the subsequent conveyance (and
that such grantor will not be entitled to receive after such date),
and the denominator of which is the total value of the consideration
used to compute such tax paid.
