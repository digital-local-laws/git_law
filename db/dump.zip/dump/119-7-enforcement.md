## § 119-7 Enforcement.


Enforcement of this article shall be in the same manner as a
traffic violation is handled: through the use of an appearance ticket
and procedures similar to that used to enforce the Vehicle and Traffic
Law of the State of New York, except that the citation may be in a
form determined to be adequate and expedient by the law enforcement
agency issuing the citation.
