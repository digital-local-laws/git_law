## § 110-12 Routing.


All wireless telephone service suppliers doing
business in Tompkins County shall route all 911 emergency calls to
the Tompkins County Public Service Answering Point.
