## § 28-1 Composition of Tompkins County Legislature; terms of office.


The governing board of County of Tompkins, known and designated
as the Tompkins County Legislature, shall be made up of 14 Legislators,
each of whom shall be elected for a four-year term of office commencing
January 1, 2014.
