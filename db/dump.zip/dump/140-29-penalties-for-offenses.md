## § 140-29 Penalties for offenses.



A. Civil penalties.

(1) The county may commence a civil action to enjoin or otherwise
remedy any failure to comply with this article or the rules, regulations and
order promulgated pursuant to this article. Any such action may include a
claim for any losses suffered by the county as a result of the failure to
comply.

(2) In addition to any other penalties prescribed in this
article, the county may maintain an action in a court of competent jurisdiction
to impound the vehicle(s) and/or equipment used in violating this article
of a person required to maintain a solid waste license who is operating without
a solid waste license or is operating with a suspended, revoked or expired
solid waste license, or has been found guilty of or liable for serious repeated
violations of this article or the rules, regulations and orders promulgated
thereto.



B. Criminal procedures.

(1) Failure to comply with this article or the rules, regulations
or orders promulgated pursuant to this article, shall be a violation as defined
in § 55.10 of the Penal Law.

(2) Any person convicted of a violation, other than a violation
of § 140-27, shall be liable for:

(a) A fine of up to $1,000 for the first violation, and a
fine of up to $2,500 for the second violation, and a fine of up to $5,000
for any succeeding violations; or

(b) Imprisonment for a term of up to 15 days per violation;
or

(c) Both a fine and imprisonment; and/or

(d) Community service.



(3) A person convicted of a violation of § 140-27
shall be liable for a fine of not less than $50 nor more than $500.

(4) Each commission of a single act shall constitute a separate
violation of this article, and each day such violation occurs or continues
shall constitute a separate offense, which may be punished and prosecuted
as such.



C. Any penalties or damages recovered or imposed under this
article are in addition to any other remedies available at law or equity.


