## § 150-50 Exemption granted; amount.



A. Pursuant to § 469 of the Real Property Tax
Law, there shall be an exemption from taxation to the extent of any
increase in assessed value of residential property resulting from
the construction or reconstruction of such property for the purpose
of providing living quarters for a parent or grandparent who is 62
years of age or older.

B. Such exemption shall not exceed the increase in assessed
value resulting from construction or reconstruction of such property;
or 20% of the total assessed value of such property as improved; or
20% of the median sale price of residential property as reported in
the most recent sales statistical summary published by the state board
for the County in which the property is located, whichever is less.


