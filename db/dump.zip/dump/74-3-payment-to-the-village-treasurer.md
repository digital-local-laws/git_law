## § 74-3 Payment to the Village Treasurer.


The Office of Budget and Administration shall, on or before the first
day of April following the receipt of the account and certification of delinquent
village taxes as provided in § 1436 of the Real Property Tax Law,
pay to the Village Treasurer the amount of returned delinquent village taxes
remaining unpaid, including interest accumulated at the time of the return
of the tax roll and warrant by the Village Treasurer to the Village Board
of Trustees.
