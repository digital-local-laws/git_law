## § 90-2 Penalties for offenses. 


[Amended 3-14-1977 by L.L.
No. 1-1977]
Any owner of a dog who shall neglect to confine the dog as required
by an order made pursuant to § 115 of the Agriculture and Markets
Law shall be subject to a penalty of $10. Any owner of a dog who shall neglect
to confine the dog as required by orders made pursuant to § 115(a)
of the Agriculture and Markets Law shall be subject to a penalty of $25.
