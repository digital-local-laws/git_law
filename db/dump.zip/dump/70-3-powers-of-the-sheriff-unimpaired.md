## § 70-3 Powers of the Sheriff unimpaired.


Except where inconsistent with this chapter, the Sheriff shall have
and exercise all powers and duties now and hereafter conferred or imposed
by any law applicable to the Sheriff and such other duties as may be imposed
by law.
