## § 130-4 Enforcement.


Pursuant to § 33-1004 of the New York Environmental Conservation
Law, the Tompkins County Department of Health and Department of Weights and
Measures shall enforce the provisions of this article administratively, provided
that all sanctions, which shall be assessed after providing a hearing or opportunity
to be heard, shall be as specified in the penalties provision herein of this
article and shall be payable to and deposited with Tompkins County. In particular,
the Department of Health shall be responsible for neighbor and applicator
provisions and the Department of Weights and Measures shall be responsible
for retail establishment provisions.
