## § 162-16 Penalties for offenses.



A. Violation of this article is hereby made a traffic infraction
and, upon a first, second and third conviction thereof, shall be punishable
by a fine or fines as determined by resolution of the Board of Representatives.

B. Failure to appear or answer on the return date set forth
in said summons shall result in a certification of the same by said Municipal
Court to the New York State Commissioner of Motor Vehicles.


