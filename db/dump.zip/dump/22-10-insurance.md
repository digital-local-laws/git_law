## § 22-10 Insurance.


Tompkins County is hereby authorized and empowered to purchase insurance
from any insurance company created by or under the laws of the State of New
York, or authorized by law to transact business in this state against any
liability imposed by the provisions of this article, or to act as a self-insurer
with respect thereto.
