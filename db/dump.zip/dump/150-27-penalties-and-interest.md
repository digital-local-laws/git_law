## § 150-27 Penalties and interest.



A. Any person failing to file a return or to pay over
any tax to the County Administrator within the time required by this
article shall be subject to a penalty of 10% of the amount of tax
due, plus interest at the rate of 1.5% of such tax for each month
of delay, except the first month after such return was required to
be filed or such tax became due. Such penalties and interest shall
be paid and disposed of in the same manner as other revenues from
this article.

B. The following persons shall, in addition to the penalties
herein or elsewhere prescribed, be guilty of a misdemeanor, punishment
for which shall be a fine of not more than $1,000 or imprisonment
not exceeding one year, or both:

(1) Any operator, occupant, or any officer of a corporate
operator or occupant failing to file a return required by this article,
or filing or causing to be filed, making or causing to be made, giving
or causing to be given any return, certificate, affidavit, representation,
information, testimony or statement authorized or required by this
article, which is willfully false;

(2) Any operator or officer of a corporate operator willfully
failing to file a bond required to be filed pursuant to § 150-19
of this article, failing to file a registration certificate and such
data in connection therewith as the County Administrator may require,
failing to display or surrender the certificate of authority as required
by this article, or assigning or transferring such certificate of
authority;

(3) Any operator or officer of a corporate operator willfully
failing to charge separately from the rent the tax herein imposed,
willfully failing to state such tax separately on any evidence of
occupancy and on any bill, statement or receipt of rent issued or
employed by the operator, or willfully failing or refusing to collect
such tax from the occupant;

(4) Any operator or officer of a corporate operator who
refers or causes reference to be made to this tax in a form or manner
other than that required by this article; and

(5) Any operator failing to keep records required by § 150-16
of this article.



C. Any operator or officer of a corporate operator who
fails to file a certificate of registration as provided under this
article shall be subject to a penalty of $50 for each month of delinquency
in filing such certificate. Officers of a corporate operator shall
be personally liable for the tax collected or required to be collected
by such corporation under this article, and subject to the penalties
hereinabove imposed.

D. The certificate of the County Administrator to the
effect that a tax has not been paid, that a return, bond, or registration
certificate has not been filed, or that information has not been supplied
pursuant to the provisions of this article, shall be presumptive evidence
thereof.


