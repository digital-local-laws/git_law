## § 13-2 Establishing prior third-party coverage.


The Sheriff of Tompkins County, upon receiving a person committed to
the Tompkins County Jail as an inmate, shall determine by questioning such
person or by other procedures, if the person carries third-party coverage
or indemnification for services received from a hospital, doctor, or dentist,
required to be provided to an inmate by § 500-h of the Correction
Law of the State of New York.
