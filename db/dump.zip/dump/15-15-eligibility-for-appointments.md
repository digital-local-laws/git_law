## § 15-15 Eligibility for appointments.


Notwithstanding any inconsistent provision of law, general, special
or local, no person shall be ineligible for Board membership or appointment
as Director under or pursuant to this chapter because he holds any other public
office, employment, or trust, nor shall any person be made ineligible to or
forfeit his right to any public office, employment or trust by reason of such
an appointment under this chapter.
