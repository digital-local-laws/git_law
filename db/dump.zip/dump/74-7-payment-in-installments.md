## § 74-7 Payment in installments.


Such taxes may be paid in two equal installments, the first of which
shall be due and payable not later than the 15th day of the month in which
the respective taxes may be paid without interest to the local receiver or
collector of taxes without regard to this article. The second installment
shall be due and payable not later than the first day of the sixth month thereafter
to the County Treasurer of the County of Tompkins.
