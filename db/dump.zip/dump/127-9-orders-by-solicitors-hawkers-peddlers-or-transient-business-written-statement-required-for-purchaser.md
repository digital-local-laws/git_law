## § 127-9 Orders by solicitors, hawkers, peddlers or transient business; written statement required for purchaser.


A written statement of all orders taken by licensed solicitors who demand,
accept or receive payment or deposit of money in advance of final delivery,
setting forth the terms thereof, the amount paid in advance, the name of the
solicitor and the name of the person or firm he represents, shall be given
to the purchaser at the time the money is paid to or deposited with such individual
or firm.
