## § 32-2 Definitions.


As used in this chapter, the following terms shall have the
meanings indicated:

BOARD
The Tompkins County Legislature or any County administrative
board, commission, or other agency or body of the County of Tompkins.


CODE
The Tompkins County Code of Ethics.


CONFIDENTIAL INFORMATION
Includes any information that would i) affect current or
imminent contract awards or collective bargaining negotiations, or
ii) interfere with law enforcement investigations or judicial proceedings,
or iii) deprive a person of his/her right to a fair trial or impartial
adjudication, or iv) constitute an unwarranted invasion of privacy,
or v) endanger the life or safety of any person, or vi) provide civil
service examination questions or answers prior to administration of
the examination, or vii) reveal computer access codes, or viii) provide
any information that is specified as nondisclosable by federal or
state law. Procedures that determine whether other information is
confidential are described in the Tompkins County Administrative Policy
Manual.


COUNTY
Tompkins County.


COUNTY OFFICER OR EMPLOYEE
A paid or unpaid officer or employee of Tompkins County,
including, but not limited to, the members of any County board.


COUNTY RESOURCES
Include, but are not limited to, County personnel and the
County's money, vehicles, equipment, materials, supplies, or
other property.


GIFT
Includes anything of value, whether in the form of money,
service, loan, travel, entertainment, hospitality, thing or promise,
or in any other form.


INTEREST
A direct or indirect financial or material benefit, but does
not include any benefit arising from the provision or receipt of any
services generally available to the residents or taxpayers of the
County or an area of the County, or a lawful class of such residents
or taxpayers. A County officer or employee is deemed to have an interest
in any private organization when he or she, his or her spouse, or
a member of his or her household, is an owner, partner, member, director,
officer, employee, or directly or indirectly owns or controls more
than 5% of the organization's outstanding stock. This definition
shall not apply to a person serving as an unpaid member, director,
or officer of a not-for-profit organization.


KEY EMPLOYEES
Those employees of Tompkins County designated annually by
resolution of the Tompkins County Legislature as key employees who
are required to file an annual financial disclosure form.


RELATIVE
A parent, stepparent, spouse, spouse equivalent, domestic
partner, sibling, step sibling, sibling's spouse, child, stepchild,
grandparent, parent of spouse or spouse equivalent or domestic partner,
including in-laws and members of the household of a County officer
or employee, and individuals having any of these relationships to
the spouse of the officer or employee.

