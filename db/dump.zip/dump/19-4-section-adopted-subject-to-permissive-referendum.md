## § 19-4 Section adopted subject to permissive referendum.


Section 19-3 is adopted subject to permissive referendum pursuant
to § 24 of the Municipal Home Rule Law.[1]
[1]:
Editor's Note: No valid petition requesting such referendum
was filed as of 2-3-2014.
