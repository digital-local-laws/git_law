## § 74-8 Service charge for installment payment.


There shall be a service charge of 2 1/2% of the amount of taxes
as levied which it is estimated will reimburse the county for the expense
incurred in the administration of the installment collection of taxes as prescribed
by this article, including the cost for contracting any necessary indebtedness
for advancing the money as provided in §§ 976 and 1342, respectively,
of the Real Property Tax Law. If, in any year, the estimated service charge
shall not be sufficient to reimburse the county for administering the financing
of the collection of taxes in installments as provided in this article, the
amount of such deficiency shall be included in determining the estimated service
charge for the collection of taxes for the succeeding year by resolution of
the Tompkins County Board of Representatives pursuant to Real Property Tax
Law § 972, Subsection 3. The amount of such service charge shall
be added to the first installment of the taxes which an owner of real property
may have elected to pay in installments pursuant to the provisions of this
article, and such service charge shall be deemed part of such taxes. The amount
of such charge and any interest which shall be added to any installment pursuant
to the provisions of this article shall belong to the county.
