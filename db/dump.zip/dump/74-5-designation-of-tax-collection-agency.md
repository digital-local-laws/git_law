## § 74-5 Designation of tax collection agency.


On and after the effective date of this article, and until such time
as this article is repealed, the County of Tompkins shall become the tax collection
agency for the purpose of collecting taxes in installments as prescribed by
Article 9, Title 4-A and by Article 13 of the Real Property Tax Law of the
State of New York.
