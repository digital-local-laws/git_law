## § 114-8 Billing and collecting of fee. 


[Amended 12-7-1993 by L.L. No. 5-1993; 9-6-1994 by L.L. No. 5-1994]

A. The county shall mail on or about January 2 to each
owner of real property an invoice for the annual solid waste fee due
from such owner. Such invoice may be sent as a separate statement
or may be sent as a separate line item on the county tax bill.

B. The fee shall be due January 1, and payable without
interest or penalties by January 31, and payment shall be made to
the County Division of Budget and Finance, in person or by mail, at
such locations as are specified on the invoice. The fee shall be paid
in one lump sum; partial payments will not be accepted, except under
the provisions of L.L. No. 8-1990.[1]
[1]:
Editor's Note: See Ch. 74, Tax Collection,
Art. II, Collection in Installments.

C. All annual solid waste fees shall be a debt and personal
obligation of the owner of the parcel of property. Said fees shall
be a lien upon the parcel of property as of the due date of the fee.


