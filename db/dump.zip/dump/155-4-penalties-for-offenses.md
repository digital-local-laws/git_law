## § 155-4 Penalties for offenses.


Any person, business, tobacco retailer, or owner, manager or operator
of any establishment subject to this chapter who fails to comply with any
provision of this chapter shall be guilty of a violation as defined by § 55.00
of the Penal Law and be subject to a fine of up to $1,000 for a first violation
and a fine up to $2,500 for a second or succeeding violation or by imprisonment
of not more than 15 days, or by both such fine and imprisonment. Any peace
officer or police officer within the County of Tompkins is authorized to enforce
this chapter. The County Board of Health and the Public Health Director are
authorized to enforce this chapter in the same manner as a violation of the
County Sanitary Code.
