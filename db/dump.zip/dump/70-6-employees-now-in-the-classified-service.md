## § 70-6 Employees now in the classified service.


Nothing herein contained in this chapter shall apply to or otherwise
affect the status of those employees of the Sheriff who are in the classified
service as of the effective date of this chapter. The status of such employees
shall continue for all purposes as if this chapter had not been adopted.
