## § 15-13 Compensation of the Director.


Compensation of the Director shall be fixed by the Community Mental
Health Board as recommended by the Civil Service and Salaries Committee and
approved by the Board, within the amounts made available by appropriation
therefor. In addition to such compensation, the Director shall be allowed
his actual and necessary expenses in the performance of official duties.
