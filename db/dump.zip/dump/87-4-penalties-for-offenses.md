## § 87-4 Penalties for offenses.



A. Penalty clause. Any person, firm, corporation, or other
party violating any provision of this chapter or any rule, regulation or standard
adopted pursuant to this chapter shall be deemed guilty of an offense and,
upon conviction, shall be subject to a fine not exceeding $250, or to imprisonment
for a term not exceeding 30 days, or to both. Nothing herein shall be construed
to exempt an offender from any other prosecution or penalty.

B. Revocation of privileges. The County reserves the right
to revoke the privilege of use of the Airport and its facilities to any tenant
or staff member and any user for violation of any airport rules or regulations.


