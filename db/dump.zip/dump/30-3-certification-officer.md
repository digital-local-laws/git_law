## § 30-3 Certification Officer.


Pursuant to requirements of § 963
of the General Municipal Law, the County Assessor shall serve as the
Local Empire Zone Certification Officer of Tompkins County's Empire
Zone and shall perform the following duty, to wit: certify, jointly
with the New York State Commissioner of Economic Development and the
New York State Commissioner of Labor, those business enterprises that
are eligible to receive benefits referred to in § 966 of
the General Municipal Law and any other applicable statutes.
