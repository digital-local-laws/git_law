## § 150-25 Administration of oaths and compelling testimony.



A. The County Administrator or employees or agent(s)
duly designated and authorized shall have the power to administer
oaths and take affidavits in relation to any matter or proceeding
in the exercise of their powers and duties under this article. The
County Administrator shall have power to subpoena and require the
attendance of witnesses and the production of books, papers, and documents
to secure information pertinent to the performance of the duties hereunder
in the enforcement of this article, and to examine them in relation
thereto. The County Administrator shall also have the power to issue
commissions for the examination of witnesses who are out of the state,
unable to attend, or who are excused from attendance.

B. A Supreme Court Justice, either in court or in chambers,
shall have the power to summarily enforce by proper proceedings the
attendance and testimony of witnesses and the production and examination
of books, papers, and documents called for by the subpoena of the
County Administrator under this article.

C. Any subpoenaed person who refuses to testify or produce
books or records, or who testifies falsely in any material matter
pending before the County Administrator under this article shall be
guilty of a misdemeanor, punishment for which shall be a fine of not
more than $1,000 or imprisonment for not more than one year, or both
such fine and imprisonment.

D. The officers who serve the summons or subpoena of
the County Administrator and witnesses attending in response thereto
shall be entitled to the same fees as are allowed to officers and
witnesses in civil cases in courts of record, except as herein provided
otherwise. Such officers shall be the County Sheriff and duly appointed
deputies, or any officers or employees of the County Administrator's
office designated to serve such process.


