## § 98-2 Enforcement of State Code.


It is the intention of the County of Tompkins to enforce the provisions
of the New York State Uniform Fire Prevention and Building Code on its own
buildings and structures.
