## § 4-2 Purpose; office created.


In order to better provide for the needs of the elderly in our community,
the County of Tompkins hereby creates a Tompkins County Office for the Aging.
