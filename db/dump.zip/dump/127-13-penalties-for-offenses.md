## § 127-13 Penalties for offenses.


The violation of the provisions of this chapter shall constitute an
offense, and a person guilty of such offense may be punished by a fine not
exceeding $1,000 or by imprisonment not exceeding 30 days, or by both fine
and imprisonment.
