## § 160-7 Records.



A. The county shall maintain a book of registry for abandoned
vehicles in substantially the form prescribed in Subsection B of this section.

B. Form of book of registry: (See next page).


