## § 80-1 Establishment.


A County Traffic Safety Board is hereby established by the Board of
Representatives of Tompkins County pursuant to Article 43 of the Vehicle and
Traffic Law.
