## § 83-2 Commencement of registration system.


The first election to be held hereunder shall be the general election
of the year 1958, and registration shall be taken preceding such election
in the manner provided by Article 15 of the Election Law.
