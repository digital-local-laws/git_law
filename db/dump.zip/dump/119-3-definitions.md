## § 119-3 Definitions.


As used in this article, the following terms shall have the
following meanings:

AQUATIC INVASIVE SPECIES
With respect to waters located and/or accessed in Tompkins
County, any aquatic species, whether animal or plant, including its
eggs, spores or other biological material capable of propagating or
reproducing that species, whether or not natural to said waters, including
all of its cultivars and varieties, whose introduction causes or is
likely to cause economic or environmental harm or harm to human health.
Invasive species, as that term is used herein, includes but is not
limited to Asian clam (Corbicula fluminea), Eurasian water milfoil
(Myriophyllum spicatum), Hydrilla (Hydrilla verticillata), zebra mussels
(Dreissena polymorpha) and quagga mussels (Dreissena bugensis). Aquatic
invasive species shall also include any species listed separately
either within the New York State Environmental Conservation Law, New
York State Rules and Regulations or by a local agency duly authorized
to define invasive species and as listed on the attached schedule,[1] as it may be amended from time to time. Commercial availability
of an aquatic invasive species, such as in aquarium stores, pet stores,
bait shops, or otherwise, does not exempt such plant or animal from
the provisions of this legislation.


HAUL
To lift a watercraft above or lift above and remove beyond
50 feet from the high water mark of any water body.


LAUNCH
To place a watercraft into a water body for any purpose and
any related activity that takes place within 50 feet of the high water
mark of the water body for the purpose of placing a watercraft into
a water body, including moving by trailer or other device or carrying
by hand a watercraft toward a water body, or entering a queue prior
to launching.


PERSON
Any individual, governmental entity, firm, partnership, corporation,
company, society, association, or any organized group of persons,
whether incorporated or not, and every officer, agent, or employee
thereof.


WATER BODY
The same as "waters."


WATERCRAFT
Every motorized or nonmotorized boat, vessel, shell, jet
ski, personal watercraft, canoe, kayak, raft, derrick, barge, platform
or vehicle, either recreational or commercial, capable of being used
or operated in or on water.


WATERS
All lakes, including Cayuga Lake, bays, sounds, ponds, impounding
reservoirs, springs, wells, rivers, streams, creeks, including intermittent
streams or creeks, estuaries, marshes, inlets, canals, ephemeral drainageways,
and ditches, within the territorial limits of the County of Tompkins,
and all other bodies of surface or underground water, natural or artificial,
fresh, public or private, that are wholly or partially within or bordering
the County or within its jurisdiction.

[1]:
Editor's Note: The Schedule of Aquatic Invasive Species
is included at the end of this chapter.
