## § 26-1 Purpose.


This chapter is adopted pursuant to § 257-c of the Executive
Law of the State of New York, which permits counties to adopt local laws requiring
individuals sentenced to a period of probation upon conviction of any crime
under Article 31 of the Vehicle and Traffic Law to pay to the local probation
department supervising such an individual an administrative fee of $30 per
month.
