## § 150-58 Exemptions.



A. The following shall be exempt from payment of the
real estate transfer tax:

(1) The State of New York, or any of its agencies, instrumentalities,
political subdivisions, or public corporations (including a public
corporation created pursuant to agreement or compact with another
state or the dominion of Canada);

(2) The United Nations, the United States of America and
any of its agencies and instrumentalities.



B. The exemption of such governmental bodies or persons
shall not, however, relieve a grantee from them of liability for the
tax.

C. The tax shall not apply to any of the following conveyances:

(1) Conveyances to the United Nations, the United States
of America, the State of New York, or any of their instrumentalities,
agencies or political subdivisions (or any public corporation, including
a public corporation created pursuant to agreement or compact with
another state or the dominion of Canada);

(2) Conveyances that are or were used to secure a debt
or other obligation;

(3) Conveyances that, without additional consideration,
confirm, correct, modify, or supplement a prior conveyance;

(4) Conveyances of real property without consideration
and otherwise than in connection with a sale, including conveyances
conveying realty as bona fide gifts;

(5) Conveyances given in connection with a tax sale;

(6) Conveyances to effectuate a mere change of identity
or form of ownership or organization where there is no change in beneficial
ownership, other than conveyances to a cooperative housing corporation
of the real property comprising the cooperative dwelling or dwellings;

(7) Conveyances that consist of a deed of partition;

(8) Conveyances given pursuant to the federal bankruptcy
act;

(9) Conveyances of real property that consist of the execution
of a contract to sell real property without the use or occupancy of
such property or the granting of an option to purchase real property
without the use or occupancy of such property; and

(10) 
Conveyances of an option or contract to purchase
real property with the use or occupancy of such property where the
consideration is less than $200,000 and such property was used solely
by the grantor as his personal residence and consists of a one-, two-
or three-family house, an individual residential condominium unit,
or the sale of stock in a cooperative housing corporation in connection
with the grant or transfer of a proprietary leasehold covering an
individual residential cooperative unit.




