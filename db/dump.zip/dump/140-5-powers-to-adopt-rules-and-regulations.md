## § 140-5 Powers to adopt rules and regulations.



A. The Board of Representatives is authorized to promulgate,
revise, amend and publish rules, regulations and orders necessary to carry
out the purposes of this article. Such rules, regulations and orders may,
but shall not be limited to or required to, include the following:

(1) Designate, define and modify categories of recyclable
materials for which economic markets exist as regulated recyclable materials
to be source separated pursuant to this article.

(2) Prescribe methods and standards of source separation
for regulated recyclable materials.

(3) Identify one or more authorized recycling facilities
to which regulated recyclable materials may be delivered, subject to such
exceptions as the Solid Waste Manager may determine to be in the public interest.

(4) Establish criteria and procedures to identify persons
exempt from all or parts of this article and the rules and regulations hereunder.

(5) Establish county programs to implement source separation
of recyclable materials.

(6) Provide notice and public education consistent with this
article and the rules and regulations promulgated hereunder.

(7) Determine the form, content and procedures of reports
and records to be maintained pursuant to this article.



B. The Board of Representatives, in promulgating the rules,
regulations, and orders, may reflect local differences in types of waste generators,
population density, accessibility and capacity of markets and facilities,
collection practices, and waste composition. The Board of Representatives
shall also give due consideration to existing source separation, recycling,
and other facilities in the area; to the adequacy of markets for separated
materials, and to any additional expense and effort to be incurred by waste
generators and haulers. In addition, the Board of Representatives shall consider
the capacity, handling, disposal, marketing capabilities, and geographical
location of available facilities, and such other factors as enable the Board
of Representatives to determine that the public interest is served by the
rule or regulation.

C. The Board of Representatives may delegate to its designee
all or part of its power to promulgate rules, regulations, and orders.


