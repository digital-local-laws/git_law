## § 1-9 Sale of Code book; supplementation.KEEPFOLLOWING


Copies of the Code, or any chapter or portion of it, may be purchased
from the Clerk of the Board of Representatives, or an authorized agent of
the Clerk, upon the payment of a fee to be set by resolution of the Board
of Representatives. The Clerk of the Board of Representatives may also arrange
for procedures for the periodic supplementation of the Code.
