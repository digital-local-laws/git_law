## § 127-12 Purchase and/or sale of precious metals and jewelry.



A. In addition to the standing provisions of this chapter
governing transient business transactions, the following provisions will apply
to the purchase and/or sale of precious metals:

(1) All transactions shall be in the "accepted trade standards"
(i.e.: karat, metric, troy, etc.).

(2) The range of prices being paid must be conspicuously
posted at a place where business is transacted.

(3) Advertising must clearly state purchase prices being
offered in relation to "accepted trade standards."

(4) Scales used in any purchase or sale must be New York
State approved for both lightweight and heavyweight metals.



B. All purchases must be recorded and conform to the following:

(1) Full description of item purchased.

(2) Name of seller, address and telephone number. (Identification
used for confirmation of information will be a driver's license, social security
card or other satisfactory ID with picture normally accepted as approved documents.)

(3) Physical description of seller (i.e.: height, weight,
color hair, eyes and complexion, etc.).

(4) No transactions shall be made with any individual under
the age of 18.

(5) No transactions shall be conducted after 9:00 p.m. Any
records so maintained shall be made available to any law enforcement officials
at any time covering transient business transactions conducted in this community
and for a period of 90 days thereafter if such is requested.



C. Any hawker, peddler, solicitor or transient business
that purchases or sells precious metals must secure a bond in accordance with
provisions outlined in § 127-4B of this chapter.


