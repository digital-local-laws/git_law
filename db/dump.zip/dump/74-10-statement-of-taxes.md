## § 74-10 Statement of taxes.



A. Upon receipt of the tax roll and warrant, the collecting
officer shall mail to each property owner of property listed thereon, a statement
of taxes as provided by law.

B. Such statement shall recite that such owner may elect,
pursuant to § 74-11 of this article, to pay the taxes set forth
in the statement in installments, as provided herein.


