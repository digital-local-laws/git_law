## § 92-3 Definitions.


As used in this chapter, the following terms shall have the meanings
indicated:

COMMERCIAL SPACE
Any space in a building, structure, or portion thereof which is used
or occupied or is intended, arranged or designed to be used or occupied for
the manufacture, sale, resale, processing, reprocessing, displaying, storing,
handling, garaging or distribution of personal property; and any space which
is used or occupied, or is intended, arranged or designed to be used or occupied
as a separate business or professional unit or office in any building, structure
or portion thereof.


DISCRIMINATION
Includes segregation and separation.


EMPLOYEE
Does not include any individual employed by her or his parents, spouse
or child, or in the domestic service of any person.


EMPLOYER
Does not include any employer with fewer than four persons in her
or his employ.


EMPLOYMENT AGENCY
Includes any person undertaking to procure employees or opportunities
to work.


GENDER IDENTITY AND EXPRESSION
A person's actual or perceived gender identity, gender-related
self-image, gender-related appearance, gender-related behavioral or physical
characteristics, or gender-related expression, whether or not that gender
identity, gender-related self-image, gender-related appearance, gender-related
behavioral or physical characteristics, or gender-related expression is different
from that traditionally associated with the person's sex assigned at
birth. This shall include but not be limited to:

A. 
Transsexuals in all stages of transition, including preoperative, postoperative
and persons living in a gender other than their birth sex;

B. 
Persons (including cross-dressers) whose gender expression occasionally
differs from their birth sex; and

C. 
Intersexed persons born with anatomy or physiology that includes medical
characteristics of both male and female whose sex was assigned at birth and
who sometimes manifest physical characteristics, expressions or identity that
differs from the sex assigned.




HOUSING ACCOMMODATION
Includes any building, structure, or portion thereof which is used
or occupied or is intended, arranged or designed to be used or occupied as
the home, residence or sleeping place of one or more human beings.


LABOR ORGANIZATION
Includes any organization which exists and is constituted for the
purpose, in whole or in part, of collective bargaining or of dealing with
employers concerning grievances, terms or conditions of employment, or of
other mutual aid or protection in connection with employment.


MULTIPLE DWELLING
A dwelling which is occupied, as a rule, for the permanent residence
purposes and which is either rented, leased, let or hired out, to be occupied
as the residence or home of three or more families living independently of
each other. A multiple dwelling shall not be deemed to include a hospital,
convent, monastery, asylum or public institution, or a fireproof building
used wholly for commercial purposes except for not more than one janitor's
apartment and not more than one penthouse occupied by not more than two families.
The term “family,” as used herein, means either a person occupying
a dwelling and maintaining a household, with not more than four boarders,
roomers, or lodgers, or two or more persons occupying a dwelling living together
and maintaining a common household, with not more than four boarders, roomers
or lodgers. A boarder, roomer or lodger residing with a family means a person
living within the household who pays a consideration for such a residence
and does not occupy such space within the household as an incident of employment
therein.


PERCEIVED SEXUAL ORIENTATION
The assumption or expectation that an individual is heterosexual,
bisexual, asexual or homosexual due to their behavior or demeanor, regardless
of their actual sexual orientation.


PERSON
Includes one or more individuals, partnerships, associations, corporations,
legal representatives, trustees, trustees in bankruptcy, or receivers.


PLACE OF PUBLIC ACCOMMODATION, RESORT OR AMUSEMENT
Includes, except hereinafter specified, all places included in the
meaning of such terms as inns, taverns, road houses, hotels, motels, whether
conducted for the entertainment of transient guests or for the accommodation
of those seeking health, recreation or rest, or restaurants, or eating houses,
or any place where food is sold for consumption on the premises; buffets,
salons, barrooms, or any store, park or enclosure where spirituous or malt
liquors are sold; ice cream parlors, confectioneries, soda fountains, and
all stores where ice cream, ice and fruit preparations or their derivatives,
or where beverages of any kind are retailed for consumption on the premises;
wholesale and retail stores and establishments dealing with goods or services
of any kind, dispensaries, clinics, hospitals, bathhouses, swimming pools,
laundries and all other cleaning establishments, barbershops, beauty parlors,
theaters, motion-picture houses, roof gardens, music halls, race courses,
skating rinks, amusement and recreation parks, trailer camps, resort camps,
fairs, bowling alleys, golf courses, gymnasiums, shooting galleries, billiard
and pool parlors; garages, all public conveyances operated on land or water
or in the air, as well as the stations and terminals thereof; travel or tour
advisory services, agencies or bureaus; public halls and public elevators
of buildings and structures occupied by two or more tenants, or by the owner
and one or more tenants. Such term shall not include public libraries, kindergartens,
primary and secondary schools, high schools, academies, colleges and universities,
extension courses, and all educational institutions under the supervision
of the Regents of the State of New York; any such public library, kindergarten,
primary or secondary school, academy, college, university, professional school,
extension course or other education facility, supported in whole or in part
by public funds or by contributions solicited from the general public; or
any institution, club or place of accommodation which is in its nature distinctly
private. No institution, club, organization or place of accommodation which
sponsors or conducts any amateur athletic contest or sparring exhibition and
advertises or bills such contest or exhibition as a New York State Championship
or Tompkins County Championship contest or uses the words “New York
State” or “Tompkins County” in its announcements shall be
deemed a private exhibition within the meaning of this section.


PUBLICLY-ASSISTED HOUSING ACCOMMODATIONS
Includes all housing accommodations within the County of Tompkins
in:

A. 
Public housing;

B. 
Housing operated by companies under the supervision of the Commissioner
of Housing;

C. 
Housing constructed after July 1, 1950, within the State of New York:

(1) 
Which is exempt in whole or in part from tax levied by the state or
any of its political subdivisions;

(2) 
Which is constructed on land sold below cost by the state or any of
its political subdivisions or any agency thereof, pursuant to the Federal
Housing Act of 1949;

(3) 
Which is constructed in whole or in part on property acquired or assembled
by the state or any of its political subdivisions or any agency thereof through
the power of condemnation or otherwise for the purpose of such construction;
or

(4) 
For the acquisition, construction, repair or maintenance of which the
state or any of its political subdivisions or any agency thereof supplies
funds or other financial assistance.



D. 
Housing which is located in a multiple dwelling, the acquisition, construction,
rehabilitation, repair or maintenance of which is, after July 1, 1955, financed
in whole or in part by a loan, whether or not secured by a mortgage, the repayment
of which is guaranteed or insured by the federal government or any agency
thereof, or the state or any of its political subdivisions or any agency thereof,
provided that such a housing accommodation shall be deemed to be publicly
assisted only during the life of such loan and such guaranty or insurance;
and

E. 
Housing which is offered for sale by a person who owns or otherwise
controls the sale of 10 or more housing accommodations located on land that
is contiguous (exclusive of public streets), if:

(1) 
The acquisition, construction, rehabilitation, repair or maintenance
of such housing accommodations is, after July 1, 1955, financed in whole or
in part by a loan, whether or not secured by a mortgage, the repayment of
which is guaranteed or insured by the federal government or any agency thereof,
or the state or any of its political subdivisions or any agency thereof, provided
that such a housing accommodation shall be deemed to be publicly assisted
only during the life of such loan and such guaranty or insurance; or

(2) 
A commitment by a government agency after July 1, 1995, is outstanding
that acquisition of such housing accommodations may be financed in whole or
in part by a loan, whether or not secured by a mortgage, the repayment of
which is guaranteed or insured by the federal government or any agency thereof,
or the state or any of its political subdivisions or any agency thereof.






REAL ESTATE BROKER
Any person, firm or corporation who, for another and for a fee, commission
or other valuable consideration, lists for sale, sells, at auction or otherwise,
exchanges, buys or rents, or offers or attempts to negotiate a sale, at auction
or otherwise, exchange, purchase or rental of an estate or interest in real
estate, or collects or offers or attempts to collect rent for the use of real
estate, or negotiates, or offers or attempts to negotiate, a loan secured
or to be secured by a mortgage or other encumbrance upon or transfer of real
estate. In the sale of lots pursuant to the provisions of Article 9-A of the
Real Property Law, the term “real estate broker” shall also include
any person, partnership, association or corporation employed by or on behalf
of the owner or owners of lots or other parcels of real estate, at a stated
salary, or upon a commission, or upon a salary and commission, or otherwise,
to sell such real estate, or any parts thereof, in lots or other parcels,
and who shall sell or exchange, or offer or attempt or agree to negotiate
the sale or exchange of any such lot or parcel of real estate.


REAL ESTATE SALESPERSON
A person employed by a licensed real estate broker to list for sale,
sell or offer for sale, at auction or otherwise, to buy or offer to buy or
negotiate the purchase or sale or exchange of real estate, or to negotiate
a loan on real estate, or to lease or rent or offer to lease, rent or place
for rent any real estate, or who collects or offers or attempts to collect
rent for the use of real estate for or in behalf of such real estate broker.


SEXUAL ORIENTATION
Heterosexuality, homosexuality, bisexuality or asexuality, whether
actual or perceived.


UNLAWFUL DISCRIMINATORY PRACTICE
Includes those practices specified in this chapter.

