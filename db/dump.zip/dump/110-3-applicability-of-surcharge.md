## § 110-3 Applicability of surcharge.


The surcharge herein shall not apply to more
than 75 local exchange lines per customer per location.
