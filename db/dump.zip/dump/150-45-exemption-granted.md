## § 150-45 Exemption granted.


Real property within the County of Tompkins
altered or rehabilitated subsequent to the effective date of this
article shall be exempt from County real property taxes and special
ad valorem levies subject to and in accordance with the schedules
set forth in § 150-46 and conditions outlined in §§ 150-47
and 150-48.
