## § 150-7 Intent.


The intent of this article shall be to enhance
the general economy of Tompkins County, its cities, towns and villages
through promotion of tourist activities, conventions, trade shows,
special events and other directly related and supporting activities.
