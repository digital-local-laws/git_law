## § 150-14 Registration.


Within three days after commencing hotel business
in Tompkins County, every operator shall file with the County Administrator's
Office a certificate of registration in a form prescribed by the County
Administrator. Within five days after such registration, the County
Administrator shall issue without charge to each operator a certificate
of authority empowering such operator to collect the tax from the
occupant and duplicate thereof for each additional hotel of such operator.
Each certificate or duplicate shall state the hotel to which it is
applicable. Such certificates of authority shall be prominently displayed
by the operator in a manner that it may be seen and come to the notice
of all occupants and persons seeking occupancy in the hotel to which
it applies. Such certificates shall be nonassignable and nontransferable,
and shall be surrendered immediately to the County Administrator upon
the cessation of business at the hotel named or upon its sale or transfer.
