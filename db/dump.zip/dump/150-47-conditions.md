## § 150-47 Conditions.


No such exemption shall be granted for such
alterations or rehabilitation unless all of the following criteria
are met:

A. Such property must be designated as a landmark or
is a property that contributes to the character of a historic district,
created by a local law passed pursuant to § 96-a or § 119-dd
of the General Municipal Law.

B. Such alterations or rehabilitation of historic property
must meet guidelines and review standards establishes by governing
local preservation law.

C. Such alterations and rehabilitations must be for the
purpose of historic preservation.

D. Such alterations or rehabilitations of historic property
are approved by a governing local preservation commission prior to
the commencement of work.

E. Such alterations or rehabilitation must be commenced
subsequent to the effective date of this article.


