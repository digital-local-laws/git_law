## § 68-5 Fiscal requirements.


The amounts required for operation of the plan, as estimated by the
administrator, including contributions to the reserve, shall be apportioned
annually to each participant in the proportion that the full valuation of
its taxable real property bears to the aggregate full valuation of all participants.
