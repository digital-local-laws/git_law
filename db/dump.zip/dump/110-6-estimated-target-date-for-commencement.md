## § 110-6 Estimated target date for commencement.


The estimated target date for the commencement
of Enhanced 911 Emergency Telephone Service in Tompkins County is
November 30, 1994.
