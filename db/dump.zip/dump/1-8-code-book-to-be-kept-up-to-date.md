## § 1-8 Code book to be kept up-to-date.


It shall be the duty of the Clerk of the Board of Representatives to
keep up-to-date the certified copy of the book containing the Code of Tompkins
County required to be filed in the office of the Clerk of the Board of Representatives
for use by the public. All changes in said Code and all local laws and ordinances
adopted by the Board of Representatives subsequent to the enactment of this
local law in such form as to indicate the intention of said Board to be a
part of said Code shall, when finally enacted or adopted, be included therein
by temporary attachment of copies of such changes, local laws or ordinances
until such changes, local laws or ordinances are printed as supplements to
said Code book, at which time such supplements shall be inserted therein.
