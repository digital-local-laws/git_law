## § 162-8 County property.


The following county-owned lands and areas are designated as controlled
parking areas to be used in conjunction with Tompkins County buildings:

A. All lands owned by Tompkins County and suitable for parking
purposes.


