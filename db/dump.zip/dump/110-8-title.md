## § 110-8 Title.


This article shall be known as the "Tompkins
County Wireless 911 Call Routing Law."
