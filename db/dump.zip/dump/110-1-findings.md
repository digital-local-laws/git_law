## § 110-1 Findings.


The Tompkins County Board of Representatives,
in order to provide for the protection of the health, safety and welfare
of persons in the county, finds it in the public interest for there
to be an Enhanced 911 Emergency Telephone System operating in Tompkins
County.
