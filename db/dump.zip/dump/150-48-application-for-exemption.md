## § 150-48 Application for exemption.


This exemption shall be granted only by application
of the owner or owners of such historic real property on a form prescribed
by the State Equalization and Assessment Board. The application shall
be filed with the County Assessor, on or before the appropriate taxable
status date covering County real property.
