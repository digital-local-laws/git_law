## § 110-10 Findings and declaration of intent.



A. This Board of Representatives recognizes the paramount
importance of the health, safety and welfare of the citizens of the
county and further recognizes that when the lives or property of its
citizens are in imminent danger that appropriate assistance must be
rendered as expeditiously possible.

B. This Board of Representatives recognizes further that
such assistance is increasingly summoned by cellular phones and other
wireless communication devices and that unintentional, though avoidable,
delays in reaching appropriate emergency aid can occur when such 911
calls are not routed directly to the single county-wide Tompkins County
Public Safety Answering Point (PSAP).

C. This Board of Representatives further finds that the
Tompkins County PSAP has the most accurate, current and extensive
knowledge of Tompkins County's geography, roadways, landmarks, emergency
service resources and similar information of critical importance in
emergency situations and can immediately dispatch the number and type
of emergency services the situation requires.

D. The intent of this article is to provide for the health,
safety and welfare of the people of this county by mandating the direct
routing of all 911 calls, including wireless calls, directly to the
Tompkins County PSAP so as to facilitate the rendering of emergency
services as expeditiously and effectively as possible.


