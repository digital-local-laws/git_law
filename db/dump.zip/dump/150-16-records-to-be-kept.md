## § 150-16 Records to be kept. 


[Amended 5-7-1991 by L.L. No. 1-1991]
Every operator shall keep records of every occupancy,
of all rent paid, charged, or due, and of the tax payable thereon,
in such form as the County Administrator may require by regulation.
Such records shall be available for inspection and examination at
any time upon demand by the County Administrator or his duly authorized
employee or agent, and shall be preserved for a period of five years,
except that the County Administrator may consent to their destruction
within that period or may require that they be kept longer.
